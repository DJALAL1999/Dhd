import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../domain/guided_entry_engine.dart';
import '../domain/trade_entry_catalog.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../models/trading_account.dart';
import '../state/app_controller.dart';
import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../theme/trade_detail_palette.dart';
import '../theme/trade_outcome_palette.dart';
import '../widgets/common.dart';
import '../widgets/decision_option_emoji.dart';
import '../widgets/trade_decision_zones.dart';
import '../widgets/trade_no_entry_zones.dart';
import '../widgets/trade_save_bar.dart';

enum _TradeImageSlot { before, after, confirmation }

// The guided-entry steps live in the pure-Dart engine so the same logic is
// unit-tested; the form keeps its private alias.
typedef _AutoEntryStep = GuidedStep;

/// What happened in one round of a guided section list.
enum _GuidedListOutcome { continued, again, paused }
enum _NumericEntryTarget { result, expectedLoss }

const String _mindsetDialogCancelSentinel = '__trade_mindset_cancel__';
// Returned by a guided section list when the trader presses Continue, and by
// the entry-reason flow when a sub-popup was dismissed and the list should
// simply reopen.
const String _guidedContinueValue = '__trade_guided_continue__';
const String _guidedRetryValue = '__trade_guided_retry__';

// Market / Direction and Mindset are intentionally equal-height companion fields.
const double _tradeDataControlHeight = 72;
// Inner content height shared by Market / Direction and Mindset. An
// InputDecorator paints its outline from its CONTENT height (the outer 72dp
// box only reserves space), so both companion fields must hold content of the
// same height for their visible rectangles to be identical.
const double _tradeDataContentHeight = 30;
// Flutter scales a floating InputDecorator label to 75% of its configured size.
// 17.5dp therefore renders at about 13.1dp: readable without competing with
// the selected value or changing the inline/empty-state label size.
const double _tradeFieldLabelFontSize = 14;
const double _tradeFloatingLabelFontSize = 17.5;
// One consistent size for selected values and all trade-data popup rows.
const double _tradeDataItemFontSize = 14.5;

/// Minimum width of the Symbol / Direction popups. Their fields are only about
/// a quarter of the screen wide, which cut «SELL» down to «S…».
const double _shortChoiceMenuWidth = 104;

// Muted, product-grade tones inspired by the Windows trade-entry panels.
const _resultTone = Color(0xFF9BA9B9);
const _dataTone = Color(0xFF76AEE8);
const _imagesTone = Color(0xFF9AA3AD);
const _behaviorTone = Color(0xFFB7A2EC);
const _decisionTone = Color(0xFFC6A071);
const _commitmentTone = Color(0xFF55C99A);
const _noEntryTone = Color(0xFFB69AF0);
const _entryConditionsTone = Color(0xFF78AFC3);
const _reverseSignalsTone = Color(0xFF6E9FB6);

/// Single source for the Entry Conditions surface tint. The timeframe / choice
/// popups of this section and the Opposing signals and Bounce area fields use
/// the same blend, so a field reads as the closed state of its own popup.
Color _entryConditionsSurface({
  required TdTokens tokens,
  required Color tone,
  required Brightness brightness,
}) => Color.alphaBlend(
  tone.withValues(alpha: brightness == Brightness.dark ? .14 : .08),
  tokens.surface2,
);

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key, this.trade});
  final Trade? trade;

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _anchorMenuAnchorKey = GlobalKey();
  final _marketPopupAnchorKey = GlobalKey();
  final _directionPopupAnchorKey = GlobalKey();
  // Marks the bottom action slot (the merged outcome + save bar). The outcome
  // menu is anchored to this exact slot.
  final _saveSlotKey = GlobalKey(debugLabel: 'trade-save-slot');
  bool _outcomeMenuOpen = false;
  int _activeFormSectionIndex = 0;
  int _activeBehaviorSectionIndex = 0;
  late final TextEditingController _result;
  late final TextEditingController _expectedLoss;
  late final TextEditingController _risk;
  late final TextEditingController _rewardRisk;
  final FocusNode _resultFocusNode = FocusNode();
  final FocusNode _expectedLossFocusNode = FocusNode();
  late String _accountId;
  String? _symbol;
  TradeSide? _side;
  late Set<String> _anchors;
  late Map<String, String> _anchorTimeframes;
  late Set<String> _selectedMoods;
  late DateTime _tradedAt;
  late List<TradeEntrySetup> _entrySetups;
  late List<TradeConfirmationSetup> _confirmationSetups;
  late List<TradeConfirmationSetup> _exitReasonSetups;
  late List<TradeEntryConditionSetup> _reverseSignalSetups;
  late List<TradeEntryConditionSetup> _bounceZoneSetups;
  late Set<String> _executionReviewKeys;
  // Decisions area UI state: active zone and each zone's fold state.
  int _decisionZoneIndex = 0;
  bool _decisionAnalysisCollapsed = false;
  Set<String> _decisionCollapsedZones = <String>{};
  bool _commitmentCollapsed = false;
  final Set<String> _collapsedSelectionFields = <String>{};
  bool _anchorValuesCollapsed = false;
  int _noEntryZoneIndex = 0;
  Set<String> _noEntryCollapsedZones = <String>{};
  late Set<String> _noEntryReasons;
  late List<TradeEntryConditionSetup> _practicalNoEntryReverseSignalSetups;
  TradeClassification? _classification;
  MissedTradeOutcome? _missedOutcome;
  BreakEvenType? _breakEvenType;
  /// +1 means a positive result, -1 means a negative result. Null represents
  /// a zero-result / missed setup until the trader explicitly chooses a sign.
  int? _resultSign;
  bool _showResultSignChoices = true;
  String? _beforePath;
  String? _afterPath;
  String? _confirmationImagePath;
  // Once the first result sign starts guidance, the form keeps reconciling its
  // required fields until this screen is closed. Completing the first pass
  // does not disable monitoring: later edits can make any earlier field
  // incomplete again and the guide will route to the first missing item.
  bool _guidedEntryActive = false;
  Set<String>? _guidedMindsetDraft;
  _AutoEntryStep _autoEntryStep = _AutoEntryStep.idle;
  int _guidedReconciliationRevision = 0;
  // Sections the trader already finished with Continue during guidance.
  // Progress of the guided entry (sections passed with Continue, sections that
  // were filled at some point, section to resume). Completeness itself is
  // always derived from the live data through the engine.
  final GuidedEntryController _guided = GuidedEntryController();
  Set<_AutoEntryStep> get _guidedSectionsContinued => _guided.progress.continued;
  bool _guidedSectionRunning = false;
  final _entryReasonSectionKey = GlobalKey();
  final _confirmationSectionKey = GlobalKey();
  final _exitReasonSectionKey = GlobalKey();
  final _reverseSignalSectionKey = GlobalKey();
  final _bounceZoneSectionKey = GlobalKey();
  bool _resultKeyboardActionHandled = false;
  bool _expectedLossKeyboardActionHandled = false;
  _NumericEntryTarget? _activeNumericPad;
  bool _busy = false;
  bool _seededExpectedLoss = false;
  final _picker = ImagePicker();

  bool get _ar => AppStrings.isArabic(context);
  String _copy(String ar, String en) => _ar ? ar : en;
  bool get _hasTradeDirection => _side != null;
  // Existing-trade editing remains manual. A new, non-missed trade starts
  // monitoring when its result sign is chosen; monitoring then stays enabled
  // for the lifetime of the form, including after all guided fields are done.
  bool get _canStartGuidedEntry =>
      widget.trade == null && !_hasEntryConditionsNoEntryLink;
  bool get _shouldGuideResult =>
      _guidedEntryActive && _autoEntryStep == _AutoEntryStep.result;
  bool get _shouldGuideExpectedLoss =>
      _guidedEntryActive && _autoEntryStep == _AutoEntryStep.expectedLoss;

  bool get _hasValidGuidedExpectedLoss {
    final value = _parse(_expectedLoss);
    return value != null && value.isFinite && value > 0;
  }

  bool get _hasRecordedMindset =>
      _selectedMoods.any((key) => key != 'moodUnknown');

  /// Resolves the first incomplete required item from the live form values.
  /// The order mirrors the original guided entry: result, planned loss for a
  /// win, direction, market, then mindset.
  _AutoEntryStep get _nextIncompleteGuidedStep => _guided.next(_guidedSnapshot());

  /// The live form reduced to plain data for the engine. Every guided-area
  /// rule (what counts as filled, what does not apply) is defined here once.
  GuidedSnapshot _guidedSnapshot() => GuidedSnapshot(
        active: _guidedEntryActive,
        noEntryLink: _hasEntryConditionsNoEntryLink,
        resultValid: _resultSign != null &&
            _parseResult() != null &&
            _resultValidator(_result.text) == null,
        needsExpectedLoss: _resultSign == 1,
        expectedLossValid: _hasValidGuidedExpectedLoss,
        hasSide: _side != null,
        hasSymbol: _symbol != null && _symbol!.trim().isNotEmpty,
        hasMindset: _hasRecordedMindset,
        exitApplicable: _exitSectionTitle != null,
        filled: {
          if (_entrySetups.isNotEmpty) _AutoEntryStep.entryReason,
          // An anchor counts only while it is still linked (a removed last
          // timeframe removes the anchor itself; legacy anchors saved without
          // a timeframe stay valid).
          if (_anchors.isNotEmpty) _AutoEntryStep.anchors,
          if (_confirmationSetups.isNotEmpty) _AutoEntryStep.confirmation,
          if (_exitReasonSetups.isNotEmpty) _AutoEntryStep.exitReason,
          if (_reverseSignalSetups.isNotEmpty) _AutoEntryStep.reverseSignals,
          if (_bounceZoneSetups.isNotEmpty) _AutoEntryStep.bounceZone,
        },
      );

  static const List<_AutoEntryStep> _guidedSections =
      GuidedEntryEngine.sections;

  // Sections that live on the Entry Conditions tab (index 1) instead of the
  // Trade Details tab (index 0); the guide switches tabs before scrolling to
  // one of these so the field is actually visible when it opens.
  static const Set<_AutoEntryStep> _entryConditionsTabSections = {
    _AutoEntryStep.reverseSignals,
    _AutoEntryStep.bounceZone,
  };

  int _formSectionIndexForGuidedStep(_AutoEntryStep step) =>
      _entryConditionsTabSections.contains(step) ? 1 : 0;

  bool _isGuidedSection(_AutoEntryStep step) =>
      _guidedEntryActive && _autoEntryStep == step;

  /// Re-evaluates all guided fields after a committed selection. A cleared
  /// Mindset is left pending without immediately reopening the same dialog;
  /// the next edit elsewhere will route back to it. A revision token prevents
  /// stale post-frame work from opening an outdated popup after another edit.
  void _reconcileGuidedEntryAfterChange({
    bool deferIfMindsetRemainsEmpty = false,
  }) {
    if (!mounted || !_guidedEntryActive) return;
    final next = _nextIncompleteGuidedStep;
    setState(() {
      _autoEntryStep = next;
      // Switch tabs here too, not only in _advanceGuidedEntry, so a step that
      // lives on the Entry Conditions tab never flashes on the wrong tab for
      // a frame while this reconciliation is pending.
      if (next != _AutoEntryStep.idle) {
        _activeFormSectionIndex = _formSectionIndexForGuidedStep(next);
      }
    });
    if (deferIfMindsetRemainsEmpty && next == _AutoEntryStep.mindset) {
      _guidedReconciliationRevision++;
      return;
    }
    final revision = ++_guidedReconciliationRevision;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted ||
          !_guidedEntryActive ||
          revision != _guidedReconciliationRevision ||
          next != _autoEntryStep) {
        return;
      }
      _advanceGuidedEntry();
    });
  }

  bool get _hasPracticalNoEntryReason =>
      _practicalNoEntryReverseSignalSetups.any(_reverseSignalSetups.contains);
  bool get _hasEntryConditionsNoEntryLink =>
      _noEntryReasons.isNotEmpty || _hasPracticalNoEntryReason;
  // Keep the established contextual accent for the opposing-signal picker;
  // the outer Entry Conditions card and its connector use the separate
  // practical long-press state below.
  Color get _currentReverseSignalTone =>
      _hasEntryConditionsNoEntryLink ? _noEntryTone : _reverseSignalsTone;

  List<TradeClassification> get _availableClassifications {
    if (_hasEntryConditionsNoEntryLink) {
      return const [TradeClassification.missed];
    }
    if (_resultSign == 1) return const [TradeClassification.win];
    if (_resultSign == -1) return const [TradeClassification.loss];
    return const [
      TradeClassification.breakEven,
      TradeClassification.missed,
    ];
  }

  /// Keeps [_classification] consistent with what the form already knows:
  /// a positive result is a win, a negative result is a loss, and a
  /// psychological / opposing-signal no-entry link is a missed setup. Only
  /// when none of these decide it does the trader choose break-even / missed.
  void _reconcileClassification() {
    final available = _availableClassifications;
    if (available.length == 1) {
      final only = available.first;
      if (_classification != only) {
        _classification = only;
        _missedOutcome = null;
        _breakEvenType = null;
      }
    } else if (_classification != null &&
        !available.contains(_classification)) {
      _classification = null;
      _missedOutcome = null;
      _breakEvenType = null;
    }
    if (_classification != TradeClassification.missed) _missedOutcome = null;
    if (_classification != TradeClassification.breakEven) _breakEvenType = null;
  }

  @override
  void initState() {
    super.initState();
    final trade = widget.trade;
    _symbol = trade?.market.isNotEmpty == true ? trade!.market : null;
    _resultSign = trade == null || trade.result == 0
        ? null
        : trade.result > 0
            ? 1
            : -1;
    _result = TextEditingController(
      text: trade == null || trade.result == 0
          ? ''
          : '${trade.result > 0 ? '+' : '−'}${trade.result.abs()}',
    );
    _expectedLoss = TextEditingController(text: trade?.expectedLoss?.toString() ?? '');
    _risk = TextEditingController(text: trade?.riskPercent.toStringAsFixed(2) ?? '');
    _rewardRisk = TextEditingController();
    _accountId = trade?.accountId ?? '';
    _side = trade?.side;
    _anchors = {...?trade?.effectiveAnchors};
    _anchorTimeframes = {...?trade?.anchorTimeframes};
    _selectedMoods = trade == null
        ? <String>{'moodUnknown'}
        : trade.effectiveMoods.toSet();
    if (_selectedMoods.isEmpty) _selectedMoods = <String>{'moodUnknown'};
    _tradedAt = trade?.tradedAt ?? DateTime.now();
    _entrySetups = [...?trade?.effectiveEntrySetups];
    _confirmationSetups = [...?trade?.effectiveConfirmationSetups];
    _exitReasonSetups = [...?trade?.exitReasonSetups];
    _reverseSignalSetups = [...?trade?.reverseSignalSetups];
    _bounceZoneSetups = [...?trade?.bounceZoneSetups];
    _executionReviewKeys = {...?trade?.executionReviewKeys};
    _noEntryReasons = {...?trade?.noEntryReasons};
    // Editing a trade that only has structural reasons opens that section.
    final firstNoEntryZone = tradeNoEntryGroups.indexWhere(
      (group) => group.options.any((option) => _noEntryReasons.contains(option.key)),
    );
    _noEntryZoneIndex = firstNoEntryZone < 0 ? 0 : firstNoEntryZone;
    _practicalNoEntryReverseSignalSetups = [
      ...?trade?.practicalNoEntryReverseSignalSetups,
    ].where(_reverseSignalSetups.contains).toList();
    _classification = trade?.effectiveClassification;
    _missedOutcome = trade?.missedOutcome;
    _breakEvenType = trade?.breakEvenType;
    // A psychological reason or an explicitly linked opposing signal means
    // the record is a missed setup. Normalize older contradictory drafts in
    // the editor without changing the saved record until the user saves it.
    if (_hasEntryConditionsNoEntryLink) {
      _result.clear();
      _resultSign = null;
      _showResultSignChoices = false;
    }
    // The outcome is derived from the result sign / no-entry link, so an
    // editor never opens with a classification that contradicts them.
    _reconcileClassification();
    _beforePath = trade?.beforeImagePath;
    _afterPath = trade?.afterImagePath;
    _confirmationImagePath = trade?.confirmationImagePath;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final app = AppScope.of(context);
    if (_accountId.isEmpty && app.accounts.isNotEmpty) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    if (!_seededExpectedLoss && widget.trade != null) {
      _seededExpectedLoss = true;
      final balance = _accountBalanceBeforeTrade(app);
      final trade = widget.trade!;
      final amount = trade.expectedLoss ??
          (trade.result >= 0 && balance > 0
              ? balance * trade.riskPercent / 100
              : 0);
      _expectedLoss.text = trade.expectedLoss != null || amount > 0
          ? amount.toString()
          : '';
    }
    _updateComputedFields();
  }

  @override
  void dispose() {
    _result.dispose();
    _resultFocusNode.dispose();
    _expectedLossFocusNode.dispose();
    _expectedLoss.dispose();
    _risk.dispose();
    _rewardRisk.dispose();
    super.dispose();
  }

  double? _parse(TextEditingController controller) =>
      double.tryParse(controller.text.trim().replaceAll(',', '.'));

  double? _parseResult() {
    if (_hasEntryConditionsNoEntryLink) return 0;
    final raw = _result.text.trim();
    if (raw.isEmpty) return null;
    final sign = raw.startsWith('+')
        ? 1
        : (raw.startsWith('-') || raw.startsWith('−'))
            ? -1
            : null;
    if (sign == null) return null;
    final magnitudeText = raw.substring(1).trim();
    if (magnitudeText.isEmpty) return null;
    final magnitude =
        double.tryParse(magnitudeText.replaceAll(',', '.'));
    if (magnitude == null || !magnitude.isFinite) return null;
    return magnitude.abs() * sign;
  }

  void _enforceMissedOnlyOutcome() {
    if (!_hasEntryConditionsNoEntryLink) return;
    _result.clear();
    _resultSign = null;
    _showResultSignChoices = false;
    // A no-entry link changes the record into a missed setup, which is outside
    // the result/direction/market/mindset guided path.
    _guidedEntryActive = false;
    _guidedMindsetDraft = null;
    _guided.progress.clear();
    _autoEntryStep = _AutoEntryStep.idle;
    _guidedReconciliationRevision++;
    _activeNumericPad = null;
    _resultFocusNode.unfocus();
    _expectedLossFocusNode.unfocus();
    _reconcileClassification();
    _updateComputedFields();
  }

  void _selectResultSign(int sign) {
    if (_hasEntryConditionsNoEntryLink) return;
    final monitorGuidedEntry = _guidedEntryActive || _canStartGuidedEntry;
    setState(() {
      _resultKeyboardActionHandled = false;
      _expectedLossKeyboardActionHandled = false;
      // The sign is a real editable character in the amount field. Preserve
      // any digits when the user deletes a sign and chooses it again.
      final magnitudeText = _result.text.trim().replaceFirst(
        RegExp(r'^[+\-−]'),
        '',
      );
      final signCharacter = sign > 0 ? '+' : '−';
      final nextText = '$signCharacter$magnitudeText';
      _result.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: nextText.length),
      );
      _resultSign = sign;
      _showResultSignChoices = false;
      _guidedEntryActive = monitorGuidedEntry;
      if (monitorGuidedEntry) _activeFormSectionIndex = 0;
      _guidedReconciliationRevision++;
      _autoEntryStep = monitorGuidedEntry
          ? _AutoEntryStep.result
          : _AutoEntryStep.idle;
      _reconcileClassification();
      _updateComputedFields();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _activateNumericPad(_NumericEntryTarget.result);
    });
  }

  /// Opens the in-app numeric keypad for the selected amount field. The
  /// keypad is anchored to the bottom edge for comfortable one-handed use;
  /// TextFields remain read-only so Android never opens its own keyboard.
  void _activateNumericPad(_NumericEntryTarget target) {
    if (!mounted || _hasEntryConditionsNoEntryLink) return;
    if (target == _NumericEntryTarget.result && _resultSign == null) return;
    if (_guidedEntryActive &&
        target == _NumericEntryTarget.expectedLoss &&
        (_parseResult() ?? 0) < 0) {
      // A losing new trade skips planned loss in the guided sequence. Saved
      // trades remain manually editable, including their historical values.
      return;
    }
    final controller = target == _NumericEntryTarget.result
        ? _result
        : _expectedLoss;
    // Numeric entry is append-first: tapping anywhere in the read-only field
    // starts input at the end instead of inserting into an arbitrary position.
    controller.selection = TextSelection.collapsed(
      offset: controller.text.length,
    );
    setState(() {
      _activeNumericPad = target;
      if (_guidedEntryActive) {
        _autoEntryStep = target == _NumericEntryTarget.result
            ? _AutoEntryStep.result
            : _AutoEntryStep.expectedLoss;
      }
    });
    final focusNode = target == _NumericEntryTarget.result
        ? _resultFocusNode
        : _expectedLossFocusNode;
    focusNode.requestFocus();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _activeNumericPad != target) return;
      final fieldContext = (target == _NumericEntryTarget.result
              ? _resultFocusNode
              : _expectedLossFocusNode)
          .context;
      if (fieldContext != null) {
        Scrollable.ensureVisible(
          fieldContext,
          alignment: .55,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  void _dismissNumericPad({bool unfocus = true}) {
    if (_activeNumericPad == null) return;
    final active = _activeNumericPad;
    setState(() => _activeNumericPad = null);
    if (unfocus) {
      if (active == _NumericEntryTarget.result) {
        _resultFocusNode.unfocus();
      } else {
        _expectedLossFocusNode.unfocus();
      }
    }
  }

  TextEditingController? get _activeNumericController =>
      switch (_activeNumericPad) {
        _NumericEntryTarget.result => _result,
        _NumericEntryTarget.expectedLoss => _expectedLoss,
        null => null,
      };

  void _handleNumericKey(String key) {
    final controller = _activeNumericController;
    final target = _activeNumericPad;
    if (controller == null || target == null || !mounted) return;

    var text = controller.text;
    var selection = controller.selection;
    if (!selection.isValid) {
      selection = TextSelection.collapsed(offset: text.length);
    }
    final start = selection.start.clamp(0, text.length).toInt();
    final end = selection.end.clamp(0, text.length).toInt();

    if (key == 'clear') {
      // Keep the selected Profit/Loss sign while replacing its amount.
      final signPrefix = target == _NumericEntryTarget.result
          ? RegExp(r'^[+\-−]').stringMatch(text) ?? ''
          : '';
      text = signPrefix;
      selection = TextSelection.collapsed(offset: text.length);
    } else if (key == 'backspace') {
      if (start != end) {
        text = text.replaceRange(start, end, '');
        selection = TextSelection.collapsed(offset: start);
      } else if (start > 0) {
        text = text.replaceRange(start - 1, start, '');
        selection = TextSelection.collapsed(offset: start - 1);
      }
    } else {
      final decimal = _ar ? ',' : '.';
      final character = key == 'decimal' ? decimal : key;
      if (character == decimal || character == '.' || character == ',') {
        if (text.contains('.') || text.contains(',')) return;
        // Keep a leading decimal valid and easy to read after the sign.
        final magnitudeStart = target == _NumericEntryTarget.result &&
                RegExp(r'^[+\-−]').hasMatch(text)
            ? 1
            : 0;
        final existingMagnitude = text.substring(magnitudeStart);
        if (existingMagnitude.isEmpty) {
          final prefix = text.substring(0, magnitudeStart);
          text = '$prefix' '0$character';
          selection = TextSelection.collapsed(offset: text.length);
        } else {
          text = text.replaceRange(start, end, character);
          selection = TextSelection.collapsed(offset: start + character.length);
        }
      } else if (RegExp(r'^\d$').hasMatch(character)) {
        text = text.replaceRange(start, end, character);
        selection = TextSelection.collapsed(offset: start + character.length);
      } else {
        return;
      }
    }

    controller.value = TextEditingValue(text: text, selection: selection);
    if (target == _NumericEntryTarget.result) {
      _resultKeyboardActionHandled = false;
      _handleResultChanged(text);
    } else {
      _expectedLossKeyboardActionHandled = false;
      _handleExpectedLossChanged(text);
    }
    HapticFeedback.selectionClick();
  }

  void _changeResultSignFromPad() {
    if (_activeNumericPad != _NumericEntryTarget.result || _resultSign == null) {
      return;
    }
    final current = _result.text;
    final magnitude = current.replaceFirst(RegExp(r'^[+\-−]'), '');
    _result.value = TextEditingValue(
      text: magnitude,
      selection: TextSelection.collapsed(offset: magnitude.length),
    );
    _handleResultChanged(magnitude);
    _dismissNumericPad();
  }

  void _handleNumericPadContinue() {
    final active = _activeNumericPad;
    if (active == null) return;
    if (!_guidedEntryActive) {
      _dismissNumericPad();
      return;
    }
    if (active == _NumericEntryTarget.result) {
      _submitGuidedResultOnce();
    } else {
      _submitGuidedExpectedLossOnce();
    }
  }

  Widget _numericPadKey(
    String label,
    String value,
    TdTokens tokens, {
    bool muted = false,
    bool emphasized = false,
  }) {
    final foreground = emphasized ? tokens.text1 : tokens.text2;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: SizedBox(
          height: 45,
          child: Material(
            color: emphasized ? tokens.surface3 : tokens.surface2,
            borderRadius: BorderRadius.circular(11),
            child: InkWell(
              key: ValueKey('trade-numpad-key-$value'),
              borderRadius: BorderRadius.circular(11),
              onTap: () => _handleNumericKey(value),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(
                    color: tokens.lineSubtle.withValues(alpha: muted ? .50 : .78),
                    width: .75,
                  ),
                ),
                child: Text(
                  label,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: foreground,
                    fontSize: label.length > 1 ? 15 : 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNumericPad() {
    final tokens = TdTokens.of(context);
    final isResult = _activeNumericPad == _NumericEntryTarget.result;
    final fieldLabel = isResult
        ? _copy('الربح / الخسارة', 'Profit / loss')
        : _copy('الخسارة المتوقعة', 'Expected loss');
    final value = _activeNumericController?.text ?? '';
    final decimalLabel = _ar ? ',' : '.';
    return SafeArea(
      top: false,
      child: Material(
        key: const ValueKey('trade-custom-numeric-keypad'),
        color: tokens.surface1,
        elevation: 12,
        child: Container(
          decoration: BoxDecoration(
            color: tokens.surface1,
            border: Border(
              top: BorderSide(color: tokens.lineStrong.withValues(alpha: .72), width: .9),
            ),
            boxShadow: tokens.raisedShadows,
          ),
          padding: const EdgeInsets.fromLTRB(9, 8, 9, 7),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          fieldLabel,
                          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: tokens.text2,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 1),
                        Text(
                          value.isEmpty ? '—' : value,
                          key: const ValueKey('trade-numpad-current-value'),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.ltr,
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: tokens.text1,
                            fontWeight: FontWeight.w700,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    key: const ValueKey('trade-numpad-clear'),
                    onPressed: () => _handleNumericKey('clear'),
                    style: TextButton.styleFrom(
                      foregroundColor: tokens.text3,
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                    ),
                    icon: const Icon(Icons.backspace_outlined, size: 15),
                    label: Text(_copy('مسح', 'Clear')),
                  ),
                  if (isResult && _resultSign != null)
                    TextButton(
                      key: const ValueKey('trade-numpad-change-sign'),
                      onPressed: _changeResultSignFromPad,
                      style: TextButton.styleFrom(
                        foregroundColor: tokens.text2,
                        visualDensity: VisualDensity.compact,
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                      ),
                      child: Text(_copy('تغيير الإشارة', 'Change sign')),
                    ),
                  IconButton(
                    key: const ValueKey('trade-numpad-close'),
                    visualDensity: VisualDensity.compact,
                    tooltip: _copy('إخفاء لوحة الأرقام', 'Hide numeric keypad'),
                    onPressed: _dismissNumericPad,
                    icon: Icon(Icons.keyboard_hide_outlined, color: tokens.text3, size: 19),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final row in const [
                      ['1', '2', '3'],
                      ['4', '5', '6'],
                      ['7', '8', '9'],
                    ]) ...[
                      Row(
                        children: [
                          for (final digit in row)
                            _numericPadKey(digit, digit, tokens),
                        ],
                      ),
                      const SizedBox(height: 5),
                    ],
                    Row(
                      children: [
                        _numericPadKey(decimalLabel, 'decimal', tokens, muted: true),
                        _numericPadKey('0', '0', tokens),
                        _numericPadKey('⌫', 'backspace', tokens, muted: true),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 7),
              SizedBox(
                width: double.infinity,
                height: 43,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: tokens.primaryGradient,
                    borderRadius: BorderRadius.circular(11),
                    boxShadow: tokens.raisedShadows,
                  ),
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(11),
                    child: InkWell(
                      key: const ValueKey('trade-numpad-continue'),
                      borderRadius: BorderRadius.circular(11),
                      onTap: _handleNumericPadContinue,
                      child: Center(
                        child: Text(
                          _copy('متابعة', 'Continue'),
                          style: Theme.of(context).textTheme.labelLarge?.copyWith(
                            color: tokens.text1,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleResultChanged(String value) {
    final trimmed = value.trimLeft();
    final nextSign = trimmed.startsWith('+')
        ? 1
        : (trimmed.startsWith('-') || trimmed.startsWith('−'))
            ? -1
            : null;
    setState(() {
      _resultKeyboardActionHandled = false;
      _resultSign = nextSign;
      // Editing the result moves the live guide back to this field while the
      // trader uses the in-app keypad. Continue validates before advancing.
      if (_guidedEntryActive) _autoEntryStep = _AutoEntryStep.result;
      // Removing the sign leaves the magnitude intact and makes the sign
      // chooser available again; the trader can then select + or − anew.
      _showResultSignChoices = nextSign == null &&
          !_hasEntryConditionsNoEntryLink;
      _reconcileClassification();
      _updateComputedFields();
    });
    if (nextSign == null) {
      // Close the in-app keypad after the sign is removed so the sign
      // choices can be selected cleanly from the field decoration.
      _resultFocusNode.unfocus();
    }
  }

  void _handleExpectedLossChanged(String _) {
    _expectedLossKeyboardActionHandled = false;
    setState(() {
      // A planned-loss correction on a winning trade becomes the current
      // guided item until the trader confirms it with the keypad Continue key.
      if (_guidedEntryActive && _resultSign == 1) {
        _autoEntryStep = _AutoEntryStep.expectedLoss;
      }
      _updateComputedFields();
    });
  }

  // The onEditingComplete / onFieldSubmitted callbacks are retained as a
  // defensive fallback for accessibility or platform-driven submission. The
  // in-app Continue button uses the same guarded handlers. The next step is
  // always derived from current form state, never default focus traversal.
  void _submitGuidedResultOnce() {
    if (!_shouldGuideResult || _resultKeyboardActionHandled) return;
    _resultKeyboardActionHandled = true;
    _continueAfterResult();
  }

  void _handleResultEditingComplete() {
    if (_shouldGuideResult) {
      _submitGuidedResultOnce();
      return;
    }
    _resultFocusNode.unfocus();
  }

  void _handleResultSubmitted(String _) => _submitGuidedResultOnce();

  void _submitGuidedExpectedLossOnce() {
    if (!_shouldGuideExpectedLoss || _expectedLossKeyboardActionHandled) {
      return;
    }
    _expectedLossKeyboardActionHandled = true;
    _continueAfterExpectedLoss();
  }

  void _handleExpectedLossEditingComplete() {
    if (_shouldGuideExpectedLoss) {
      _submitGuidedExpectedLossOnce();
      return;
    }
    _expectedLossFocusNode.unfocus();
  }

  void _handleExpectedLossSubmitted(String _) =>
      _submitGuidedExpectedLossOnce();

  Future<void> _continueAfterResult() async {
    if (!_shouldGuideResult) return;
    final validation = _resultValidator(_result.text);
    if (validation != null) {
      _showValidationMessage(validation);
      _resultFocusNode.requestFocus();
      return;
    }
    await _advanceGuidedEntry();
  }

  Future<void> _continueAfterExpectedLoss() async {
    if (!_shouldGuideExpectedLoss) return;
    final validation = _expectedLossValidator(_expectedLoss.text);
    if (validation != null) {
      _showValidationMessage(validation);
      _expectedLossFocusNode.requestFocus();
      return;
    }
    await _advanceGuidedEntry();
  }

  Future<void> _advanceGuidedEntry() async {
    if (!mounted || !_guidedEntryActive) return;
    final next = _nextIncompleteGuidedStep;
    setState(() {
      _autoEntryStep = next;
      if (next != _AutoEntryStep.idle) {
        _activeFormSectionIndex = _formSectionIndexForGuidedStep(next);
      }
      _activeNumericPad = switch (next) {
        _AutoEntryStep.result => _NumericEntryTarget.result,
        _AutoEntryStep.expectedLoss => _NumericEntryTarget.expectedLoss,
        _ => null,
      };
    });
    switch (next) {
      case _AutoEntryStep.result:
        _expectedLossFocusNode.unfocus();
        _resultFocusNode.requestFocus();
        break;
      case _AutoEntryStep.expectedLoss:
        _resultFocusNode.unfocus();
        _expectedLoss.selection = TextSelection.collapsed(
          offset: _expectedLoss.text.length,
        );
        _expectedLossFocusNode.requestFocus();
        break;
      case _AutoEntryStep.direction:
        _resultFocusNode.unfocus();
        _expectedLossFocusNode.unfocus();
        await _openAutoDirectionPopup();
        break;
      case _AutoEntryStep.market:
        _resultFocusNode.unfocus();
        _expectedLossFocusNode.unfocus();
        await _openAutoMarketPopup();
        break;
      case _AutoEntryStep.mindset:
        _resultFocusNode.unfocus();
        _expectedLossFocusNode.unfocus();
        await _openAutoMindsetDialog();
        break;
      case _AutoEntryStep.entryReason:
      case _AutoEntryStep.anchors:
      case _AutoEntryStep.confirmation:
      case _AutoEntryStep.exitReason:
      case _AutoEntryStep.reverseSignals:
      case _AutoEntryStep.bounceZone:
        _resultFocusNode.unfocus();
        _expectedLossFocusNode.unfocus();
        await _runGuidedSection(next);
        break;
      case _AutoEntryStep.idle:
        // The current sequence is complete, but monitoring remains active so
        // later edits or cleared selections can be reconciled automatically.
        setState(() => _autoEntryStep = _AutoEntryStep.idle);
        break;
    }
  }

  GlobalKey _guidedSectionAnchorKey(_AutoEntryStep step) => switch (step) {
        _AutoEntryStep.entryReason => _entryReasonSectionKey,
        _AutoEntryStep.anchors => _anchorMenuAnchorKey,
        _AutoEntryStep.confirmation => _confirmationSectionKey,
        _AutoEntryStep.reverseSignals => _reverseSignalSectionKey,
        _AutoEntryStep.bounceZone => _bounceZoneSectionKey,
        _ => _exitReasonSectionKey,
      };

  /// Opens the list of a guided section and keeps reopening it after every
  /// added item until the trader presses Continue. Dismissing the list is a
  /// pause: the step stays pending and tapping the same field resumes it.
  Future<void> _runGuidedSection(_AutoEntryStep step) async {
    if (_guidedSectionRunning) return;
    final continued = await _guidedSectionLoop(step);
    if (!continued || !mounted || !_guidedEntryActive) return;
    _guided.continuePressed(_guidedSnapshot(), step);
    await _advanceGuidedEntry();
  }

  Future<bool> _guidedSectionLoop(_AutoEntryStep step) async {
    _guidedSectionRunning = true;
    try {
      await _prepareAutoPopup(_guidedSectionAnchorKey(step));
      var outcome = _GuidedListOutcome.again;
      while (outcome == _GuidedListOutcome.again &&
          mounted &&
          _guidedEntryActive &&
          _autoEntryStep == step) {
        outcome = await _openGuidedSectionList(step);
      }
      return mounted && outcome == _GuidedListOutcome.continued;
    } finally {
      _guidedSectionRunning = false;
    }
  }

  Future<_GuidedListOutcome> _openGuidedSectionList(_AutoEntryStep step) =>
      switch (step) {
        _AutoEntryStep.entryReason => _entryReasonRound(guided: true),
        _AutoEntryStep.anchors => _guidedAnchorsRound(),
        _AutoEntryStep.confirmation => _confirmationRound(guided: true),
        _AutoEntryStep.reverseSignals => _reverseSignalRound(guided: true),
        _AutoEntryStep.bounceZone => _bounceZoneRound(guided: true),
        _ => _exitReasonRound(guided: true),
      };

  // One round of a section list: item list (checks on selected items) ->
  // timeframe list (checks on selected timeframes) -> toggle that pair. The
  // same round serves the manual "add" tap and the guided flow; only the
  // guided flow shows the Continue button and reopens the list afterwards.
  Future<_GuidedListOutcome> _entryReasonRound({bool guided = false}) async {
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    final reason = await _showEntryReasonSheet(guided: guided);
    if (!mounted || reason == null) return _GuidedListOutcome.paused;
    if (reason == _guidedContinueValue) return _GuidedListOutcome.continued;
    if (reason == _guidedRetryValue) return _GuidedListOutcome.again;
    final key = tradeEntryReasonSelectionKey(reason);
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '${_copy('سبب الدخول', 'Entry reason')} · ${formatTradeEntryReasonLabel(reason: reason, side: _side)}',
      selectedFrames: {
        for (final setup in _entrySetups)
          if (tradeEntryReasonSelectionKey(setup.reason) == key)
            setup.timeframe,
      },
    );
    if (!mounted) return _GuidedListOutcome.paused;
    if (timeframe == null) return _GuidedListOutcome.again;
    _toggleEntrySetup(reason, timeframe);
    return _GuidedListOutcome.again;
  }

  Future<_GuidedListOutcome> _guidedAnchorsRound() async {
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    final continued = await _showAnchorsDialog(guided: true);
    return continued && mounted
        ? _GuidedListOutcome.continued
        : _GuidedListOutcome.paused;
  }

  Future<_GuidedListOutcome> _confirmationRound({bool guided = false}) async {
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    final type = await _showChoiceSheet(
      title: _copy('تأكيد الدخول', 'Entry confirmation'),
      options: tradeConfirmationOptions,
      centered: true,
      guidedContinue: guided,
      selectedKeys: {
        for (final setup in _confirmationSetups)
          tradeConfirmationSelectionKey(setup.type),
      },
    );
    if (!mounted || type == null) return _GuidedListOutcome.paused;
    if (type == _guidedContinueValue) return _GuidedListOutcome.continued;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog();
      if (!mounted) return _GuidedListOutcome.paused;
      if (custom == null) return _GuidedListOutcome.again;
      finalType = custom;
    }
    final key = tradeConfirmationSelectionKey(finalType);
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '${_copy('تأكيد الدخول', 'Entry confirmation')} · ${_confirmationLabel(finalType)}',
      selectedFrames: {
        for (final setup in _confirmationSetups)
          if (tradeConfirmationSelectionKey(setup.type) == key)
            setup.timeframe,
      },
    );
    if (!mounted) return _GuidedListOutcome.paused;
    if (timeframe == null) return _GuidedListOutcome.again;
    _toggleConfirmationSetup(finalType, timeframe);
    return _GuidedListOutcome.again;
  }

  Future<_GuidedListOutcome> _exitReasonRound({bool guided = false}) async {
    final title = _exitSectionTitle;
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    // No exit rectangle for this outcome: nothing to pick, just move on.
    if (title == null) return _GuidedListOutcome.continued;
    final type = await _showChoiceSheet(
      title: title,
      options: tradeExitReasonOptions,
      centered: true,
      guidedContinue: guided,
      selectedKeys: {
        for (final setup in _exitReasonSetups)
          tradeExitReasonSelectionKey(setup.type),
      },
    );
    if (!mounted || type == null) return _GuidedListOutcome.paused;
    if (type == _guidedContinueValue) return _GuidedListOutcome.continued;
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '$title · ${tradeExitReasonLabel(type, arabic: _ar, side: _side)}',
      selectedFrames: {
        for (final setup in _exitReasonSetups)
          if (tradeExitReasonSelectionKey(setup.type) == type)
            setup.timeframe,
      },
    );
    if (!mounted) return _GuidedListOutcome.paused;
    if (timeframe == null) return _GuidedListOutcome.again;
    _toggleExitReasonSetup(type, timeframe);
    return _GuidedListOutcome.again;
  }

  // Opposing signals and Bounce area are optional, like Anchors: the guide
  // just needs the trader to pass through and press Continue, with no
  // minimum number of selected items.
  Future<_GuidedListOutcome> _reverseSignalRound({bool guided = false}) async {
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    final setup = await _showEntryConditionSetup(
      title: _copy('إشارات عكسية', 'Opposing signals'),
      categoryLabel: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
      choiceTone: _currentReverseSignalTone,
      guided: guided,
      selectedKeys: {
        for (final item in _reverseSignalSetups)
          tradeBounceZoneMenuKey(item.optionKey),
      },
    );
    if (!mounted || setup == null) return _GuidedListOutcome.paused;
    if (setup.optionKey == _guidedContinueValue) {
      return _GuidedListOutcome.continued;
    }
    setState(() {
      if (!_reverseSignalSetups.contains(setup)) {
        _reverseSignalSetups.add(setup);
      }
    });
    return _GuidedListOutcome.again;
  }

  Future<_GuidedListOutcome> _bounceZoneRound({bool guided = false}) async {
    if (!_hasTradeDirection) return _GuidedListOutcome.paused;
    final setup = await _showEntryConditionSetup(
      title: _copy('منطقة الارتداد', 'Bounce area'),
      categoryLabel: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
      choiceTone: _entryConditionsTone,
      guided: guided,
      selectedKeys: {
        for (final item in _bounceZoneSetups)
          tradeBounceZoneMenuKey(item.optionKey),
      },
    );
    if (!mounted || setup == null) return _GuidedListOutcome.paused;
    if (setup.optionKey == _guidedContinueValue) {
      return _GuidedListOutcome.continued;
    }
    setState(() {
      if (!_bounceZoneSetups.contains(setup)) _bounceZoneSetups.add(setup);
    });
    return _GuidedListOutcome.again;
  }

  // Picking an already-selected (item, timeframe) pair removes it; any other
  // timeframe adds the same item again with that timeframe.
  void _toggleEntrySetup(String reason, String timeframe) {
    final key = tradeEntryReasonSelectionKey(reason);
    final index = _entrySetups.indexWhere((setup) =>
        setup.timeframe == timeframe &&
        tradeEntryReasonSelectionKey(setup.reason) == key);
    if (index < 0) {
      _appendEntrySetup(reason, timeframe);
    } else {
      setState(() => _entrySetups.removeAt(index));
    }
  }

  void _toggleConfirmationSetup(String type, String timeframe) {
    final key = tradeConfirmationSelectionKey(type);
    final index = _confirmationSetups.indexWhere((setup) =>
        setup.timeframe == timeframe &&
        tradeConfirmationSelectionKey(setup.type) == key);
    if (index < 0) {
      _appendConfirmationSetup(type, timeframe);
    } else {
      setState(() => _confirmationSetups.removeAt(index));
    }
  }

  void _toggleExitReasonSetup(String type, String timeframe) {
    final index = _exitReasonSetups.indexWhere((setup) =>
        setup.timeframe == timeframe &&
        tradeExitReasonSelectionKey(setup.type) == type);
    if (index < 0) {
      _appendExitReasonSetup(type, timeframe);
    } else {
      setState(() => _exitReasonSetups.removeAt(index));
    }
  }

  /// Records which areas currently hold data. Runs from build, i.e. after every
  /// change of the form, so no add/remove/edit path can bypass the monitoring.
  void _trackFilledGuidedSections() => _guided.observe(_guidedSnapshot());

  /// The first incomplete item for a trader acting in [intent], looked at live
  /// from the current data (see GuidedEntryEngine.missingFor).
  _AutoEntryStep? _firstMissingGuidedField(_AutoEntryStep intent) =>
      GuidedEntryEngine.missingFor(_guidedSnapshot(), _guided.progress, intent)
          .firstOrNull;

  /// Returns true when missing information was found and the guide took over.
  /// The section the trader asked for is re-queued so it opens right after the
  /// missing information has been completed.
  bool _redirectToMissingGuidedField(_AutoEntryStep intent) {
    final snapshot = _guidedSnapshot();
    if (_guided.planTap(snapshot, intent).mode == GuidedTapMode.none) {
      return false;
    }
    _guided.applyImmediate(snapshot, intent);
    _guidedReconciliationRevision++;
    _advanceGuidedEntry();
    return true;
  }

  /// Same detection as [_redirectToMissingGuidedField], for a selection made
  /// outside the six guided sections — Decisions, Commitment, or No-entry
  /// reasons. _AutoEntryStep.idle is just a placeholder here.
  bool _redirectToMissingGuidedFieldAnywhere() =>
      _redirectToMissingGuidedField(_AutoEntryStep.idle);

  /// Entry point of every manual tap/edit in the six guided sections. Returns
  /// true when the tap was fully handled here.
  ///  * A required/basic item is missing: the guide takes over immediately.
  ///  * An optional area was emptied: the requested list still opens, with the
  ///    Continue button and reopening after every pick. The button is the
  ///    sign that another area became incomplete; it takes the trader to that
  ///    area, and afterwards the requested list is reopened with the earlier
  ///    picks intact.
  Future<bool> _guideThroughMissing(_AutoEntryStep intent) async {
    final plan = _guided.planTap(_guidedSnapshot(), intent);
    if (plan.mode == GuidedTapMode.none) return false;
    if (plan.mode == GuidedTapMode.immediate || _guidedSectionRunning) {
      return _redirectToMissingGuidedField(intent);
    }
    _guidedSectionRunning = true;
    var outcome = _GuidedListOutcome.again;
    try {
      while (outcome == _GuidedListOutcome.again &&
          mounted &&
          _guidedEntryActive) {
        outcome = await _openGuidedSectionList(intent);
      }
    } finally {
      _guidedSectionRunning = false;
    }
    if (!mounted || !_guidedEntryActive) return true;
    if (outcome != _GuidedListOutcome.continued) return true;
    final target = _guided.applyDeferredContinue(_guidedSnapshot(), intent);
    if (target == _AutoEntryStep.idle) return true;
    _guidedReconciliationRevision++;
    await _advanceGuidedEntry();
    await _resumeInterruptedSection();
    return true;
  }

  /// After the missing areas were completed, reopens the list the trader was
  /// working in when the gap was found.
  Future<void> _resumeInterruptedSection() async {
    if (!mounted || !_guidedEntryActive) return;
    final target = _guided.takeResume(_guidedSnapshot());
    if (target == null) return;
    switch (target) {
      case _AutoEntryStep.entryReason:
        await _addEntrySetup();
      case _AutoEntryStep.anchors:
        await _pickAnchors();
      case _AutoEntryStep.confirmation:
        await _addConfirmationSetup();
      case _AutoEntryStep.exitReason:
        await _addExitReasonSetup();
      case _AutoEntryStep.reverseSignals:
        await _addReverseSignalSetup();
      case _AutoEntryStep.bounceZone:
        await _addBounceZoneSetup();
      default:
        break;
    }
  }

  Set<String> _anchorEquivalentKeys(String optionKey) => switch (optionKey) {
        'zoneSd' => {'zoneSd', 'supplyZone', 'demandZone'},
        'engulfing' => {'engulfing', 'bullishEngulfing', 'bearishEngulfing'},
        _ => {optionKey},
      };

  List<String> _anchorFrames(String anchorKey) =>
      splitAnchorTimeframes(_anchorTimeframes[anchorKey]);

  void _toggleAnchorFrame(String optionKey, String storageKey, String frame) {
    final frames = _anchorFrames(storageKey).toList();
    if (!frames.remove(frame)) frames.add(frame);
    final equivalent = _anchorEquivalentKeys(optionKey);
    setState(() {
      _anchors.removeAll(equivalent);
      for (final key in equivalent) {
        _anchorTimeframes.remove(key);
      }
      final joined = joinAnchorTimeframes(frames);
      if (joined != null) {
        _anchors.add(optionKey);
        _anchorTimeframes[optionKey] = joined;
      }
    });
  }

  List<({String key, String? frame})> _anchorEntries(List<String> keys) => [
        for (final key in keys)
          if (_anchorFrames(key).isEmpty)
            (key: key, frame: null)
          else
            for (final frame in _anchorFrames(key)) (key: key, frame: frame),
      ];

  String _anchorEntryId(({String key, String? frame}) entry) {
    final frames = _anchorFrames(entry.key);
    return entry.frame == null || frames.isEmpty || frames.first == entry.frame
        ? entry.key
        : '${entry.key}-${entry.frame}';
  }

  /// Compact Continue button shown at the bottom of guided section lists. It
  /// reuses the gradient, radius and label style of the numeric-pad Continue
  /// key so the two read as the same control.
  Widget _guidedContinueButton({
    required TdTokens tokens,
    required VoidCallback onTap,
  }) =>
      Align(
        alignment: AlignmentDirectional.centerEnd,
        child: SizedBox(
          height: 36,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: tokens.primaryGradient,
              borderRadius: BorderRadius.circular(11),
              boxShadow: tokens.raisedShadows,
            ),
            child: Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(11),
              child: InkWell(
                key: const ValueKey('trade-guided-continue'),
                borderRadius: BorderRadius.circular(11),
                onTap: onTap,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _copy('متابعة', 'Continue'),
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: tokens.text1,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(
                        Icons.arrow_forward_rounded,
                        size: 15,
                        color: tokens.text1,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );

  void _appendEntrySetup(String reason, String timeframe) {
    setState(() {
      if (!_hasEquivalentEntrySetup(reason, timeframe)) {
        _entrySetups.add(TradeEntrySetup(reason: reason, timeframe: timeframe));
      }
    });
  }

  void _appendConfirmationSetup(String type, String timeframe) {
    setState(() {
      if (!_confirmationSetups.any((item) =>
          tradeConfirmationSelectionKey(item.type) ==
              tradeConfirmationSelectionKey(type) &&
          item.timeframe == timeframe)) {
        _confirmationSetups
            .add(TradeConfirmationSetup(type: type, timeframe: timeframe));
      }
    });
  }

  void _appendExitReasonSetup(String type, String timeframe) {
    setState(() {
      if (!_exitReasonSetups.any(
        (item) =>
            tradeExitReasonSelectionKey(item.type) == type &&
            item.timeframe == timeframe,
      )) {
        _exitReasonSetups.add(
          TradeConfirmationSetup(type: type, timeframe: timeframe),
        );
      }
    });
  }

  Future<void> _prepareAutoPopup(GlobalKey anchorKey) async {
    await Future<void>.delayed(const Duration(milliseconds: 180));
    if (!mounted) return;
    final anchorContext = anchorKey.currentContext;
    if (anchorContext != null) {
      await Scrollable.ensureVisible(
        anchorContext,
        alignment: .55,
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOutCubic,
      );
    }
    await Future<void>.delayed(const Duration(milliseconds: 90));
  }

  Future<void> _openAutoDirectionPopup() async {
    await _prepareAutoPopup(_directionPopupAnchorKey);
    if (!mounted || _autoEntryStep != _AutoEntryStep.direction) return;
    await _showCompactPopupChoice<TradeSide>(
      anchorKey: _directionPopupAnchorKey,
      values: TradeSide.values,
      itemKeyPrefix: 'trade-direction-option',
      selectedValue: _side,
      labelFor: (value) => tr(
        context,
        value == TradeSide.buy ? 'buy' : 'sell',
      ),
      minMenuWidth: _shortChoiceMenuWidth,
      onSelected: _handleDirectionSelected,
    );
    // A dismissed popup is a pause, not completion. Keep Direction pending so
    // reopening the same field resumes the guided sequence.
  }

  void _handleDirectionSelected(TradeSide value) {
    setState(() {
      // Preserve the existing tap-again-to-clear behavior. The live resolver
      // then detects that Direction is incomplete and routes back to it.
      _side = _side == value ? null : value;
    });
    _reconcileGuidedEntryAfterChange();
  }

  Future<void> _openAutoMarketPopup() async {
    await _prepareAutoPopup(_marketPopupAnchorKey);
    if (!mounted || _autoEntryStep != _AutoEntryStep.market) return;
    await _showCompactPopupChoice<String>(
      anchorKey: _marketPopupAnchorKey,
      values: const ['NQ', 'ES', 'GC'],
      itemKeyPrefix: 'trade-market-option',
      selectedValue: _symbol,
      labelFor: (value) => value,
      minMenuWidth: _shortChoiceMenuWidth,
      onSelected: _handleMarketSelected,
    );
    // Keep Market pending when the popup is dismissed without a selection.
  }

  void _handleMarketSelected(String value) {
    setState(() => _symbol = value);
    // Re-check every required value, not just the Market step. For example,
    // changing Market while Mindset is empty routes directly to Mindset.
    _reconcileGuidedEntryAfterChange();
  }

  Future<void> _openAutoMindsetDialog() async {
    await Future<void>.delayed(const Duration(milliseconds: 160));
    if (!mounted || _autoEntryStep != _AutoEntryStep.mindset) return;
    await _showMindsetMultiSelect();
    // Dismissing the dialog leaves Mindset pending. Reopening the field lets
    // the trader resume and explicitly finish the multi-select step.
  }

  List<String> get _orderedMoodKeys => tradeMoodOptions
      .where((item) => _selectedMoods.contains(item.key))
      .map((item) => item.key)
      .toList(growable: false);

  Future<void> _showMindsetMultiSelect() async {
    // Opening a completed field for manual correction no longer disables live
    // monitoring. Keep a dialog draft while guidance is active so dismissing
    // the overlay does not silently lose unconfirmed checkbox changes.
    final keepGuidedDraft = _guidedEntryActive;
    final draft = {
      ...(keepGuidedDraft
          ? (_guidedMindsetDraft ?? _selectedMoods)
          : _selectedMoods),
    };
    final selected = await showDialog<Set<String>>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        final tokens = TdTokens.of(dialogContext);
        return StatefulBuilder(
          builder: (context, setDialogState) => Dialog(
            key: const ValueKey('trade-mood-multi-select-dialog'),
            backgroundColor: tdPopupMenuColor(Theme.of(context).brightness),
            surfaceTintColor: Colors.transparent,
            elevation: 9,
            shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness),
            insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: 340,
                maxHeight: MediaQuery.sizeOf(context).height * .72,
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(
                        _copy('الحالة النفسية', 'Mindset'),
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: tokens.text1,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(height: 5),
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(
                        _copy('يمكنك اختيار أكثر من حالة', 'Choose more than one state'),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: tokens.text2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Divider(height: 1, color: tokens.lineSubtle),
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        children: [
                          for (final item in tradeMoodOptions)
                            CheckboxListTile(
                              key: ValueKey('trade-mood-option-${item.key}'),
                              value: draft.contains(item.key),
                              dense: true,
                              visualDensity: VisualDensity.compact,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 5),
                              controlAffinity: ListTileControlAffinity.leading,
                              activeColor: tokens.accent,
                              title: Text(
                                _ar ? item.ar : item.en,
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: draft.contains(item.key) ? tokens.text1 : tokens.text2,
                                  fontSize: _tradeDataItemFontSize,
                                  fontWeight: draft.contains(item.key) ? FontWeight.w700 : FontWeight.w500,
                                ),
                              ),
                              onChanged: (checked) {
                                setDialogState(() {
                                  if (item.key == 'moodUnknown') {
                                    if (checked == true) {
                                      draft
                                        ..clear()
                                        ..add(item.key);
                                    } else {
                                      draft.remove(item.key);
                                    }
                                  } else {
                                    draft.remove('moodUnknown');
                                    if (checked == true) {
                                      draft.add(item.key);
                                    } else {
                                      draft.remove(item.key);
                                    }
                                  }
                                });
                                // Keep unconfirmed multi-select choices when
                                // the user dismisses the dialog and resumes.
                                if (keepGuidedDraft) {
                                  _guidedMindsetDraft = {...draft};
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(
                            dialogContext,
                            <String>{_mindsetDialogCancelSentinel},
                          ),
                          child: Text(tr(context, 'cancel')),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          key: const ValueKey('trade-mood-multi-select-done'),
                          onPressed: () => Navigator.pop(
                            dialogContext,
                            draft.isEmpty ? <String>{'moodUnknown'} : {...draft},
                          ),
                          child: Text(_copy('تم', 'Done')),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    if (!mounted) return;
    if (selected != null) {
      if (selected.contains(_mindsetDialogCancelSentinel)) {
        if (keepGuidedDraft) _guidedMindsetDraft = null;
        return;
      }
      setState(() {
        _selectedMoods = selected.isEmpty
            ? <String>{'moodUnknown'}
            : selected;
        if (keepGuidedDraft) _guidedMindsetDraft = null;
      });
      // If the trader confirms an empty Mindset, leave that field pending but
      // do not trap them by immediately reopening the same dialog. Any later
      // edit in Direction/Market/another guided field will route back here.
      _reconcileGuidedEntryAfterChange(
        deferIfMindsetRemainsEmpty: true,
      );
    }
  }

  String? _resultValidator(String? value) {
    if (_hasEntryConditionsNoEntryLink) return null;
    final raw = value?.trim() ?? '';
    if (raw.isEmpty) {
      return _resultSign == null ? null : tr(context, 'requiredField');
    }
    final hasSign = raw.startsWith('+') ||
        raw.startsWith('-') ||
        raw.startsWith('−');
    if (!hasSign) {
      return _copy(
        'اختر موجب أو سالب أولاً.',
        'Choose + or − before entering the amount.',
      );
    }
    final magnitudeText = raw.substring(1).trim();
    if (magnitudeText.isEmpty) return tr(context, 'requiredField');
    final invalid = _number(magnitudeText, min: 0);
    if (invalid != null) return invalid;
    final magnitude =
        double.tryParse(magnitudeText.replaceAll(',', '.')) ?? 0;
    if (magnitude == 0) return tr(context, 'invalidNumber');
    return null;
  }

  TradingAccount? get _account {
    final app = AppScope.of(context);
    for (final item in app.accounts) {
      if (item.id == _accountId) return item;
    }
    return app.accounts.firstOrNull;
  }

  double _accountBalanceBeforeTrade(AppController app) {
    TradingAccount? account;
    for (final candidate in app.accounts) {
      if (candidate.id == _accountId) {
        account = candidate;
        break;
      }
    }
    if (account == null) return 0;
    final selectedAccount = account;
    return app.trades
        .where((trade) => trade.accountId == selectedAccount.id &&
            trade.id != widget.trade?.id && trade.isExecuted &&
            trade.tradedAt.isBefore(_tradedAt))
        .fold<double>(selectedAccount.startingBalance, (balance, trade) {
      final next = balance + trade.result;
      return next.isFinite ? next : balance;
    });
  }

  void _updateComputedFields() {
    final app = AppScope.of(context);
    final balance = _accountBalanceBeforeTrade(app);
    var parsedLoss = _parse(_expectedLoss);
    final result = _parseResult();
    final isLosingResult = result != null && result < 0;
    if (isLosingResult &&
        _expectedLoss.text.trim().isNotEmpty &&
        (widget.trade == null ||
            parsedLoss == null ||
            !parsedLoss.isFinite ||
            parsedLoss < 0)) {
      _expectedLoss.clear();
      parsedLoss = null;
    }
    final recordedLoss = parsedLoss != null &&
            parsedLoss.isFinite &&
            parsedLoss >= 0
        ? parsedLoss
        : null;
    // For a losing trade with no previously recorded planned risk, use the
    // realized loss as the risk amount for derived percentages and R-multiple.
    // It is not added to the trade result or stored as a second cash loss.
    final loss = isLosingResult &&
            (recordedLoss == null || recordedLoss == 0)
        ? result!.abs()
        : recordedLoss;
    final risk = loss == null || loss < 0
        ? null
        : loss == 0
            ? 0.0
            : balance > 0
                ? loss / balance * 100
                : null;
    _risk.text = risk != null && risk.isFinite ? risk.toStringAsFixed(2) : '';
    _rewardRisk.text = loss != null && loss > 0 && result != null && result.isFinite
        ? (result / loss).toStringAsFixed(2)
        : '';
  }

  String _formattedTradeDateTime(BuildContext context) {
    final localTradeTime = _tradedAt.toLocal();
    final time = TimeOfDay.fromDateTime(localTradeTime).format(context);
    return '${shortDate(localTradeTime)} · $time';
  }

  Future<void> _pickDateTime() async {
    if (!_hasTradeDirection) return;
    final date = await showDatePicker(
      context: context,
      initialDate: _tradedAt,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_tradedAt));
    if (time == null || !mounted) return;
    setState(() {
      _tradedAt = DateTime(date.year, date.month, date.day, time.hour, time.minute);
      _updateComputedFields();
    });
  }

  Future<void> _pickImage(_TradeImageSlot slot) async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 92);
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final saved = await AppScope.of(context).persistImage(picked.path);
      if (!mounted) return;
      setState(() {
        switch (slot) {
          case _TradeImageSlot.before:
            _beforePath = saved;
          case _TradeImageSlot.after:
            _afterPath = saved;
          case _TradeImageSlot.confirmation:
            _confirmationImagePath = saved;
        }
        _busy = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  /// Shows centered choices in the shared popup style. Standard selectors keep
  /// the established blue surface; semantic selectors can inherit their
  /// category tone for a continuous visual state. Long catalogs scroll inside
  /// the dialog without stretching it across the screen.
  Future<T?> _showCenteredTradeChoiceDialog<T>({
    required String title,
    String? subtitle,
    required List<({String label, T value})> options,
    required String keyPrefix,
    T? selectedValue,
    List<Key?>? optionKeys,
    Color? accentTone,
    T? continueValue,
    Set<T>? selectedValues,
  }) =>
      showDialog<T>(
        context: context,
        barrierDismissible: true,
        builder: (dialogContext) {
          final brightness = Theme.of(dialogContext).brightness;
          final tokens = TdTokens.of(dialogContext);
          final isDark = brightness == Brightness.dark;
          final semanticAccent = accentTone ?? tokens.accent;
          // Preserve the original contextual surfaces for Entry Conditions:
          // opposing-signal and bounce pickers inherit their semantic tone,
          // while ordinary Trade Data selectors retain the shared blue surface.
          final dialogBorderColor = accentTone == null
              ? tdTradeDataPopupMenuBorderColor(brightness)
              : accentTone.withValues(alpha: isDark ? .17 : .13);
          final dialogSurfaceColor = accentTone == null
              ? tdPopupMenuColor(brightness)
              : _entryConditionsSurface(
                  tokens: tokens,
                  tone: accentTone,
                  brightness: brightness,
                );
          final screen = MediaQuery.sizeOf(dialogContext);
          final dialogWidth =
              (screen.width - 56).clamp(240.0, 360.0).toDouble();
          final dialogMaxHeight =
              (screen.height * .68).clamp(160.0, 560.0).toDouble();

          return Dialog(
            key: ValueKey('trade-centered-choice-$keyPrefix'),
            backgroundColor: dialogSurfaceColor,
            surfaceTintColor: Colors.transparent,
            elevation: 9,
            shape: accentTone == null
                ? tdTradeDataPopupMenuShape(brightness)
                : RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: dialogBorderColor, width: .8),
                  ),
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            child: SizedBox(
              width: dialogWidth,
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: dialogMaxHeight),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              title,
                              textAlign: TextAlign.start,
                              style: Theme.of(dialogContext)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                    color: tokens.text1,
                                    fontWeight: FontWeight.w800,
                                  ),
                            ),
                            if (subtitle != null &&
                                subtitle.trim().isNotEmpty) ...[
                              const SizedBox(height: 4),
                              Text(
                                subtitle,
                                textAlign: TextAlign.start,
                                softWrap: true,
                                style: Theme.of(dialogContext)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: tokens.text2,
                                      fontWeight: FontWeight.w600,
                                      height: 1.25,
                                    ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      Divider(
                        height: 1,
                        color: accentTone == null
                            ? tdTradeDataPopupMenuBorderColor(brightness)
                                .withValues(alpha: .48)
                            : dialogBorderColor.withValues(alpha: .56),
                      ),
                      const SizedBox(height: 5),
                      Flexible(
                        child: ListView.separated(
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          itemCount: options.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: 2),
                          itemBuilder: (itemContext, index) {
                            final option = options[index];
                            final isSelected = option.value == selectedValue ||
                                (selectedValues?.contains(option.value) ?? false);
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 1),
                              child: ListTile(
                                key: optionKeys != null && index < optionKeys.length
                                    ? optionKeys[index]
                                    : ValueKey('$keyPrefix-option-$index'),
                                minTileHeight: 48,
                                minVerticalPadding: 8,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 11,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                selected: isSelected,
                                selectedTileColor:
                                    semanticAccent.withValues(
                                      alpha: accentTone == null
                                          ? .09
                                          : isDark
                                              ? .16
                                              : .10,
                                    ),
                                title: Text(
                                  option.label,
                                  softWrap: true,
                                  style: Theme.of(itemContext)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        color: tokens.text1,
                                        fontSize: _tradeDataItemFontSize,
                                        fontWeight: isSelected
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                      ),
                                ),
                                trailing: Icon(
                                  isSelected
                                      ? Icons.check_circle_rounded
                                      : Icons.chevron_left_rounded,
                                  size: 18,
                                  color: isSelected
                                      ? semanticAccent
                                      : tokens.text3,
                                ),
                                onTap: () =>
                                    Navigator.pop(dialogContext, option.value),
                              ),
                            );
                          },
                        ),
                      ),
                      if (continueValue != null) ...[
                        const SizedBox(height: 8),
                        Divider(
                          height: 1,
                          color: accentTone == null
                              ? tdTradeDataPopupMenuBorderColor(brightness)
                                  .withValues(alpha: .48)
                              : dialogBorderColor.withValues(alpha: .56),
                        ),
                        const SizedBox(height: 10),
                        _guidedContinueButton(
                          tokens: tokens,
                          onTap: () =>
                              Navigator.pop(dialogContext, continueValue),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );

  Future<String?> _showChoiceSheet({
    required String title,
    required List<TradeEntryOption> options,
    String? selectedKey,
    bool centered = false,
    Color? accentTone,
    String? subtitle,
    bool guidedContinue = false,
    Set<String>? selectedKeys,
  }) {
    if (centered) {
      return _showCenteredTradeChoiceDialog<String>(
        title: title,
        subtitle: subtitle,
        keyPrefix: 'single-choice',
        selectedValue: selectedKey,
        accentTone: accentTone,
        continueValue: guidedContinue ? _guidedContinueValue : null,
        selectedValues: selectedKeys,
        options: [
          for (final option in options)
            (label: _ar ? option.ar : option.en, value: option.key),
        ],
      );
    }

    final tokens = TdTokens.of(context);
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: tdPopupMenuColor(Theme.of(context).brightness),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * .72,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: Text(
                  title,
                  style: Theme.of(sheetContext)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
                  itemCount: options.length,
                  separatorBuilder: (_, _) =>
                      Divider(height: 1, color: tokens.lineSubtle),
                  itemBuilder: (itemContext, index) {
                    final option = options[index];
                    final isSelected = option.key == selectedKey;
                    return ListTile(
                      dense: false,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 8,
                      ),
                      selected: isSelected,
                      selectedTileColor: tokens.accent.withValues(alpha: .08),
                      title: Text(
                        _ar ? option.ar : option.en,
                        style: Theme.of(itemContext)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(
                              fontSize: _tradeDataItemFontSize,
                              fontWeight: isSelected
                                  ? FontWeight.w800
                                  : FontWeight.w500,
                            ),
                      ),
                      trailing: Icon(
                        isSelected
                            ? Icons.check_circle
                            : Icons.chevron_left,
                        size: 19,
                        color: isSelected ? tokens.accent : tokens.text3,
                      ),
                      onTap: () => Navigator.pop(sheetContext, option.key),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// All timeframe pickers share one concise heading and one contextual line.
  /// The contextual line identifies both the section and the selected item,
  /// while the established centered dialog, row list, and selection styling
  /// remain unchanged.
  Future<String?> _showTimeframeSheet({
    required String contextLabel,
    String? selectedFrame,
    Set<String>? selectedFrames,
    Color? accentTone,
  }) =>
      _showCenteredTradeChoiceDialog<String>(
        title: _copy('اختيار الفريم الزمني', 'Select timeframe'),
        subtitle: contextLabel,
        keyPrefix: 'single-choice',
        selectedValue: selectedFrame,
        selectedValues: selectedFrames,
        accentTone: accentTone,
        options: [
          for (final frame in tradeEntryTimeframes)
            (label: frame, value: frame),
        ],
      );

  /// Sentinel returned when the trader presses Continue on the top-level
  /// choice list in guided mode. Its optionKey is checked by the caller
  /// (_reverseSignalRound / _bounceZoneRound) before it is ever stored.
  static const _entryConditionGuidedContinueSentinel = TradeEntryConditionSetup(
    optionKey: _guidedContinueValue,
    timeframe: '',
  );

  /// Bounce area and Opposing signals share this flow:
  /// choice list → (optional sub-choice popup / S/R Touch 2 / negative-close
  /// Trendline qualifier) → timeframe list.
  /// Grouped rows («سحب سيولة», «إرتداد من Trendline») open a small popup with
  /// their concrete choices before the timeframe picker; «ارتداد من Zone S/D»
  /// goes straight to the timeframe list and resolves Supply/Demand Zone from
  /// the trade direction. In guided mode (guided: true), pressing Continue on
  /// the top-level list returns _entryConditionGuidedContinueSentinel instead
  /// of walking the rest of the flow.
  Future<TradeEntryConditionSetup?> _showEntryConditionSetup({
    required String title,
    required String categoryLabel,
    required List<TradeEntryOption> options,
    TradeEntryConditionSetup? current,
    Color? choiceTone,
    bool guided = false,
    Set<String>? selectedKeys,
  }) async {
    if (!_hasTradeDirection) return null;
    final entryConditionsPrefix =
        '${_copy('ظروف الدخول', 'Entry conditions')} · $categoryLabel';
    final menuKey = await _showChoiceSheet(
      title: title,
      options: options,
      selectedKey:
          current == null ? null : tradeBounceZoneMenuKey(current.optionKey),
      centered: true,
      accentTone: choiceTone,
      guidedContinue: guided,
      selectedKeys: selectedKeys,
    );
    if (menuKey == null || !mounted) return null;
    if (menuKey == _guidedContinueValue) {
      return _entryConditionGuidedContinueSentinel;
    }

    var optionKey = menuKey;
    final subOptions = tradeBounceZoneSubOptions(menuKey);
    if (subOptions != null) {
      final menuOption = options.where((item) => item.key == menuKey).first;
      final subKey = await _showChoiceSheet(
        title: _ar ? menuOption.ar : menuOption.en,
        subtitle: entryConditionsPrefix,
        options: subOptions,
        selectedKey: current != null &&
                subOptions.any((item) => item.key == current.optionKey)
            ? current.optionKey
            : null,
        centered: true,
        accentTone: choiceTone,
      );
      if (subKey == null || !mounted) return null;
      optionKey = subKey;
    }

    // Negative-close rows: optional Trendline qualifier popup. «متابعة» keeps
    // the setup without a qualifier; dismissing the popup cancels the flow.
    String? closeRelation;
    if (tradeNegativeCloseKeys.contains(optionKey)) {
      final menuOption = options.where((item) => item.key == menuKey).first;
      final selectedRelation = await _showCenteredTradeChoiceDialog<String>(
        title: _ar ? menuOption.ar : menuOption.en,
        subtitle: entryConditionsPrefix,
        keyPrefix: 'negative-close-trendline',
        // No qualifier means nothing was chosen, so both choices stay neutral
        // until the user picks one; only a stored qualifier is restored.
        selectedValue: current?.optionKey == optionKey
            ? current?.closeRelation
            : null,
        accentTone: choiceTone,
        optionKeys: const [
          ValueKey('negative-close-above-trendline'),
          ValueKey('negative-close-below-trendline'),
          ValueKey('skip-negative-close-trendline'),
        ],
        options: [
          for (final option in tradeNegativeCloseTrendlineOptions)
            (label: _ar ? option.ar : option.en, value: option.key),
          (label: _copy('متابعة', 'Continue'), value: ''),
        ],
      );
      if (selectedRelation == null || !mounted) return null;
      closeRelation = selectedRelation.isEmpty ? null : selectedRelation;
    }

    var touch2 = false;
    if (optionKey == 'bounceFromSrZone') {
      final selectedTouch2 = await _showTouch2Sheet(
        baseReason: 'bounceFromSrZone',
        // A false Touch 2 flag means no qualifier is stored, not that the
        // user explicitly selected Continue. Keep both choices neutral until
        // the user makes a selection; restore only an explicitly stored Touch 2.
        selected: current?.optionKey == 'bounceFromSrZone' &&
                current?.touch2 == true
            ? true
            : null,
        side: _side,
        accentTone: choiceTone,
      );
      if (selectedTouch2 == null || !mounted) return null;
      touch2 = selectedTouch2;
    }
    final selectedOption = [...options, ...tradeBounceZoneLabelOptions]
        .where((option) => option.key == optionKey)
        .firstOrNull;
    final selectedOptionLabel = selectedOption == null
        ? optionKey
        : (_ar ? selectedOption.ar : selectedOption.en);
    final selectedContextLabel = formatTradeEntryConditionSetupLabel(
      setup: TradeEntryConditionSetup(
        optionKey: optionKey,
        timeframe: '',
        touch2: touch2,
        closeRelation: closeRelation,
      ),
      optionLabel: selectedOptionLabel,
      arabic: _ar,
      side: _side,
    );
    final timeframe = await _showTimeframeSheet(
      contextLabel: '$entryConditionsPrefix · $selectedContextLabel',
      selectedFrame: current?.timeframe,
      // Preserve the semantic tone when the timeframe picker follows an
      // opposing-signal selection. Other entry-condition pickers pass null
      // and therefore retain the established neutral/blue styling.
      accentTone: choiceTone,
    );
    if (timeframe == null || !mounted) return null;

    return TradeEntryConditionSetup(
      optionKey: optionKey,
      timeframe: timeframe,
      touch2: touch2,
      closeRelation: closeRelation,
    );
  }

  String _touch2DialogTitle({
    required String baseReason,
    required TradeSide? side,
  }) {
    if (baseReason == 'directionalBreakout') {
      final scenario = switch (side) {
        TradeSide.buy => 'RBS',
        TradeSide.sell => 'SBR',
        null => 'BREAKOUT',
      };
      return _ar
          ? '$scenario Touch — اختياري'
          : '$scenario Touch — Optional';
    }
    if (baseReason == 'bounceFromSrZone') {
      final scenario = switch (side) {
        TradeSide.buy => 'Support',
        TradeSide.sell => 'Resistan',
        null => 'S/R',
      };
      return _ar
          ? (side == null
              ? 'ارتداد من S/R Touch — اختياري'
              : 'ارتداد من $scenario Touch — اختياري')
          : (side == null
              ? 'S/R Bounce Touch — Optional'
              : 'Bounce from $scenario Touch — Optional');
    }
    return _copy('تفصيل $baseReason Touch — اختياري', '$baseReason Touch — Optional');
  }

  Future<bool?> _showTouch2Sheet({
    required String baseReason,
    required TradeSide? side,
    bool? selected,
    bool compactLabels = false,
    Color? accentTone,
  }) {
    return _showCenteredTradeChoiceDialog<bool>(
      title: _touch2DialogTitle(baseReason: baseReason, side: side),
      keyPrefix: 'touch2-$baseReason',
      selectedValue: selected,
      accentTone: accentTone,
      optionKeys: [
        ValueKey('touch2-choice-$baseReason'),
        ValueKey('skip-touch2-$baseReason'),
      ],
      options: [
        (
          label: baseReason == 'bounceFromSrZone'
              ? '2 Touch'
              : compactLabels
                  ? _copy('Touch 2', 'Touch 2')
                  : _copy('لمسة 2', 'Touch 2'),
          value: true,
        ),
        (
          label: _copy('متابعة', 'Continue'),
          value: false,
        ),
      ],
    );
  }

  Future<String?> _showEntryReasonSheet({
    String? currentReason,
    bool editing = false,
    bool guided = false,
  }) async {
    final currentBase = currentReason == null ? null : tradeEntryBaseReason(currentReason);
    final baseReason = await _showChoiceSheet(
      title: editing
          ? _copy('تعديل سبب الدخول', 'Edit entry reason')
          : _copy('سبب الدخول', 'Entry reason'),
      options: tradeEntryReasons,
      selectedKey: currentBase == null
          ? null
          : tradeEntryReasonSelectionKey(currentBase),
      centered: true,
      guidedContinue: guided,
      // Items already on the trade carry a check mark.
      selectedKeys: editing
          ? null
          : {
              for (final setup in _entrySetups)
                tradeEntryReasonSelectionKey(setup.reason),
            },
    );
    if (baseReason == null || !mounted) return null;
    if (baseReason == _guidedContinueValue) return _guidedContinueValue;
    if (!editing) {
      // Tapping an item that is already selected goes straight to its
      // timeframe list, reusing the variant it was saved with.
      final baseKey = tradeEntryReasonSelectionKey(baseReason);
      for (final setup in _entrySetups) {
        if (tradeEntryReasonSelectionKey(setup.reason) == baseKey) {
          return setup.reason;
        }
      }
    }
    final isDirectionalBreakout = baseReason == 'directionalBreakout';
    if (!isDirectionalBreakout &&
        !tradeEntryTouch2EligibleReasons.contains(baseReason)) {
      return baseReason;
    }

    final isEditingSameBreakout = currentReason != null &&
        tradeEntryReasonSelectionKey(currentReason) == 'directionalBreakout';
    final touch2 = await _showTouch2Sheet(
      baseReason: baseReason,
      // Preserve the current choice when editing. Legacy SBR/RBS Touch 2
      // values migrate into the same semantic BREAKOUT + Touch 2 selection.
      selected: isEditingSameBreakout && tradeEntryUsesTouch2(currentReason)
          ? true
          : null,
      side: _side,
      compactLabels: true,
    );
    if (!mounted) return null;
    // In guided mode a dismissed sub-popup just reopens the list.
    if (touch2 == null) return guided ? _guidedRetryValue : null;
    return tradeEntryReasonWithTouch2(baseReason, touch2);
  }

  Future<String?> _showCustomConfirmationDialog({String initialValue = ''}) async {
    final controller = TextEditingController(text: initialValue);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_copy('تأكيد مخصص', 'Custom confirmation')),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 80,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(labelText: _copy('اكتب نوع التأكيد', 'Enter confirmation type')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(tr(context, 'cancel'))),
          FilledButton(onPressed: () {
            final text = controller.text.trim();
            if (text.isNotEmpty) Navigator.pop(dialogContext, text);
          }, child: Text(tr(context, 'confirm'))),
        ],
      ),
    );
    controller.dispose();
    return value;
  }

  bool _hasEquivalentEntrySetup(String reason, String timeframe, {int? exceptIndex}) =>
      _entrySetups.asMap().entries.any((entry) =>
          entry.key != exceptIndex &&
          entry.value.timeframe == timeframe &&
          tradeEntryReasonSelectionKey(entry.value.reason) ==
              tradeEntryReasonSelectionKey(reason));

  Future<void> _addEntrySetup() async {
    if (!_hasTradeDirection) return;
    if (_isGuidedSection(_AutoEntryStep.entryReason)) {
      await _runGuidedSection(_AutoEntryStep.entryReason);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.entryReason)) return;
    await _entryReasonRound();
  }

  Future<void> _addConfirmationSetup() async {
    if (!_hasTradeDirection) return;
    if (_isGuidedSection(_AutoEntryStep.confirmation)) {
      await _runGuidedSection(_AutoEntryStep.confirmation);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.confirmation)) return;
    await _confirmationRound();
  }

  Future<void> _editEntrySetup(TradeEntrySetup current) async {
    if (!_hasTradeDirection) return;
    if (_redirectToMissingGuidedField(_AutoEntryStep.entryReason)) return;
    final reason = await _showEntryReasonSheet(currentReason: current.reason, editing: true);
    if (reason == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      contextLabel: '${_copy('سبب الدخول', 'Entry reason')} · ${formatTradeEntryReasonLabel(reason: reason, side: _side)}',
      selectedFrame: current.timeframe,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _entrySetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeEntrySetup(reason: reason, timeframe: timeframe);
      if (_hasEquivalentEntrySetup(reason, timeframe, exceptIndex: index)) {
        _entrySetups.removeAt(index);
      } else {
        _entrySetups[index] = replacement;
      }
    });
  }

  Future<void> _editConfirmationSetup(TradeConfirmationSetup current) async {
    if (!_hasTradeDirection) return;
    if (_redirectToMissingGuidedField(_AutoEntryStep.confirmation)) return;
    final type = await _showChoiceSheet(
      title: _copy('تعديل تأكيد الدخول', 'Edit entry confirmation'),
      options: tradeConfirmationOptions,
      selectedKey: tradeConfirmationOptions.any(
        (item) => item.key == tradeConfirmationSelectionKey(current.type),
      )
          ? tradeConfirmationSelectionKey(current.type)
          : '__custom__',
      centered: true,
    );
    if (type == null || !mounted) return;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog(initialValue: current.type == '__custom__' ? '' : current.type);
      if (custom == null || !mounted) return;
      finalType = custom;
    }
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '${_copy('تأكيد الدخول', 'Entry confirmation')} · ${_confirmationLabel(finalType)}',
      selectedFrame: current.timeframe,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _confirmationSetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeConfirmationSetup(type: finalType, timeframe: timeframe);
      if (_confirmationSetups.asMap().entries.any((entry) =>
          entry.key != index &&
          tradeConfirmationSelectionKey(entry.value.type) ==
              tradeConfirmationSelectionKey(replacement.type) &&
          entry.value.timeframe == replacement.timeframe)) {
        _confirmationSetups.removeAt(index);
      } else {
        _confirmationSetups[index] = replacement;
      }
    });
  }

  Future<void> _addReverseSignalSetup() async {
    if (_side == null) {
      _showValidationMessage(
        _copy(
          'حدد اتجاه الصفقة شراء أو بيع أولاً حتى تُعرض الإشارة العكسية الصحيحة.',
          'Choose Buy or Sell first so the opposing signal can be resolved correctly.',
        ),
      );
      return;
    }
    if (_isGuidedSection(_AutoEntryStep.reverseSignals)) {
      await _runGuidedSection(_AutoEntryStep.reverseSignals);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.reverseSignals)) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('إشارات عكسية', 'Opposing signals'),
      categoryLabel: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
      choiceTone: _currentReverseSignalTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_reverseSignalSetups.contains(setup)) _reverseSignalSetups.add(setup);
    });
  }

  Future<void> _editReverseSignalSetup(TradeEntryConditionSetup current) async {
    if (_side == null) {
      _showValidationMessage(
        _copy(
          'حدد اتجاه الصفقة شراء أو بيع أولاً حتى تُعرض الإشارة العكسية الصحيحة.',
          'Choose Buy or Sell first so the opposing signal can be resolved correctly.',
        ),
      );
      return;
    }
    if (_redirectToMissingGuidedField(_AutoEntryStep.reverseSignals)) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل الإشارة العكسية', 'Edit opposing signal'),
      categoryLabel: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
      current: current,
      choiceTone: _currentReverseSignalTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _reverseSignalSetups.indexOf(current);
      if (index < 0) return;
      final wasMarkedPractical =
          _practicalNoEntryReverseSignalSetups.remove(current);
      final duplicateIndex = _reverseSignalSetups.indexWhere(
        (value) => value == setup && value != current,
      );
      if (duplicateIndex >= 0) {
        _reverseSignalSetups.removeAt(index);
        if (wasMarkedPractical &&
            !_practicalNoEntryReverseSignalSetups.contains(setup)) {
          _practicalNoEntryReverseSignalSetups.add(setup);
        }
      } else {
        _reverseSignalSetups[index] = setup;
        if (wasMarkedPractical) {
          _practicalNoEntryReverseSignalSetups.add(setup);
        }
      }
    });
  }

  Future<void> _addBounceZoneSetup() async {
    if (!_hasTradeDirection) return;
    if (_isGuidedSection(_AutoEntryStep.bounceZone)) {
      await _runGuidedSection(_AutoEntryStep.bounceZone);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.bounceZone)) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('منطقة الارتداد', 'Bounce area'),
      categoryLabel: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
      choiceTone: _entryConditionsTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_bounceZoneSetups.contains(setup)) _bounceZoneSetups.add(setup);
    });
  }

  Future<void> _editBounceZoneSetup(TradeEntryConditionSetup current) async {
    if (!_hasTradeDirection) return;
    if (_redirectToMissingGuidedField(_AutoEntryStep.bounceZone)) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل منطقة الارتداد', 'Edit bounce area'),
      categoryLabel: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
      current: current,
      choiceTone: _entryConditionsTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _bounceZoneSetups.indexOf(current);
      if (index < 0) return;
      if (_bounceZoneSetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == setup,
      )) {
        _bounceZoneSetups.removeAt(index);
      } else {
        _bounceZoneSetups[index] = setup;
      }
    });
  }

  void _removeReverseSignalSetup(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() {
      _reverseSignalSetups.remove(setup);
      _practicalNoEntryReverseSignalSetups.remove(setup);
    });
  }

  void _togglePracticalNoEntryReverseSignal(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection || !_reverseSignalSetups.contains(setup)) return;
    final wasMarked = _practicalNoEntryReverseSignalSetups.contains(setup);
    setState(() {
      if (wasMarked) {
        _practicalNoEntryReverseSignalSetups.remove(setup);
      } else {
        _practicalNoEntryReverseSignalSetups.add(setup);
        _enforceMissedOnlyOutcome();
      }
    });
    HapticFeedback.selectionClick();
    final message = wasMarked
        ? _copy('تم إلغاء ربط الإشارة كسبب عملي', 'Practical reason link removed')
        : _copy('تم ربط الإشارة كسبب عملي لعدم الدخول', 'Opposing signal linked as a practical no-entry reason');
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(milliseconds: 1500),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _removeBounceZoneSetup(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _bounceZoneSetups.remove(setup));
  }

  void _removeEntrySetup(TradeEntrySetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _entrySetups.remove(setup));
  }

  /// Dynamic title of the exit rectangle; null hides it (no win/loss/break-even).
  String? get _exitSectionTitle =>
      tradeExitSectionTitle(_classification, arabic: _ar);

  Future<void> _addExitReasonSetup() async {
    if (!_hasTradeDirection || _exitSectionTitle == null) return;
    if (_isGuidedSection(_AutoEntryStep.exitReason)) {
      await _runGuidedSection(_AutoEntryStep.exitReason);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.exitReason)) return;
    await _exitReasonRound();
  }

  Future<void> _editExitReasonSetup(TradeConfirmationSetup current) async {
    final title = _exitSectionTitle;
    if (!_hasTradeDirection || title == null) return;
    if (_redirectToMissingGuidedField(_AutoEntryStep.exitReason)) return;
    final type = await _showChoiceSheet(
      title: _ar ? 'تعديل $title' : 'Edit $title',
      options: tradeExitReasonOptions,
      selectedKey: tradeExitReasonSelectionKey(current.type),
      centered: true,
    );
    if (type == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '$title · ${tradeExitReasonLabel(type, arabic: _ar, side: _side)}',
      selectedFrame: current.timeframe,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _exitReasonSetups.indexOf(current);
      if (index < 0) return;
      final replacement =
          TradeConfirmationSetup(type: type, timeframe: timeframe);
      if (_exitReasonSetups.asMap().entries.any((entry) =>
          entry.key != index &&
          tradeExitReasonSelectionKey(entry.value.type) == type &&
          entry.value.timeframe == timeframe)) {
        _exitReasonSetups.removeAt(index);
      } else {
        _exitReasonSetups[index] = replacement;
      }
    });
  }

  void _removeExitReasonSetup(TradeConfirmationSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _exitReasonSetups.remove(setup));
  }

  void _removeConfirmationSetup(TradeConfirmationSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _confirmationSetups.remove(setup));
  }

  bool get _hasExecutionFlaw =>
      _executionReviewKeys.any(tradeExecutionFlawKeys.contains);

  /// «التزمت بالخطة كاملة» and «التزمت بشروط الدخول…» are locked while any
  /// violation or analysis-quality item is chosen. A commitment that is already
  /// selected (an older saved trade) stays tappable so it can be cleared.
  bool _commitmentLocked(String key) =>
      tradeCommitmentExclusiveKeys.contains(key) &&
      _hasExecutionFlaw &&
      !_executionReviewKeys.contains(key);

  void _toggleSet(Set<String> values, String key, bool selected) {
    if (!_hasTradeDirection) return;
    // Shared by Decisions (violations/analysis), Commitment, and No-entry
    // reasons: picking a new item anywhere here first checks whether the
    // trader emptied a required earlier section (Entry reason / Entry
    // confirmation) and, if so, takes them back to it instead of selecting.
    if (selected && _redirectToMissingGuidedFieldAnywhere()) return;
    setState(() {
      if (selected) {
        values.add(key);
      } else {
        values.remove(key);
      }
      if (identical(values, _executionReviewKeys) &&
          selected &&
          tradeExecutionFlawKeys.contains(key)) {
        // A mistake and a "followed the plan / entry conditions" commitment
        // contradict each other, so the commitment is released.
        values.removeAll(tradeCommitmentExclusiveKeys);
      }
      if (identical(values, _noEntryReasons) && selected) {
        _enforceMissedOnlyOutcome();
      }
    });
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? tr(context, 'requiredField') : null;

  String? _number(String? value, {double? min}) {
    if (value == null || value.trim().isEmpty) return tr(context, 'requiredField');
    final parsed = double.tryParse(value.trim().replaceAll(',', '.'));
    if (parsed == null || !parsed.isFinite || (min != null && parsed < min)) return tr(context, 'invalidNumber');
    return null;
  }

  String? _expectedLossValidator(String? value) {
    // The result itself supplies the realized loss when it is negative, so
    // this separate planned-loss field is intentionally not required then.
    if (_hasEntryConditionsNoEntryLink) return null;
    final result = _parseResult();
    if (result != null && result < 0) return null;
    if ((value == null || value.trim().isEmpty) &&
        (_classification == TradeClassification.breakEven ||
            _classification == TradeClassification.missed)) {
      return null;
    }
    final invalid = _number(value, min: 0);
    if (invalid != null) return invalid;
    final loss = _parse(_expectedLoss) ?? 0;
    if (result != 0 && loss <= 0) return tr(context, 'expectedLossNeeded');
    return null;
  }

  String _breakEvenTypeLabel(BreakEvenType value) => switch (value) {
    BreakEvenType.balanced => _copy('متساوي', 'Balanced'),
    BreakEvenType.atEntry => _copy('عند منطقة الدخول', 'At entry area'),
  };

  String _missedOutcomeLabel(MissedTradeOutcome value) => switch (value) {
    MissedTradeOutcome.win => _copy('كانت رابحة', 'Would have won'),
    MissedTradeOutcome.loss => _copy('كانت خاسرة', 'Would have lost'),
  };

  /// True while the trader still owes one choice that the form cannot derive:
  /// break-even vs missed, the break-even type, or the missed would-be result.
  bool get _needsOutcomeChoice => switch (_classification) {
    null => true,
    TradeClassification.breakEven => _breakEvenType == null,
    TradeClassification.missed => _missedOutcome == null,
    TradeClassification.win || TradeClassification.loss => false,
  };

  /// Only break-even / missed carry a menu; win and loss are fixed by the
  /// sign of the result.
  bool get _outcomeHasMenu => _availableClassifications.any(
    (value) =>
        value == TradeClassification.breakEven ||
        value == TradeClassification.missed,
  );

  void _applyOutcomeChoice(_OutcomeChoice choice) {
    setState(() {
      _classification = choice.classification;
      _breakEvenType = choice.breakEvenType;
      _missedOutcome = choice.missedOutcome;
    });
    HapticFeedback.selectionClick();
  }

  /// Opens the outcome menu in place of the save bar. The card grows upward
  /// from the bottom edge of the save slot, so every choice sits inside thumb
  /// reach with no scrolling, and one tap selects and closes it.
  Future<void> _openOutcomeMenu() async {
    if (_busy || _outcomeMenuOpen || !_outcomeHasMenu) return;
    _outcomeMenuOpen = true;
    // Bring the slot fully on screen first so the popup always opens directly
    // over the save bar's own position.
    final slotContext = _saveSlotKey.currentContext;
    if (slotContext != null) {
      await Scrollable.ensureVisible(
        slotContext,
        alignmentPolicy: ScrollPositionAlignmentPolicy.keepVisibleAtEnd,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
      );
      if (!mounted) {
        _outcomeMenuOpen = false;
        return;
      }
    }
    final slotBox = _saveSlotKey.currentContext?.findRenderObject();
    final Rect? slotRect =
        slotBox is RenderBox && slotBox.hasSize && slotBox.attached
            ? slotBox.localToGlobal(Offset.zero) & slotBox.size
            : null;
    final available = _availableClassifications;
    final selected = await showGeneralDialog<_OutcomeChoice>(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: TdTokens.of(context).scrim.withValues(alpha: .34),
      transitionDuration: const Duration(milliseconds: 190),
      pageBuilder: (dialogContext, _, _) {
        final tokens = TdTokens.of(dialogContext);
        final brightness = Theme.of(dialogContext).brightness;
        final isDark = brightness == Brightness.dark;
        final media = MediaQuery.of(dialogContext);
        const horizontalMargin = 16.0;
        final screenHeight = media.size.height;
        final minBottom = media.padding.bottom + media.viewInsets.bottom + 12;
        // Card bottom edge == slot bottom edge; fall back to the screen bottom
        // when the slot has not been laid out.
        final bottom = slotRect == null
            ? minBottom
            : (screenHeight - slotRect.bottom)
                .clamp(minBottom, screenHeight)
                .toDouble();
        final left = slotRect == null
            ? horizontalMargin
            : slotRect.left
                .clamp(horizontalMargin, media.size.width / 2)
                .toDouble();
        final right = slotRect == null
            ? horizontalMargin
            : (media.size.width - slotRect.right)
                .clamp(horizontalMargin, media.size.width / 2)
                .toDouble();

        Widget option({
          required String keyName,
          required String label,
          required Color accent,
          required bool isSelected,
          required _OutcomeChoice choice,
        }) {
          return Material(
            color: isSelected
                ? accent.withValues(alpha: isDark ? .16 : .11)
                : tokens.surface3.withValues(alpha: isDark ? .62 : .9),
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              key: ValueKey('trade-outcome-option-$keyName'),
              borderRadius: BorderRadius.circular(12),
              onTap: () => Navigator.of(dialogContext).pop(choice),
              child: Container(
                constraints: const BoxConstraints(minHeight: 50),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? accent.withValues(alpha: .72)
                        : tokens.lineSubtle.withValues(alpha: .62),
                    width: isSelected ? 1 : .8,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        label,
                        style: Theme.of(dialogContext).textTheme.bodyMedium
                            ?.copyWith(
                              color: isSelected ? tokens.text1 : tokens.text2,
                              fontWeight: isSelected
                                  ? FontWeight.w800
                                  : FontWeight.w600,
                            ),
                      ),
                    ),
                    Icon(
                      isSelected
                          ? Icons.check_circle_rounded
                          : Icons.chevron_left_rounded,
                      size: 19,
                      color: isSelected ? accent : tokens.text3,
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        Widget header(TradeClassification value) {
          final accent = TradeOutcomePalette.of(value, tokens, brightness);
          return Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
            child: Row(
              children: [
                Icon(TradeSaveBar.iconFor(value), size: 18, color: accent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _classificationLabel(value),
                    style: Theme.of(dialogContext).textTheme.titleSmall
                        ?.copyWith(
                          color: accent,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
              ],
            ),
          );
        }

        final sections = <Widget>[];
        if (available.contains(TradeClassification.breakEven)) {
          final accent = TradeOutcomePalette.breakEven(brightness);
          sections.addAll([
            header(TradeClassification.breakEven),
            for (final type in BreakEvenType.values) ...[
              option(
                keyName: type.name,
                label: _breakEvenTypeLabel(type),
                accent: accent,
                isSelected: _classification == TradeClassification.breakEven &&
                    _breakEvenType == type,
                choice: _OutcomeChoice(
                  TradeClassification.breakEven,
                  breakEvenType: type,
                ),
              ),
              const SizedBox(height: 8),
            ],
          ]);
        }
        if (available.contains(TradeClassification.missed)) {
          final accent = TradeOutcomePalette.missed(brightness);
          if (sections.isNotEmpty) sections.add(const SizedBox(height: 4));
          sections.addAll([
            header(TradeClassification.missed),
            for (final outcome in MissedTradeOutcome.values) ...[
              option(
                keyName: outcome == MissedTradeOutcome.win
                    ? 'missedWin'
                    : 'missedLoss',
                label: _missedOutcomeLabel(outcome),
                accent: accent,
                isSelected: _classification == TradeClassification.missed &&
                    _missedOutcome == outcome,
                choice: _OutcomeChoice(
                  TradeClassification.missed,
                  missedOutcome: outcome,
                ),
              ),
              const SizedBox(height: 8),
            ],
          ]);
        }
        if (sections.isNotEmpty) sections.removeLast();

        return Stack(
          children: [
            Positioned(
              left: left,
              right: right,
              bottom: bottom,
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: screenHeight * .7),
                child: Material(
                  key: const ValueKey('trade-outcome-menu'),
                  color: tdPopupMenuColor(brightness),
                  elevation: 10,
                  shadowColor: Colors.black.withValues(alpha: .5),
                  surfaceTintColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                    side: BorderSide(
                      color: tdTradeDataPopupMenuBorderColor(brightness),
                      width: .8,
                    ),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: sections,
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
      transitionBuilder: (context, animation, _, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            alignment: Alignment.bottomCenter,
            scale: Tween<double>(begin: .94, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
    _outcomeMenuOpen = false;
    if (selected != null && mounted) _applyOutcomeChoice(selected);
  }

  /// "USD 250+" / "USD 120−" for a decided win or loss; null while no amount.
  String? _resultAmountLabel(String currency) {
    final result = _parseResult();
    if (result == null || result == 0 || !result.isFinite) return null;
    final magnitude = result.abs();
    final text = magnitude == magnitude.roundToDouble() && magnitude < 1e15
        ? magnitude.toInt().toString()
        : magnitude.toString();
    return '$currency $text${result > 0 ? '+' : '−'}';
  }

  /// The merged outcome + save capsule. Its colour and icon follow the
  /// outcome, so the trade type is readable from the bar alone.
  Widget _buildSaveBar(String currency) {
    final value = _classification;
    final label = value == null ? '' : _classificationLabel(value);
    final String title;
    String? subtitle;
    var subtitleLtr = false;
    switch (value) {
      case TradeClassification.win:
      case TradeClassification.loss:
        title = label;
        subtitle = _resultAmountLabel(currency);
        subtitleLtr = true;
      case TradeClassification.breakEven:
        title = label;
        subtitle = _breakEvenType == null
            ? _copy('اختر النوع', 'Choose type')
            : _breakEvenTypeLabel(_breakEvenType!);
      case TradeClassification.missed:
        title = label;
        subtitle = _missedOutcome == null
            ? _copy('حدد النتيجة', 'Set outcome')
            : _missedOutcomeLabel(_missedOutcome!);
      case null:
        title = _copy('اختر التصنيف', 'Choose outcome');
        subtitle = _copy('تعادل أو ضائعة', 'Break-even or missed');
    }
    return SizedBox(
      key: _saveSlotKey,
      height: TradeSaveBar.height,
      child: TradeSaveBar(
        classification: value,
        title: title,
        subtitle: subtitle,
        subtitleLtr: subtitleLtr,
        saveLabel: tr(context, 'save'),
        ready: !_needsOutcomeChoice,
        busy: _busy,
        hasMenu: _outcomeHasMenu,
        onOpenMenu: _openOutcomeMenu,
        // A missing sub-choice is asked for right here instead of failing.
        onSave: _needsOutcomeChoice && _outcomeHasMenu
            ? _openOutcomeMenu
            : _save,
      ),
    );
  }

  String _classificationLabel(TradeClassification value) => switch (value) {
    TradeClassification.win => tr(context, 'classificationWin'),
    TradeClassification.loss => tr(context, 'classificationLoss'),
    TradeClassification.breakEven => tr(context, 'classificationBreakEven'),
    TradeClassification.missed => tr(context, 'classificationMissed'),
  };

  bool _classificationMatchesResult(TradeClassification value, double result) =>
      switch (value) {
        TradeClassification.win => result > 0,
        TradeClassification.loss => result < 0,
        TradeClassification.breakEven || TradeClassification.missed => result == 0,
      };

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final selectedClassification = _classification;
    if (selectedClassification == null) {
      _showValidationMessage(tr(context, 'tradeClassificationRequired'));
      return;
    }
    if (selectedClassification == TradeClassification.breakEven &&
        _breakEvenType == null) {
      _showValidationMessage(_copy(
        'اختر نوع التعادل قبل حفظ الصفقة.',
        'Choose the break-even type before saving.',
      ));
      return;
    }
    if (selectedClassification == TradeClassification.missed &&
        _missedOutcome == null) {
      _showValidationMessage(
        _copy(
          'حدد ما إذا كانت الفرصة الضائعة رابحة أم خاسرة قبل حفظ الصفقة.',
          'Choose whether the missed opportunity was a win or loss before saving.',
        ),
      );
      return;
    }
    final enteredResult = _parseResult() ?? 0.0;
    if (!_availableClassifications.contains(selectedClassification) ||
        !_classificationMatchesResult(selectedClassification, enteredResult)) {
      _showValidationMessage(tr(context, 'tradeClassificationResultMismatch'));
      return;
    }
    if (_symbol == null || _symbol!.trim().isEmpty) {
      _showValidationMessage(_copy('اختر الرمز: NQ أو ES أو GC.', 'Choose a symbol: NQ, ES, or GC.'));
      return;
    }
    if (_side == null) {
      _showValidationMessage(_copy('حدد اتجاه الصفقة: شراء أو بيع.', 'Choose the trade direction: buy or sell.'));
      return;
    }
    if (_entrySetups.isEmpty) {
      _showValidationMessage(_copy('أضف سبب دخول واحدًا على الأقل مع الفريم الزمني.', 'Add at least one entry reason with its timeframe.'));
      return;
    }
    if (_confirmationSetups.isEmpty) {
      _showValidationMessage(_copy('أضف تأكيد دخول واحدًا على الأقل مع فريمه الزمني.', 'Add at least one entry confirmation with its timeframe.'));
      return;
    }
    final app = AppScope.of(context);
    if (app.accounts.isEmpty) return;
    final balance = _accountBalanceBeforeTrade(app);
    final result = _parseResult() ?? 0.0;
    final parsedLoss = _parse(_expectedLoss);
    final recordedLoss = parsedLoss != null &&
            parsedLoss.isFinite &&
            parsedLoss >= 0
        ? parsedLoss
        : null;
    final loss = result < 0 &&
            (recordedLoss == null || recordedLoss == 0)
        ? result.abs()
        : recordedLoss ?? 0.0;
    final risk = loss == 0 ? 0.0 : (balance > 0 ? loss / balance * 100 : null);
    if (risk == null || !risk.isFinite) {
      _showValidationMessage(tr(context, 'riskBalanceUnavailable'));
      return;
    }
    final setups = [..._entrySetups];
    final confirmations = [..._confirmationSetups];
    final trade = Trade(
      id: widget.trade?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      accountId: app.accounts.any((item) => item.id == _accountId) ? _accountId : (app.selectedAccountId ?? app.accounts.first.id),
      market: _symbol!.trim().toUpperCase(),
      reason: setups.first.reason,
      result: result,
      riskPercent: risk,
      // Keep this optional when the loss amount was derived solely from the
      // realized result. Existing or explicitly entered planned risk is kept.
      expectedLoss: recordedLoss ?? (result < 0 ? null : loss),
      side: _side!,
      confirmation: '',
      confirmationSetups: confirmations,
      // Exit reasons only apply to win / loss / break-even records.
      exitReasonSetups: _exitSectionTitle == null
          ? const []
          : [..._exitReasonSetups],
      reverseSignalSetups: [..._reverseSignalSetups],
      bounceZoneSetups: [..._bounceZoneSetups],
      executionJournal: widget.trade?.executionJournal ?? const [],
      executionReviewKeys: _executionReviewKeys.toList(growable: false),
      noEntryReasons: _noEntryReasons.toList(growable: false),
      practicalNoEntryReverseSignalSetups: _practicalNoEntryReverseSignalSetups
          .where(_reverseSignalSetups.contains)
          .toList(growable: false),
      sequence: widget.trade?.sequence ?? '',
      mood: _orderedMoodKeys.firstOrNull ?? 'moodUnknown',
      moods: _orderedMoodKeys,
      tradedAt: _tradedAt,
      entryTimeframe: setups.first.timeframe,
      entrySetups: setups,
      beforeImagePath: _beforePath,
      afterImagePath: _afterPath,
      confirmationImagePath: _confirmationImagePath,
      notes: widget.trade?.notes ?? '',
      strategyAdherence: widget.trade?.strategyAdherence,
      classification: selectedClassification,
      missedOutcome: selectedClassification == TradeClassification.missed
          ? _missedOutcome
          : null,
      breakEvenType: selectedClassification == TradeClassification.breakEven
          ? _breakEvenType
          : null,
      anchor: _orderedAnchorKeys.firstOrNull,
      anchors: _orderedAnchorKeys,
      anchorTimeframes: {
        for (final key in _orderedAnchorKeys)
          if (_anchorTimeframes[key] != null) key: _anchorTimeframes[key]!,
      },
    );
    Navigator.of(context).pop(trade);
  }

  void _showValidationMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  InputDecoration _blueSelectorDecoration({
    required String label,
    Widget? labelWidget,
    IconData? icon,
    IconData? trailingIcon,
    Color? tone,
    Color? fillColorOverride,
    Color? borderColorOverride,
    EdgeInsetsGeometry? contentPadding,
    FloatingLabelAlignment? floatingLabelAlignment,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectorTone = tone ?? _dataTone;
    final fieldFill = fillColorOverride ??
        (isDark
            ? (tone == null
                ? const Color(0xFF071834)
                : Color.alphaBlend(
                    selectorTone.withValues(alpha: .10),
                    const Color(0xFF071834),
                  ))
            : Color.alphaBlend(
                selectorTone.withValues(alpha: .10),
                tokens.inset,
              ));
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(
        color: borderColorOverride ??
            (isDark
                ? (tone == null
                    ? const Color(0xFF21405B).withValues(alpha: .52)
                    : selectorTone.withValues(alpha: .30))
                : tokens.lineSubtle.withValues(alpha: .68)),
        width: .78,
      ),
    );
    final fieldLabelStyle = Theme.of(context)
        .textTheme
        .labelMedium
        ?.copyWith(
          color: tokens.text2,
          fontSize: _tradeFieldLabelFontSize,
          fontWeight: FontWeight.w600,
          height: 1.15,
        );
    return InputDecoration(
      labelText: labelWidget == null ? label : null,
      label: labelWidget,
      labelStyle: fieldLabelStyle,
      floatingLabelStyle: fieldLabelStyle?.copyWith(
        fontSize: _tradeFloatingLabelFontSize,
      ),
      prefixIcon: icon == null
          ? null
          : Icon(icon, size: 17, color: tokens.text2),
      prefixIconConstraints: icon == null
          ? null
          : const BoxConstraints(minWidth: 36, minHeight: 48),
      suffixIcon: trailingIcon == null
          ? null
          : Icon(trailingIcon, size: 18, color: tokens.text3),
      suffixIconConstraints: trailingIcon == null
          ? null
          : const BoxConstraints(minWidth: 38, minHeight: 42),
      filled: true,
      fillColor: fieldFill,
      border: fieldBorder,
      enabledBorder: fieldBorder,
      focusedBorder: fieldBorder.copyWith(
        borderSide: BorderSide(
          color: selectorTone.withValues(alpha: .78),
          width: 1.05,
        ),
      ),
      contentPadding: contentPadding ??
          const EdgeInsetsDirectional.fromSTEB(10, 13, 10, 13),
      floatingLabelBehavior: FloatingLabelBehavior.auto,
      floatingLabelAlignment: floatingLabelAlignment,
    );
  }

  Future<void> _showCompactPopupChoice<T>({
    required GlobalKey anchorKey,
    required List<T> values,
    required String itemKeyPrefix,
    required T? selectedValue,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
    double itemHeight = 48,
    double minMenuWidth = 0,
  }) async {
    final anchorContext = anchorKey.currentContext;
    final anchorRenderObject = anchorContext?.findRenderObject();
    final overlay = Overlay.of(context);
    final overlayRenderObject = overlay.context.findRenderObject();
    if (anchorRenderObject is! RenderBox ||
        overlayRenderObject is! RenderBox ||
        !anchorRenderObject.hasSize ||
        !overlayRenderObject.hasSize) {
      return;
    }

    final anchorTopLeft = anchorRenderObject.localToGlobal(
      Offset.zero,
      ancestor: overlayRenderObject,
    );
    final anchorRect = anchorTopLeft & anchorRenderObject.size;
    final overlayRect = Offset.zero & overlayRenderObject.size;
    final screenWidthLimit = overlayRenderObject.size.width - 24;
    // The popup width follows its own field exactly. This keeps the mindset
    // menu inside its control and prevents market/direction menus from
    // spilling beyond their half-width selector columns.
    // [minMenuWidth] keeps short labels such as SELL fully readable when the
    // field is narrower than the text needs; the menu then widens evenly
    // around its field instead of truncating the label.
    final wantedWidth = anchorRenderObject.size.width < minMenuWidth
        ? minMenuWidth
        : anchorRenderObject.size.width;
    final menuWidth =
        wantedWidth > screenWidthLimit ? screenWidthLimit : wantedWidth;
    final widenBy = menuWidth - anchorRect.width;
    final menuAnchorRect = widenBy > 0
        ? Rect.fromLTRB(
            anchorRect.left - widenBy / 2,
            anchorRect.top,
            anchorRect.right + widenBy / 2,
            anchorRect.bottom,
          )
        : anchorRect;

    final selected = await showMenu<T>(
      context: context,
      position: RelativeRect.fromRect(
        menuAnchorRect.shift(const Offset(0, 7)),
        overlayRect,
      ),
      color: tdPopupMenuColor(Theme.of(context).brightness),
      surfaceTintColor: Colors.transparent,
      elevation: 9,
      shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness),
      menuPadding: const EdgeInsets.symmetric(vertical: 5),
      constraints: BoxConstraints.tightFor(width: menuWidth),
      popUpAnimationStyle: tdPopupMenuAnimationStyle,
      items: [
        for (final value in values)
          PopupMenuItem<T>(
            key: ValueKey(
              '$itemKeyPrefix-${value is Enum ? value.name : value.toString()}',
            ),
            value: value,
            height: itemHeight,
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            child: Container(
              width: double.infinity,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                color: value == selectedValue
                    ? TdTokens.of(context).accent.withValues(alpha: .11)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  labelFor(value),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  softWrap: false,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: value == selectedValue
                        ? TdTokens.of(context).text1
                        : TdTokens.of(context).text2,
                    fontSize: _tradeDataItemFontSize,
                    fontWeight: value == selectedValue
                        ? FontWeight.w700
                        : FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
      ],
    );

    if (selected != null && mounted) onSelected(selected);
  }

  Widget _compactPopupChoice<T>({
    required Key key,
    required GlobalKey popupAnchorKey,
    required String itemKeyPrefix,
    required String caption,
    TextDirection valueDirection = TextDirection.ltr,
    bool centerContent = false,
    bool enabled = true,
    required T? selectedValue,
    required List<T> values,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
    double minMenuWidth = 0,
  }) {
    final hasSelectedValue = selectedValue != null;
    final selectedLabel =
        hasSelectedValue ? labelFor(selectedValue as T) : caption;
    final selectedValueKey = hasSelectedValue
        ? '$itemKeyPrefix-${selectedValue is Enum ? selectedValue.name : selectedValue.toString()}-selected-value'
        : null;
    final displayedValue = Text(
      selectedLabel,
      key: selectedValueKey == null ? null : ValueKey(selectedValueKey),
      textAlign: centerContent ? TextAlign.center : TextAlign.start,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      textDirection: hasSelectedValue
          ? valueDirection
          : (_ar ? TextDirection.rtl : TextDirection.ltr),
      style: (hasSelectedValue
              ? Theme.of(context).textTheme.labelMedium
              : Theme.of(context).textTheme.labelSmall)
          ?.copyWith(
        color: hasSelectedValue
            ? TdTokens.of(context).text1
            : TdTokens.of(context).text2,
        fontSize: hasSelectedValue ? _tradeDataItemFontSize : 10.5,
        fontWeight: hasSelectedValue ? FontWeight.w700 : FontWeight.w600,
      ),
    );
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: InkWell(
        key: key,
        borderRadius: BorderRadius.circular(12),
        onTap: enabled
            ? () => _showCompactPopupChoice<T>(
                  anchorKey: popupAnchorKey,
                  values: values,
                  itemKeyPrefix: itemKeyPrefix,
                  selectedValue: selectedValue,
                  labelFor: labelFor,
                  onSelected: onSelected,
                  minMenuWidth: minMenuWidth,
                )
            : null,
        child: SizedBox(
          key: popupAnchorKey,
          height: _tradeDataContentHeight,
          child: Row(
            children: [
              Expanded(
                child: Align(
                  alignment: centerContent
                      ? Alignment.center
                      : AlignmentDirectional.centerStart,
                  child: displayedValue,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    _trackFilledGuidedSections();
    final app = AppScope.of(context);
    final tokens = TdTokens.of(context);
    final softenedTokens = tokens.copyWith(
      lineSubtle: tokens.lineSubtle.withValues(alpha: .68),
      lineStrong: tokens.lineStrong.withValues(alpha: .54),
    );
    final baseTheme = Theme.of(context);
    final formFieldLabelStyle = (baseTheme.textTheme.labelMedium ??
            const TextStyle())
        .copyWith(
      color: tokens.text2,
      fontSize: _tradeFieldLabelFontSize,
      fontWeight: FontWeight.w600,
      height: 1.15,
    );
    final formFieldFloatingLabelStyle = formFieldLabelStyle.copyWith(
      fontSize: _tradeFloatingLabelFontSize,
    );
    final defaultFieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: softenedTokens.lineSubtle, width: 0.78),
    );
    final focusedFieldBorder = defaultFieldBorder.copyWith(
      borderSide: BorderSide(
        color: tokens.accent.withValues(alpha: .78),
        width: 1.05,
      ),
    );
    if (app.accounts.isEmpty) {
      return Scaffold(appBar: AppBar(), body: Center(child: Text(tr(context, 'addFirstAccount'))));
    }
    if (!app.accounts.any((item) => item.id == _accountId)) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    final account = _account ?? app.accounts.first;
    return Theme(
      data: baseTheme.copyWith(
        popupMenuTheme: baseTheme.popupMenuTheme.copyWith(
          color: tdPopupMenuColor(baseTheme.brightness),
          surfaceTintColor: Colors.transparent,
          shape: tdTradeDataPopupMenuShape(baseTheme.brightness),
          textStyle: baseTheme.textTheme.bodySmall?.copyWith(
            fontSize: _tradeDataItemFontSize,
            color: tokens.text1,
          ),
        ),
        dividerColor: softenedTokens.lineSubtle,
        inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
          border: defaultFieldBorder,
          enabledBorder: defaultFieldBorder,
          focusedBorder: focusedFieldBorder,
          disabledBorder: defaultFieldBorder,
          labelStyle: formFieldLabelStyle,
          floatingLabelStyle: formFieldFloatingLabelStyle,
        ),
        chipTheme: baseTheme.chipTheme.copyWith(
          side: BorderSide(color: softenedTokens.lineStrong, width: 0.8),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: baseTheme.outlinedButtonTheme.style?.copyWith(
            side: WidgetStatePropertyAll(
              BorderSide(color: softenedTokens.lineStrong, width: 0.8),
            ),
          ),
        ),
        extensions: [softenedTokens],
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text(tr(context, widget.trade == null ? 'addTrade' : 'editTrade')),
          actions: [
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 14),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: tokens.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: softenedTokens.lineSubtle,
                      width: 0.8,
                    ),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.account_balance_wallet_outlined, size: 15, color: tokens.text2),
                    const SizedBox(width: 6),
                    ConstrainedBox(constraints: const BoxConstraints(maxWidth: 120), child: Text(account.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.labelMedium)),
                  ]),
                ),
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: Stack(
            children: [
              ListView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: EdgeInsets.fromLTRB(6, 10, 6, _activeNumericPad == null ? 34 : 350),
                children: [
                  _sectionCard(
                    context,
                    title: _copy('النتيجة والمخاطرة', 'Result & risk'),
                    icon: Icons.query_stats_outlined,
                    tone: _resultTone,
                    gradientColors: const [Color(0xFF343D4A), Color(0xFF29323E), Color(0xFF222B36), Color(0xFF181F29)],
                    borderTone: const Color(0xFF5B6471),
                    children: [
                      Row(children: [
                        Expanded(child: _resultAmountField(suffix: account.currency)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _numericField(
                            controller: _expectedLoss,
                            focusNode: _expectedLossFocusNode,
                            key: const ValueKey('trade-expected-loss-input'),
                            label: _copy('الخسارة المتوقعة', 'Expected loss'),
                            suffix: account.currency,
                            validator: _expectedLossValidator,
                            textInputAction: TextInputAction.done,
                            onEditingComplete: _handleExpectedLossEditingComplete,
                            onSubmitted: _handleExpectedLossSubmitted,
                            onChanged: _handleExpectedLossChanged,
                          ),
                        ),
                      ]),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(child: _readoutField(controller: _risk, key: const ValueKey('trade-risk-input'), label: _copy('نسبة المخاطرة', 'Risk %'), suffix: '%')),
                        const SizedBox(width: 10),
                        Expanded(child: _readoutField(controller: _rewardRisk, key: const ValueKey('trade-reward-risk-input'), label: _copy('العائد / المخاطرة', 'Reward / risk'), suffix: 'R')),
                      ]),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _buildFormSectionNavigation(context),
                  const SizedBox(height: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Visibility(
                        visible: _activeFormSectionIndex == 0,
                        maintainState: true,
                        maintainAnimation: true,
                        child: _buildTradeDetailsSection(context),
                      ),
                      Visibility(
                        visible: _activeFormSectionIndex == 1,
                        maintainState: true,
                        maintainAnimation: true,
                        child: _buildEntryConditionsSection(context),
                      ),
                      Visibility(
                        visible: _activeFormSectionIndex == 2,
                        maintainState: true,
                        maintainAnimation: true,
                        child: _buildBehaviorCard(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _sectionCard(
                    context,
                    title: _copy('صور الصفقة', 'Trade images'),
                    icon: Icons.photo_library_outlined,
                    tone: _imagesTone,
                    gradientColors: const [Color(0xFF232A33), Color(0xFF1A2029), Color(0xFF141920)],
                    borderTone: const Color(0xFF626B74),
                    children: [
                      Row(children: [
                        Expanded(child: ImageAttachmentTile(label: _copy('قبل الدخول', 'Before entry'), path: _beforePath, onTap: () => _pickImage(_TradeImageSlot.before), onRemove: _beforePath == null ? null : () => setState(() => _beforePath = null))),
                        const SizedBox(width: 10),
                        Expanded(child: ImageAttachmentTile(label: _copy('بعد الدخول', 'After entry'), path: _afterPath, onTap: () => _pickImage(_TradeImageSlot.after), onRemove: _afterPath == null ? null : () => setState(() => _afterPath = null))),
                      ]),
                      const SizedBox(height: 12),
                      ImageAttachmentTile(key: const ValueKey('confirmation-image-attachment'), label: _copy('تأكيد الدخول', 'Entry confirmation'), path: _confirmationImagePath, onTap: () => _pickImage(_TradeImageSlot.confirmation), onRemove: _confirmationImagePath == null ? null : () => setState(() => _confirmationImagePath = null)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  _buildSaveBar(account.currency),
                ],
              ),
              if (_activeNumericPad != null)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 150),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    child: _buildNumericPad(),
                  ),
                ),
              if (_busy) Positioned.fill(child: ColoredBox(color: tokens.scrim.withValues(alpha: .26), child: const Center(child: CircularProgressIndicator()))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFormSectionNavigation(BuildContext context) {
    final tokens = TdTokens.of(context);
    final brightness = Theme.of(context).brightness;
    final conditionsTone = _hasPracticalNoEntryReason
        ? TradeDetailPalette.noEntryTone
        : TradeDetailPalette.entryConditionsLabelTone(brightness);
    final sections = <({
      String key,
      String fullAr,
      String shortAr,
      String fullEn,
      String shortEn,
      IconData icon,
      Color tone,
      Color darkSurface,
    })>[
      (
        key: 'details',
        fullAr: 'بيانات الصفقة',
        shortAr: 'بيانات',
        fullEn: 'Trade details',
        shortEn: 'Data',
        icon: Icons.receipt_long_outlined,
        tone: TradeDetailPalette.dataToneFor(brightness),
        darkSurface: TradeDetailPalette.dataSurfaceDark,
      ),
      (
        key: 'conditions',
        fullAr: 'ظروف الدخول',
        shortAr: 'ظروف',
        fullEn: 'Entry conditions',
        shortEn: 'Conditions',
        icon: Icons.radar_rounded,
        tone: conditionsTone,
        darkSurface: _hasPracticalNoEntryReason
            ? TradeDetailPalette.reviewNoEntryDark
            : TradeDetailPalette.entryConditionsPanelDark,
      ),
      (
        key: 'behavior',
        fullAr: 'سلوك التداول',
        shortAr: 'سلوك',
        fullEn: 'Trading behavior',
        shortEn: 'Behavior',
        icon: Icons.fact_check_outlined,
        tone: TradeDetailPalette.reviewTone,
        darkSurface: TradeDetailPalette.reviewOuterDark,
      ),
    ];

    return Row(
      children: [
        for (var index = 0; index < sections.length; index++) ...[
          if (index > 0) const SizedBox(width: 7),
          Expanded(
            child: _buildFormSectionTab(
              context,
              index: index,
              keyName: sections[index].key,
              fullTitle: _copy(
                sections[index].fullAr,
                sections[index].fullEn,
              ),
              shortTitle: _copy(
                sections[index].shortAr,
                sections[index].shortEn,
              ),
              icon: sections[index].icon,
              tone: sections[index].tone,
              darkSurface: sections[index].darkSurface,
              tokens: tokens,
              isDark: brightness == Brightness.dark,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildFormSectionTab(
    BuildContext context, {
    required int index,
    required String keyName,
    required String fullTitle,
    required String shortTitle,
    required IconData icon,
    required Color tone,
    required Color darkSurface,
    required TdTokens tokens,
    required bool isDark,
  }) {
    final selected = _activeFormSectionIndex == index;
    // Match the saved trade detail cards exactly instead of using the former
    // near-neutral, almost-empty tab fill.
    final surface = isDark
        ? darkSurface
        : Color.alphaBlend(tone.withValues(alpha: .075), tokens.surface1);
    final edgeAlpha = selected ? (isDark ? .20 : .16) : (isDark ? .14 : .10);
    return AnimatedContainer(
      key: ValueKey('trade-form-section-tab-surface-$keyName'),
      duration: const Duration(milliseconds: 170),
      curve: Curves.easeOutCubic,
      height: 64,
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: tone.withValues(alpha: edgeAlpha),
          width: .8,
        ),
      ),
      child: Semantics(
        button: true,
        selected: selected,
        label: fullTitle,
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            key: ValueKey('trade-form-section-tab-$keyName'),
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              if (!selected) {
                setState(() => _activeFormSectionIndex = index);
              }
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    icon,
                    size: 18,
                    color: tone.withValues(alpha: selected ? 1 : .92),
                  ),
                  const SizedBox(height: 3),
                  SizedBox(
                    width: double.infinity,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        selected ? fullTitle : shortTitle,
                        maxLines: 1,
                        softWrap: false,
                        style: TextStyle(
                          color: selected ? tokens.text1 : tokens.text2,
                          fontSize: 12.2,
                          fontWeight:
                              selected ? FontWeight.w800 : FontWeight.w600,
                          height: 1.15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTradeDetailsSection(BuildContext context) {
    final tokens = TdTokens.of(context);
    return _sectionCard(
      context,
      showHeader: false,
      bodyHorizontalPadding: 10,
      title: _copy('بيانات الصفقة', 'Trade details'),
      icon: Icons.receipt_long_outlined,
      tone: _dataTone,
      gradientColors: const [Color(0xFF123C75), Color(0xFF0F3166), Color(0xFF0B2750), Color(0xFF071529)],
      borderTone: const Color(0xFF2B64A6),
      tint: .15,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            // Pair market/direction with mindset in equal columns;
            // the multi-row anchor selector sits full-width below.
            const identifierGap = 8.0;
            final marketControlWidth =
                (constraints.maxWidth - identifierGap) / 2;
            return SizedBox(
              key: const ValueKey('trade-entry-identifiers-available'),
              width: constraints.maxWidth,
              child: SizedBox(
                key: const ValueKey('trade-entry-identifiers-row'),
                width: constraints.maxWidth,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: marketControlWidth,
                      child: SizedBox(
                        height: _tradeDataControlHeight,
                        child: InputDecorator(
                          key: const ValueKey('trade-market-direction-field'),
                          decoration: _blueSelectorDecoration(
                            label: _copy('السوق / الاتجاه', 'Market / Direction'),
                            labelWidget: Row(
                              key: const ValueKey('trade-market-direction-label'),
                              textDirection: _ar
                                  ? TextDirection.rtl
                                  : TextDirection.ltr,
                              children: [
                                Expanded(
                                  child: Text(
                                    _copy('السوق', 'Market'),
                                    textAlign: TextAlign.center,
                                    textDirection: _ar
                                        ? TextDirection.rtl
                                        : TextDirection.ltr,
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelMedium
                                        ?.copyWith(
                                          color: TdTokens.of(context).text2,
                                          fontSize: _tradeFloatingLabelFontSize,
                                          fontWeight: FontWeight.w600,
                                          height: 1.15,
                                        ),
                                  ),
                                ),
                                Text(
                                  '/',
                                  key: const ValueKey(
                                    'trade-market-direction-label-divider',
                                  ),
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelMedium
                                      ?.copyWith(
                                        color: TdTokens.of(context).text2,
                                        fontSize: _tradeFloatingLabelFontSize,
                                        fontWeight: FontWeight.w600,
                                        height: 1.15,
                                      ),
                                ),
                                Expanded(
                                  child: Text(
                                    _copy('الاتجاه', 'Direction'),
                                    textAlign: TextAlign.center,
                                    textDirection: _ar
                                        ? TextDirection.rtl
                                        : TextDirection.ltr,
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelMedium
                                        ?.copyWith(
                                          color: TdTokens.of(context).text2,
                                          fontSize: _tradeFloatingLabelFontSize,
                                          fontWeight: FontWeight.w600,
                                          height: 1.15,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                            floatingLabelAlignment:
                                FloatingLabelAlignment.center,
                            contentPadding: const EdgeInsetsDirectional.fromSTEB(10, 8, 10, 8),
                          ),
                          isEmpty: false,
                          child: Row(
                            key: const ValueKey(
                              'trade-market-direction-choices-row',
                            ),
                            crossAxisAlignment:
                                CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                child: _compactPopupChoice<String>(
                                  key: const ValueKey(
                                    'trade-market-input',
                                  ),
                                  popupAnchorKey:
                                      _marketPopupAnchorKey,
                                  itemKeyPrefix:
                                      'trade-market-option',
                                  caption: _copy('الرمز', 'Symbol'),
                                  centerContent: true,
                                  enabled: _hasTradeDirection,
                                  valueDirection: TextDirection.ltr,
                                  selectedValue: _symbol,
                                  values: const ['NQ', 'ES', 'GC'],
                                  labelFor: (value) => value,
                                  minMenuWidth: _shortChoiceMenuWidth,
                                  onSelected: _handleMarketSelected,
                                ),
                              ),
                              SizedBox(
                                width: 1,
                                height: _tradeDataContentHeight,
                                child: DecoratedBox(
                                  key: const ValueKey(
                                    'trade-market-direction-divider',
                                  ),
                                  decoration: BoxDecoration(
                                    color: TdTokens.of(context)
                                        .accent
                                        .withValues(alpha: .38),
                                    borderRadius:
                                        BorderRadius.circular(1),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: _compactPopupChoice<TradeSide>(
                                  key: const ValueKey(
                                    'trade-direction-selector',
                                  ),
                                  popupAnchorKey:
                                      _directionPopupAnchorKey,
                                  itemKeyPrefix:
                                      'trade-direction-option',
                                  caption: _copy(
                                    'الاتجاه',
                                    'Direction',
                                  ),
                                  centerContent: true,
                                  enabled: true,
                                  valueDirection: _ar
                                      ? TextDirection.rtl
                                      : TextDirection.ltr,
                                  selectedValue: _side,
                                  values: TradeSide.values,
                                  labelFor: (value) => tr(
                                    context,
                                    value == TradeSide.buy
                                        ? 'buy'
                                        : 'sell',
                                  ),
                                  minMenuWidth: _shortChoiceMenuWidth,
                                  onSelected: _handleDirectionSelected,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: identifierGap),
                    SizedBox(
                      width: marketControlWidth,
                      child: _buildMindsetSelector(
                        enabled: _hasTradeDirection,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        KeyedSubtree(
          key: _entryReasonSectionKey,
          child: _setupSelectionField(
          title: _copy('سبب الدخول', 'Entry reason'),
          enabled: _hasTradeDirection,
          setups: _entrySetups
              .map((item) => (
                    label: formatTradeEntryReasonLabel(
                      reason: item.reason,
                      side: _side,
                    ),
                    timeframe: item.timeframe,
                    item: item,
                  ))
              .toList(),
          onAdd: _addEntrySetup,
          onRemove: (item) => _removeEntrySetup(item as TradeEntrySetup),
          onEdit: (item) => _editEntrySetup(item as TradeEntrySetup),
          fieldKey: const ValueKey('add-entry-setup'),
          fieldId: 'entry-reason',
          surfaceKey: const ValueKey('entry-reason-field-surface'),
          decoratorKey: const ValueKey('entry-reason-field-input'),
          collapsed: _collapsedSelectionFields.contains('entry-reason'),
          onCollapsedChanged: (value) =>
              _setSelectionFieldCollapsed('entry-reason', value),
        ),
        ),
        const SizedBox(height: 12),
        _anchorMultiSelector(),
        const SizedBox(height: 12),
        KeyedSubtree(
          key: _confirmationSectionKey,
          child: _setupSelectionField(
          title: _copy('تأكيد الدخول', 'Entry confirmation'),
          enabled: _hasTradeDirection,
          setups: _confirmationSetups
              .map((item) => (
                    label: _confirmationLabel(item.type),
                    timeframe: item.timeframe,
                    item: item,
                  ))
              .toList(),
          onAdd: _addConfirmationSetup,
          onRemove: (item) => _removeConfirmationSetup(item as TradeConfirmationSetup),
          onEdit: (item) => _editConfirmationSetup(item as TradeConfirmationSetup),
          fieldKey: const ValueKey('add-confirmation-setup'),
          fieldId: 'confirmation',
          surfaceKey: const ValueKey('confirmation-field-surface'),
          decoratorKey: const ValueKey('confirmation-field-input'),
          collapsed: _collapsedSelectionFields.contains('confirmation'),
          onCollapsedChanged: (value) =>
              _setSelectionFieldCollapsed('confirmation', value),
        ),
        ),
        if (_exitSectionTitle != null) ...[
          const SizedBox(height: 12),
          KeyedSubtree(
            key: _exitReasonSectionKey,
            child: _setupSelectionField(
            title: _exitSectionTitle!,
            enabled: _hasTradeDirection,
            setups: _exitReasonSetups
                .map((item) => (
                      label: tradeExitReasonLabel(
                        item.type,
                        arabic: _ar,
                        side: _side,
                      ),
                      timeframe: item.timeframe,
                      item: item,
                    ))
                .toList(),
            onAdd: _addExitReasonSetup,
            onRemove: (item) =>
                _removeExitReasonSetup(item as TradeConfirmationSetup),
            onEdit: (item) =>
                _editExitReasonSetup(item as TradeConfirmationSetup),
            fieldKey: const ValueKey('add-exit-reason-setup'),
            fieldId: 'exit-reason',
            surfaceKey: const ValueKey('exit-reason-field-surface'),
            decoratorKey: const ValueKey('exit-reason-field-input'),
            collapsed: _collapsedSelectionFields.contains('exit-reason'),
            onCollapsedChanged: (value) =>
                _setSelectionFieldCollapsed('exit-reason', value),
          ),
          ),
        ],
        const SizedBox(height: 14),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Semantics(
            label: _copy(
              'تاريخ / الوقت: ${_formattedTradeDateTime(context)}',
              'Date / time: ${_formattedTradeDateTime(context)}',
            ),
            button: true,
            child: Tooltip(
              message: _copy('تاريخ / الوقت', 'Date / time'),
              child: OutlinedButton(
                key: const ValueKey('trade-date-time-picker-button'),
                onPressed: _hasTradeDirection ? _pickDateTime : null,
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(136, 48),
                  padding: const EdgeInsetsDirectional.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  foregroundColor: tokens.text2,
                  backgroundColor: Colors.transparent,
                  side: BorderSide(
                    color: tokens.lineStrong.withValues(alpha: .55),
                    width: .8,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _copy('تاريخ / الوقت', 'Date / time'),
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(
                            color: tokens.text2,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    const SizedBox(width: 9),
                    Flexible(
                      child: Text(
                        _formattedTradeDateTime(context),
                        key: const ValueKey('trade-date-time-value'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textDirection: TextDirection.ltr,
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(
                              color: tokens.text1,
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  String _confirmationLabel(String type) {
    final displayKey = tradeConfirmationDisplayKey(type: type, side: _side);
    if (displayKey == 'confirmBullishEngulfing') return 'Bullish Engulfing';
    if (displayKey == 'confirmBearishEngulfing') return 'Bearish Engulfing';
    if (displayKey == 'confirmEngulfing') return 'Engulfing';
    final known = tradeConfirmationOptions
        .where((item) => item.key == displayKey)
        .firstOrNull;
    if (known != null) return _ar ? known.ar : known.en;
    return type;
  }

  Widget _sectionCard(
    BuildContext context, {
    Key? key,
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? tone,
    Color? borderTone,
    List<Color>? gradientColors,
    double tint = .10,
    double bodyHorizontalPadding = 16,
    bool showHeader = true,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // A smaller body padding widens the section's content; the header keeps
    // its original inset so the title does not move.
    final headerInset = 16 - bodyHorizontalPadding;
    final headerRow = Row(children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: tone == null ? tokens.surface3 : tone.withValues(alpha: isDark ? .16 : .11),
            borderRadius: BorderRadius.circular(10),
            border: tone == null ? null : Border.all(color: tone.withValues(alpha: .14), width: 0.8),
          ),
          child: Icon(icon, size: 18, color: tone ?? tokens.accent),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
      ]);
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (showHeader) ...[
          headerInset == 0
              ? headerRow
              : Padding(
                  padding: EdgeInsets.symmetric(horizontal: headerInset),
                  child: headerRow,
                ),
          const SizedBox(height: 16),
        ],
        ...children,
      ],
    );

    if (tone == null) {
      return AppCard(padding: const EdgeInsets.all(16), sheen: false, child: content);
    }
    Widget sectionContent = content;
    if (identical(tone, _dataTone) || tone == _dataTone) {
      final baseTheme = Theme.of(context);
      final fieldFill = isDark
          ? const Color(0xFF071834)
          : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);
      final fieldBorder = OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(
          color: isDark
              ? const Color(0xFF21405B).withValues(alpha: .52)
              : tokens.lineSubtle.withValues(alpha: .68),
          width: 0.78,
        ),
      );
      final sectionFieldLabelStyle = baseTheme.textTheme.labelMedium?.copyWith(
        color: tokens.text2,
        fontSize: _tradeFieldLabelFontSize,
        fontWeight: FontWeight.w600,
        height: 1.15,
      );
      final sectionFieldFloatingLabelStyle = sectionFieldLabelStyle?.copyWith(
        fontSize: _tradeFloatingLabelFontSize,
      );
      sectionContent = Theme(
        data: baseTheme.copyWith(
          inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
            filled: true,
            fillColor: fieldFill,
            enabledBorder: fieldBorder,
            border: fieldBorder,
            focusedBorder: fieldBorder.copyWith(
              borderSide: BorderSide(
                color: _dataTone.withValues(alpha: .78),
                width: 1.05,
              ),
            ),
            labelStyle: sectionFieldLabelStyle,
            floatingLabelStyle: sectionFieldFloatingLabelStyle,
          ),
        ),
        child: content,
      );
    }
    final neutralSurface = tone == _resultTone || tone == _imagesTone;
    return Container(
      key: key,
      padding: EdgeInsets.fromLTRB(bodyHorizontalPadding, 16, bodyHorizontalPadding, 16),
      decoration: BoxDecoration(
        color: Color.alphaBlend(tone.withValues(alpha: isDark ? tint : tint * .58), tokens.surface1),
        gradient: !isDark || gradientColors == null
            ? null
            : neutralSurface
                ? LinearGradient(
                    begin: AlignmentDirectional.topStart,
                    end: AlignmentDirectional.bottomEnd,
                    colors: [tokens.surface2, tokens.surface1],
                  )
                : LinearGradient(
                    begin: AlignmentDirectional.topStart,
                    end: AlignmentDirectional.bottomEnd,
                    colors: gradientColors,
                    stops: gradientColors.length == 4
                        ? const [0, .32, .68, 1]
                        : null,
                  ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: neutralSurface && isDark
              ? tokens.lineSubtle
              : (borderTone ?? tone).withValues(alpha: isDark ? .17 : .13),
          width: 0.8,
        ),
      ),
      child: sectionContent,
    );
  }

  Widget _resultTypeChoice({
    required String label,
    required int sign,
    required Key key,
  }) {
    final tokens = TdTokens.of(context);
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        key: key,
        borderRadius: BorderRadius.circular(8),
        onTap: () {
          HapticFeedback.selectionClick();
          _selectResultSign(sign);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: tokens.lineSubtle.withValues(alpha: .48),
              width: .7,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: tokens.text2,
              fontSize: _tradeDataItemFontSize,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  Widget _resultAmountField({required String suffix}) {
    final showTypeChoices = _resultSign == null &&
        _showResultSignChoices &&
        !_hasEntryConditionsNoEntryLink;
    return Stack(
      alignment: Alignment.center,
      children: [
        TextFormField(
          key: const ValueKey('trade-result-input'),
          controller: _result,
          focusNode: _resultFocusNode,
          validator: _resultValidator,
          readOnly: true,
          showCursor: true,
          enableInteractiveSelection: false,
          onTap: () => _activateNumericPad(_NumericEntryTarget.result),
          textInputAction: TextInputAction.done,
          onEditingComplete: _handleResultEditingComplete,
          onFieldSubmitted: _handleResultSubmitted,
          keyboardType: TextInputType.none,
          inputFormatters: [
            TextInputFormatter.withFunction((oldValue, newValue) {
              final valid = RegExp(r'^[+\-−]?[0-9]*[.,]?[0-9]*$');
              return valid.hasMatch(newValue.text) ? newValue : oldValue;
            }),
          ],
          textDirection: TextDirection.ltr,
          textAlign: TextAlign.start,
          onChanged: _handleResultChanged,
          decoration: InputDecoration(
            // Keep the original floating field heading visible in every
            // result state, not only when an opposing-signal link is active.
            // The field title is intentionally hidden while the in-field
            // Profit / Loss choices are visible; otherwise the same wording
            // appears twice. Restore the floating title immediately after
            // the trader chooses a sign, preserving the original field label
            // for the amount-entry state.
            labelText: showTypeChoices
                ? null
                : _copy('الربح / الخسارة', 'Profit / loss'),
            floatingLabelBehavior: FloatingLabelBehavior.auto,
            prefixText: _ar ? suffix : null,
            suffixText: _ar ? null : suffix,
            contentPadding: const EdgeInsetsDirectional.fromSTEB(12, 16, 12, 16),
          ),
        ),
        if (showTypeChoices)
          Positioned.fill(
            child: IgnorePointer(
              ignoring: false,
              child: Center(
                child: Directionality(
                  textDirection: _ar ? TextDirection.rtl : TextDirection.ltr,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _resultTypeChoice(
                        label: _copy('الربح', 'Profit'),
                        sign: 1,
                        key: const ValueKey('trade-result-sign-positive'),
                      ),
                      const SizedBox(width: 7),
                      Text(
                        '/',
                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: TdTokens.of(context).text3,
                          fontSize: _tradeDataItemFontSize,
                        ),
                      ),
                      const SizedBox(width: 7),
                      _resultTypeChoice(
                        label: _copy('الخسارة', 'Loss'),
                        sign: -1,
                        key: const ValueKey('trade-result-sign-negative'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _numericField({required TextEditingController controller, required Key key, required String label, required String suffix, required String? Function(String?) validator, FocusNode? focusNode, TextInputAction? textInputAction, VoidCallback? onEditingComplete, ValueChanged<String>? onSubmitted, ValueChanged<String>? onChanged}) => TextFormField(
        key: key,
        controller: controller,
        focusNode: focusNode,
        validator: validator,
        readOnly: true,
        showCursor: true,
        enableInteractiveSelection: false,
        onTap: () {
          if (identical(controller, _expectedLoss)) {
            _activateNumericPad(_NumericEntryTarget.expectedLoss);
          }
        },
        textInputAction: textInputAction,
        onEditingComplete: onEditingComplete,
        onFieldSubmitted: onSubmitted,
        onChanged: onChanged,
        keyboardType: TextInputType.none,
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.start,
        decoration: InputDecoration(labelText: label, suffixText: suffix),
      );

  Widget _readoutField({required TextEditingController controller, required Key key, required String label, required String suffix}) => Focus(
        // Computed values are display-only and must never intercept the
        // guided keyboard sequence between Expected Loss and Direction.
        canRequestFocus: false,
        skipTraversal: true,
        descendantsAreFocusable: false,
        child: TextFormField(
          key: key,
          controller: controller,
          readOnly: true,
          textDirection: TextDirection.ltr,
          decoration: InputDecoration(labelText: label, suffixText: suffix, filled: true, fillColor: TdTokens.of(context).inset),
        ),
      );

  Widget _fieldLabel(String label) => Text(label, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700));

  List<String> get _orderedAnchorKeys {
    final known = tradeAnchorOptions
        .where((option) => _anchors.contains(option.key))
        .map((option) => option.key);
    final knownSet = known.toSet();
    final legacyOrUnknown = _anchors.where((key) => !knownSet.contains(key));
    return [...known, ...legacyOrUnknown].toList(growable: false);
  }

  String _anchorSelectionLabel(String anchorKey) => formatTradeAnchorLabel(
        anchorKey: anchorKey,
        arabic: _ar,
        side: _side,
      );

  String? _selectedAnchorStorageKey(String optionKey, Set<String> selected) {
    if (selected.contains(optionKey)) return optionKey;
    if (optionKey == 'zoneSd') {
      // Old trades may contain the two former concrete choices. Treat the
      // direction-matching legacy key as the selected Zone S/D row.
      final preferredLegacyKey = _side == TradeSide.buy
          ? 'demandZone'
          : _side == TradeSide.sell
              ? 'supplyZone'
              : 'demandZone';
      if (selected.contains(preferredLegacyKey)) return preferredLegacyKey;
      if (selected.contains('demandZone')) return 'demandZone';
      if (selected.contains('supplyZone')) return 'supplyZone';
    }
    if (optionKey == 'engulfing') {
      // Existing trades keep their historical concrete anchor label, but
      // both keys are represented by the single Engulfing picker row.
      final preferredLegacyKey = _side == TradeSide.buy
          ? 'bullishEngulfing'
          : _side == TradeSide.sell
              ? 'bearishEngulfing'
              : 'bullishEngulfing';
      if (selected.contains(preferredLegacyKey)) return preferredLegacyKey;
      if (selected.contains('bullishEngulfing')) return 'bullishEngulfing';
      if (selected.contains('bearishEngulfing')) return 'bearishEngulfing';
    }
    return null;
  }

  String _anchorTimeframeContextLabel(String anchorKey) =>
      '${_copy('الارتكاز', 'Anchor')} · ${_anchorSelectionLabel(anchorKey)}';

  Future<void> _pickAnchors() async {
    if (!_hasTradeDirection) return;
    if (_isGuidedSection(_AutoEntryStep.anchors)) {
      await _runGuidedSection(_AutoEntryStep.anchors);
      return;
    }
    if (await _guideThroughMissing(_AutoEntryStep.anchors)) return;
    await _showAnchorsDialog();
  }

  /// Returns true when the trader left through the guided Continue button.
  Future<bool> _showAnchorsDialog({bool guided = false}) async {
    final selected = {..._anchors};
    final brightness = Theme.of(context).brightness;
    final tokens = TdTokens.of(context);
    final screen = MediaQuery.sizeOf(context);
    final dialogWidth = (screen.width - 56).clamp(240.0, 360.0).toDouble();
    final dialogMaxHeight =
        (screen.height * .68).clamp(220.0, 560.0).toDouble();

    final continued = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => Dialog(
          key: const ValueKey('trade-centered-multi-choice-anchor'),
          backgroundColor: tdPopupMenuColor(brightness),
          surfaceTintColor: Colors.transparent,
          elevation: 9,
          shape: tdTradeDataPopupMenuShape(brightness),
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: SizedBox(
            width: dialogWidth,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: dialogMaxHeight),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
                      child: Text(
                        _copy('الارتكاز', 'Anchor'),
                        style: Theme.of(dialogContext)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              color: tokens.text1,
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: tdTradeDataPopupMenuBorderColor(brightness)
                          .withValues(alpha: .48),
                    ),
                    const SizedBox(height: 5),
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemCount: tradeAnchorOptions.length,
                        separatorBuilder: (_, _) =>
                            const SizedBox(height: 2),
                        itemBuilder: (itemContext, index) {
                          final option = tradeAnchorOptions[index];
                          final selectedStorageKey =
                              _selectedAnchorStorageKey(option.key, selected);
                          final isSelected = selectedStorageKey != null;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 1),
                            child: ListTile(
                              key: ValueKey(
                                'trade-anchor-option-${option.key}',
                              ),
                              minTileHeight: 48,
                              minVerticalPadding: 8,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 11,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9),
                              ),
                              selected: isSelected,
                              selectedTileColor:
                                  tokens.accent.withValues(alpha: .09),
                              title: Text(
                                _ar ? option.ar : option.en,
                                softWrap: true,
                                style: Theme.of(itemContext)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: tokens.text1,
                                      fontSize: _tradeDataItemFontSize,
                                      fontWeight: isSelected
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                    ),
                              ),
                              trailing: Icon(
                                isSelected
                                    ? Icons.check_circle_rounded
                                    : Icons.chevron_left_rounded,
                                size: 18,
                                color: isSelected
                                    ? tokens.accent
                                    : tokens.text3,
                              ),
                              onTap: () async {
                                // Selected rows show a check; tapping one opens
                                // its timeframe list with the chosen timeframes
                                // checked. A new timeframe adds the same anchor
                                // again, a checked one removes it.
                                final storageKey =
                                    selectedStorageKey ?? option.key;
                                final frame = await _showTimeframeSheet(
                                  contextLabel:
                                      _anchorTimeframeContextLabel(option.key),
                                  selectedFrames:
                                      _anchorFrames(storageKey).toSet(),
                                );
                                if (frame == null || !mounted) return;
                                _toggleAnchorFrame(
                                  option.key,
                                  storageKey,
                                  frame,
                                );
                                setDialogState(() {
                                  selected
                                    ..clear()
                                    ..addAll(_anchors);
                                });
                              },
                            ),
                          );
                        },
                      ),
                    ),
                    if (guided) ...[
                      const SizedBox(height: 8),
                      Divider(
                        height: 1,
                        color: tdTradeDataPopupMenuBorderColor(brightness)
                            .withValues(alpha: .48),
                      ),
                      const SizedBox(height: 10),
                      _guidedContinueButton(
                        tokens: tokens,
                        onTap: () => Navigator.pop(dialogContext, true),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    return continued == true;
  }

  Future<void> _editAnchorTimeframe(String anchorKey, {String? frame}) async {
    if (!_hasTradeDirection) return;
    if (_redirectToMissingGuidedField(_AutoEntryStep.anchors)) return;
    final picked = await _showTimeframeSheet(
      contextLabel: _anchorTimeframeContextLabel(anchorKey),
      selectedFrame: frame,
    );
    if (picked == null || !mounted) return;
    setState(() {
      final frames = _anchorFrames(anchorKey).toList();
      if (frame != null) frames.remove(frame);
      if (!frames.contains(picked)) frames.add(picked);
      _anchorTimeframes[anchorKey] = joinAnchorTimeframes(frames)!;
    });
  }

  void _removeAnchor(String anchorKey, {String? frame}) {
    if (!_hasTradeDirection) return;
    setState(() {
      final frames = frame == null
          ? <String>[]
          : (_anchorFrames(anchorKey).toList()..remove(frame));
      final joined = joinAnchorTimeframes(frames);
      if (joined == null) {
        _anchors.remove(anchorKey);
        _anchorTimeframes.remove(anchorKey);
      } else {
        _anchorTimeframes[anchorKey] = joined;
      }
    });
  }

  Widget _anchorMultiSelector() {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedKeys = _orderedAnchorKeys;
    final anchorEntries = _anchorEntries(selectedKeys);
    final dataFieldFill = isDark
        ? const Color(0xFF071834)
        : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);

    return Opacity(
      opacity: _hasTradeDirection ? 1 : .52,
      child: KeyedSubtree(
        key: const ValueKey('trade-anchor-selector'),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
          key: _anchorMenuAnchorKey,
          onTap: _hasTradeDirection ? _pickAnchors : null,
          borderRadius: BorderRadius.circular(14),
          child: InputDecorator(
            key: const ValueKey('trade-anchor-field-input'),
            decoration: _blueSelectorDecoration(
              label: _copy('الارتكاز', 'Anchor'),
              labelWidget: _collapsibleSelectionFieldLabel(
                title: _copy('الارتكاز', 'Anchor'),
                fieldId: 'anchors',
                hasSelection: selectedKeys.isNotEmpty,
                collapsed: _anchorValuesCollapsed,
                onToggle: () => setState(
                  () => _anchorValuesCollapsed = !_anchorValuesCollapsed,
                ),
                onAdd: _pickAnchors,
              ),
              tone: _dataTone,
              fillColorOverride: dataFieldFill,
              floatingLabelAlignment: FloatingLabelAlignment.start,
              trailingIcon: Icons.keyboard_arrow_down_rounded,
              contentPadding: const EdgeInsetsDirectional.fromSTEB(
                12,
                14,
                10,
                12,
              ),
            ),
            isEmpty: selectedKeys.isEmpty,
            child: selectedKeys.isEmpty
                ? const SizedBox(height: 30)
                : _anchorValuesCollapsed
                    ? DecisionSelectionSummary(
                        key: const ValueKey('trade-anchor-selected-summary'),
                        itemKeyPrefix: 'anchor',
                        stacked: true,
                        latinLabels: !_ar,
                        labels: [
                          for (final entry in anchorEntries)
                            '${_anchorSelectionLabel(entry.key)}${entry.frame == null ? '' : ' ${entry.frame}'}',
                        ],
                        tone: _dataTone,
                        onTap: () => setState(
                          () => _anchorValuesCollapsed = false,
                        ),
                      )
                    : Column(
                    key: const ValueKey('trade-anchor-selected-values'),
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (var index = 0; index < anchorEntries.length; index++) ...[
                        if (index > 0)
                          Divider(
                            height: 8,
                            thickness: .6,
                            color: _dataTone.withValues(alpha: .22),
                          ),
                        Builder(
                          builder: (rowContext) {
                            final entry = anchorEntries[index];
                            final anchorKey = entry.key;
                            final entryId = _anchorEntryId(entry);
                            final label = _anchorSelectionLabel(anchorKey);
                            final timeframe = entry.frame;
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      key: ValueKey(
                                        'trade-anchor-value-$entryId',
                                      ),
                                      borderRadius: BorderRadius.circular(6),
                                      onTap: _hasTradeDirection
                                          ? () => _editAnchorTimeframe(
                                              anchorKey,
                                              frame: timeframe,
                                            )
                                          : null,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 6,
                                        ),
                                        child: Text(
                                          timeframe == null
                                              ? label
                                              : '$label $timeframe',
                                          softWrap: true,
                                          textAlign: _ar
                                              ? TextAlign.right
                                              : TextAlign.left,
                                          textDirection: TextDirection.ltr,
                                          style: Theme.of(rowContext)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: tokens.text1,
                                                fontSize: _tradeDataItemFontSize,
                                                fontWeight: FontWeight.w700,
                                                height: 1.35,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  key: ValueKey(
                                    'trade-anchor-remove-$entryId',
                                  ),
                                  tooltip: _copy(
                                    'حذف الارتكاز',
                                    'Remove anchor',
                                  ),
                                  visualDensity: VisualDensity.compact,
                                  constraints: const BoxConstraints.tightFor(
                                    width: 32,
                                    height: 32,
                                  ),
                                  padding: EdgeInsets.zero,
                                  onPressed: _hasTradeDirection
                                      ? () => _removeAnchor(anchorKey, frame: timeframe)
                                      : null,
                                  icon: Icon(
                                    Icons.close_rounded,
                                    size: 16,
                                    color: tokens.text3,
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ],
                  ),
          ),
          ),
        ),
      ),
    );
  }

  Widget _buildMindsetSelector({required bool enabled}) {
    final selectedItems = tradeMoodOptions
        .where((item) => _selectedMoods.contains(item.key))
        .toList(growable: false);
    final displayItems = selectedItems.isEmpty ||
            selectedItems.every((item) => item.key == 'moodUnknown')
        ? [tradeMoodOptions.firstWhere((item) => item.key == 'moodUnknown')]
        : selectedItems.where((item) => item.key != 'moodUnknown').toList();
    final displayLabel = displayItems.map((item) => _ar ? item.ar : item.en).join('، ');
    final hasRecordedMood = displayItems.any((item) => item.key != 'moodUnknown');

    return InkWell(
      key: const ValueKey('trade-mood-dropdown'),
      onTap: enabled ? _showMindsetMultiSelect : null,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        key: const ValueKey('trade-mood-field'),
        height: _tradeDataControlHeight,
        child: InputDecorator(
          key: const ValueKey('trade-mood-field-surface'),
          decoration: _blueSelectorDecoration(
            label: _copy('الحالة النفسية', 'Mindset'),
            contentPadding: const EdgeInsetsDirectional.fromSTEB(
              10,
              8,
              10,
              8,
            ),
          ),
          isEmpty: false,
          child: Opacity(
            opacity: enabled ? 1 : .52,
            child: SizedBox(
              key: const ValueKey('trade-mood-content'),
              height: _tradeDataContentHeight,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(
                        displayLabel,
                        key: const ValueKey('trade-mood-selected-value'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: hasRecordedMood
                              ? TdTokens.of(context).text1
                              : TdTokens.of(context).text2,
                          fontSize: _tradeDataItemFontSize,
                          fontWeight: hasRecordedMood
                              ? FontWeight.w700
                              : FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down_rounded,
                    size: 18,
                    color: TdTokens.of(context).text3,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _collapsibleSelectionFieldLabel({
    required String title,
    required String fieldId,
    required bool hasSelection,
    required bool collapsed,
    required VoidCallback onToggle,
    required VoidCallback onAdd,
  }) {
    final tokens = TdTokens.of(context);
    return Semantics(
      button: true,
      label: title,
      child: InkWell(
        key: ValueKey('trade-selection-field-title-$fieldId'),
        borderRadius: BorderRadius.circular(5),
        onTap: hasSelection ? onToggle : onAdd,
        child: Padding(
          padding: const EdgeInsetsDirectional.only(end: 3, top: 2, bottom: 2),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              if (hasSelection) ...[
                const SizedBox(width: 4),
                Icon(
                  collapsed
                      ? Icons.unfold_more_rounded
                      : Icons.unfold_less_rounded,
                  size: 15,
                  color: tokens.text3,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _setSelectionFieldCollapsed(String fieldId, bool value) {
    setState(() {
      if (value) {
        _collapsedSelectionFields.add(fieldId);
      } else {
        _collapsedSelectionFields.remove(fieldId);
      }
    });
  }

  Widget _setupSelectionField({
    required String title,
    required bool enabled,
    required List<({String label, String timeframe, Object item})> setups,
    required Future<void> Function() onAdd,
    required void Function(Object) onRemove,
    required void Function(Object) onEdit,
    required Key fieldKey,
    required String fieldId,
    required Key surfaceKey,
    required Key decoratorKey,
    required bool collapsed,
    required ValueChanged<bool> onCollapsedChanged,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final hasSelection = setups.isNotEmpty;
    final dataFieldFill = isDark
        ? const Color(0xFF071834)
        : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);

    return Opacity(
      opacity: enabled ? 1 : .52,
      child: Container(
        key: surfaceKey,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            key: fieldKey,
            onTap: enabled ? onAdd : null,
            borderRadius: BorderRadius.circular(14),
            child: InputDecorator(
            key: decoratorKey,
            decoration: _blueSelectorDecoration(
              label: title,
              labelWidget: _collapsibleSelectionFieldLabel(
                title: title,
                fieldId: fieldId,
                hasSelection: hasSelection,
                collapsed: collapsed,
                onToggle: () => onCollapsedChanged(!collapsed),
                onAdd: onAdd,
              ),
              tone: _dataTone,
              fillColorOverride: dataFieldFill,
              floatingLabelAlignment: FloatingLabelAlignment.start,
              trailingIcon: Icons.keyboard_arrow_down_rounded,
              contentPadding: const EdgeInsetsDirectional.fromSTEB(
                12,
                14,
                10,
                12,
              ),
            ),
            isEmpty: !hasSelection,
            child: hasSelection && collapsed
                ? DecisionSelectionSummary(
                    key: ValueKey('trade-setup-summary-$fieldId'),
                    itemKeyPrefix: 'setup-$fieldId',
                    stacked: true,
                    latinLabels: !_ar,
                    labels: [
                      for (final setup in setups)
                        '${setup.label} ${setup.timeframe.isEmpty ? _copy('دون فريم', 'No timeframe') : setup.timeframe}',
                    ],
                    tone: _dataTone,
                    onTap: () => onCollapsedChanged(false),
                  )
                : hasSelection
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (var index = 0; index < setups.length; index++) ...[
                        if (index > 0)
                          Divider(
                            height: 8,
                            thickness: .6,
                            color: _dataTone.withValues(alpha: .22),
                          ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  key: ValueKey(
                                    'trade-setup-edit-$fieldId-$index',
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                  onTap: enabled
                                      ? () => onEdit(setups[index].item)
                                      : null,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 5,
                                    ),
                                    child: Text(
                                      '${setups[index].label} ${setups[index].timeframe.isEmpty ? _copy('دون فريم', 'No timeframe') : setups[index].timeframe}',
                                      key: ValueKey(
                                        'trade-setup-value-$fieldId-$index',
                                      ),
                                      softWrap: true,
                                      textAlign: _ar ? TextAlign.right : TextAlign.left,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: tokens.text1,
                                            fontSize: _tradeDataItemFontSize,
                                            fontWeight: FontWeight.w700,
                                            height: 1.4,
                                          ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              key: ValueKey(
                                'trade-setup-remove-$fieldId-$index',
                              ),
                              tooltip: _copy('حذف الاختيار', 'Remove selection'),
                              visualDensity: VisualDensity.compact,
                              constraints: const BoxConstraints.tightFor(
                                width: 32,
                                height: 32,
                              ),
                              padding: EdgeInsets.zero,
                              onPressed: enabled
                                  ? () => onRemove(setups[index].item)
                                  : null,
                              icon: Icon(
                                Icons.close_rounded,
                                size: 16,
                                color: tokens.text3,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  )
                : const SizedBox(height: 30),
            ),
          ),
        ),
      ),
    );
  }

  Widget _entryConditionField({
    required Key key,
    required Key addKey,
    required Key surfaceKey,
    required Key wrapperKey,
    required String title,
    required String fieldId,
    required bool collapsed,
    required ValueChanged<bool> onCollapsedChanged,
    required List<TradeEntryConditionSetup> setups,
    required List<TradeEntryOption> options,
    required Color tone,
    required bool enabled,
    required Future<void> Function() onAdd,
    required void Function(TradeEntryConditionSetup) onRemove,
    required void Function(TradeEntryConditionSetup) onEdit,
    Set<TradeEntryConditionSetup> practicalNoEntrySetups = const {},
    ValueChanged<TradeEntryConditionSetup>? onLongPressSetup,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isPracticallyLinked = practicalNoEntrySetups.isNotEmpty;
    final entryConditionFieldFill = isPracticallyLinked
        ? (isDark
            ? TradeDetailPalette.linkedEntryConditionsFieldDark
            : Color.alphaBlend(_noEntryTone.withValues(alpha: .075), tokens.surface2))
        // Unlinked Opposing signals / Bounce area fields carry the same tint
        // as the Entry Conditions timeframe list instead of neutral grey.
        : _entryConditionsSurface(
            tokens: tokens,
            tone: tone,
            brightness: Theme.of(context).brightness,
          );

    String optionLabel(String optionKey) => options
        .where((option) => option.key == optionKey)
        .map((option) => _ar ? option.ar : option.en)
        .firstOrNull ?? optionKey;

    String setupLabel(TradeEntryConditionSetup setup) =>
        formatTradeEntryConditionSetupLabel(
          setup: setup,
          optionLabel: optionLabel(setup.optionKey),
          arabic: _ar,
          side: _side,
        );

    final hasSelection = setups.isNotEmpty;
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: KeyedSubtree(
        key: addKey,
        child: KeyedSubtree(
          key: wrapperKey,
          child: Container(
            key: surfaceKey,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                key: key,
                borderRadius: BorderRadius.circular(14),
                onTap: enabled ? onAdd : null,
                child: InputDecorator(
                  decoration: _blueSelectorDecoration(
                    label: title,
                    labelWidget: _collapsibleSelectionFieldLabel(
                      title: title,
                      fieldId: fieldId,
                      hasSelection: hasSelection,
                      collapsed: collapsed,
                      onToggle: () => onCollapsedChanged(!collapsed),
                      onAdd: onAdd,
                    ),
                    tone: tone,
                    fillColorOverride: entryConditionFieldFill,
                    borderColorOverride: isPracticallyLinked
                        ? (isDark
                            ? TradeDetailPalette.linkedEntryConditionsFieldEdge
                                .withValues(alpha: .18)
                            : _noEntryTone.withValues(alpha: .17))
                        : null,
                    trailingIcon: Icons.keyboard_arrow_down_rounded,
                    contentPadding:
                        const EdgeInsetsDirectional.fromSTEB(12, 14, 10, 12),
                  ),
                  isEmpty: !hasSelection,
                  child: hasSelection && collapsed
                      ? DecisionSelectionSummary(
                          key: ValueKey('entry-condition-summary-$fieldId'),
                          itemKeyPrefix: 'entry-condition-$fieldId',
                          stacked: true,
                          latinLabels: !_ar,
                          labels: [
                            for (final setup in setups) setupLabel(setup),
                          ],
                          trailingWidgets: [
                            for (final setup in setups)
                              if (practicalNoEntrySetups.contains(setup))
                                Tooltip(
                                  message: _copy(
                                    'سبب عملي لعدم الدخول — اضغط مطولاً لإلغاء الربط',
                                    'Practical no-entry reason — long-press to unlink',
                                  ),
                                  child: Icon(
                                    Icons.link_rounded,
                                    size: 15,
                                    color: _noEntryTone,
                                  ),
                                )
                              else
                                null,
                          ],
                          tone: isPracticallyLinked ? _noEntryTone : tone,
                          onTap: () => onCollapsedChanged(false),
                        )
                      : hasSelection
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            for (var index = 0; index < setups.length; index++) ...[
                              if (index > 0)
                                Divider(
                                  height: 8,
                                  thickness: .6,
                                  color: tone.withValues(alpha: .17),
                                ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(6),
                                        onTap: enabled
                                            ? () => onEdit(setups[index])
                                            : null,
                                        onLongPress: enabled && onLongPressSetup != null
                                            ? () => onLongPressSetup!(setups[index])
                                            : null,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 5,
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  setupLabel(setups[index]),
                                                  key: ValueKey(
                                                    'entry-condition-label-${setups[index].optionKey}-${setups[index].timeframe}-${setups[index].secondaryTimeframe ?? ''}-${setups[index].touch2}',
                                                  ),
                                                  softWrap: true,
                                                  maxLines: null,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodySmall
                                                      ?.copyWith(
                                                        color: tokens.text1,
                                                        fontSize: _tradeDataItemFontSize,
                                                        fontWeight: FontWeight.w700,
                                                        height: 1.4,
                                                      ),
                                                ),
                                              ),
                                              if (practicalNoEntrySetups.contains(setups[index]))
                                                Padding(
                                                  padding: const EdgeInsetsDirectional.only(start: 7),
                                                  child: Tooltip(
                                                    message: _copy(
                                                      'سبب عملي لعدم الدخول — اضغط مطولاً لإلغاء الربط',
                                                      'Practical no-entry reason — long-press to unlink',
                                                    ),
                                                    child: Icon(
                                                      Icons.link_rounded,
                                                      key: ValueKey('practical-no-entry-link-${setups[index].optionKey}-${setups[index].timeframe}'),
                                                      size: 15,
                                                      color: _noEntryTone,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: _copy(
                                      'حذف الاختيار',
                                      'Remove selection',
                                    ),
                                    visualDensity: VisualDensity.compact,
                                    constraints: const BoxConstraints.tightFor(
                                      width: 32,
                                      height: 32,
                                    ),
                                    padding: EdgeInsets.zero,
                                    onPressed: enabled
                                        ? () => onRemove(setups[index])
                                        : null,
                                    icon: Icon(
                                      Icons.close_rounded,
                                      size: 16,
                                      color: tokens.text3,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        )
                      : const SizedBox(height: 30),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEntryConditionsSection(BuildContext context) {
    // The practical opposing-signal relation still drives the established
    // violet palette. Only the layout changed: this section now has its own tab.
    final hasPracticalReverseSignalLink = _hasPracticalNoEntryReason;
    final reverseSignalTone = hasPracticalReverseSignalLink
        ? _noEntryTone
        : _reverseSignalsTone;
    final sectionTone = hasPracticalReverseSignalLink
        ? _noEntryTone
        : _entryConditionsTone;
    final sectionGradient = hasPracticalReverseSignalLink
        ? const [
            Color(0xFF312A57),
            Color(0xFF2B2549),
            Color(0xFF241F3E),
            Color(0xFF1D1933),
          ]
        : const [
            Color(0xFF1B3948),
            Color(0xFF162F3D),
            Color(0xFF122936),
            Color(0xFF0E202B),
          ];

    return _sectionCard(
      context,
      key: const ValueKey('entry-conditions-section-card'),
      showHeader: false,
      bodyHorizontalPadding: 10,
      title: _copy('ظروف الدخول', 'Entry conditions'),
      icon: Icons.radar_rounded,
      tone: sectionTone,
      gradientColors: sectionGradient,
      borderTone: hasPracticalReverseSignalLink
          ? const Color(0xFF7863C4)
          : const Color(0xFF456F82),
      tint: hasPracticalReverseSignalLink ? .14 : .12,
      children: [
        KeyedSubtree(
          key: _reverseSignalSectionKey,
          child: _entryConditionField(
            key: const ValueKey('reverse-signal-category-trigger'),
            addKey: const ValueKey('add-reverse-signal-setup'),
            surfaceKey: const ValueKey('reverse-signal-category-surface'),
            wrapperKey: const ValueKey('reverse-signal-category-wrapper'),
            title: _copy('إشارات عكسية', 'Opposing signals'),
            fieldId: 'reverse-signals',
            collapsed: _collapsedSelectionFields.contains('reverse-signals'),
            onCollapsedChanged: (value) =>
                _setSelectionFieldCollapsed('reverse-signals', value),
            setups: _reverseSignalSetups,
            options: tradeReverseSignalOptions,
            tone: reverseSignalTone,
            enabled: _hasTradeDirection,
            onAdd: _addReverseSignalSetup,
            onRemove: _removeReverseSignalSetup,
            onEdit: _editReverseSignalSetup,
            practicalNoEntrySetups:
                _practicalNoEntryReverseSignalSetups.toSet(),
            onLongPressSetup: _togglePracticalNoEntryReverseSignal,
          ),
        ),
        const SizedBox(height: 9),
        KeyedSubtree(
          key: _bounceZoneSectionKey,
          child: _entryConditionField(
            key: const ValueKey('bounce-zone-category-trigger'),
            addKey: const ValueKey('add-bounce-zone-setup'),
            surfaceKey: const ValueKey('bounce-zone-category-surface'),
            wrapperKey: const ValueKey('bounce-zone-category-wrapper'),
            title: _copy('منطقة الارتداد', 'Bounce area'),
            fieldId: 'bounce-area',
            collapsed: _collapsedSelectionFields.contains('bounce-area'),
            onCollapsedChanged: (value) =>
                _setSelectionFieldCollapsed('bounce-area', value),
            setups: _bounceZoneSetups,
            options: tradeBounceZoneLabelOptions,
            // Bounce area keeps its original blue field palette even when the
            // opposing-signal field carries a practical link.
            tone: _entryConditionsTone,
            enabled: _hasTradeDirection,
            onAdd: _addBounceZoneSetup,
            onRemove: _removeBounceZoneSetup,
            onEdit: _editBounceZoneSetup,
          ),
        ),
      ],
    );
  }

  Widget _buildBehaviorCard(BuildContext context) {
    final decisionCount = tradeReviewGroups
        .expand((group) => group.options)
        .where((option) => _executionReviewKeys.contains(option.key))
        .length;
    final commitmentCount = tradeCommitmentOptions
        .where((item) => _executionReviewKeys.contains(item.key))
        .length;
    final noEntryCount = _noEntryReasons.length;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final behaviorSections = <({
      String key,
      String title,
      int count,
      Color tone,
      Color darkSurface,
      Color lightSurface,
    })>[
      (
        key: 'decisions',
        title: _copy('القرارات', 'Decisions'),
        count: decisionCount,
        tone: TradeDetailPalette.decisionTone,
        darkSurface: TradeDetailPalette.reviewDecisionDark,
        lightSurface: TradeDetailPalette.reviewDecisionLight,
      ),
      (
        key: 'commitment',
        title: _copy('الالتزام', 'Plan commitment'),
        count: commitmentCount,
        tone: TradeDetailPalette.commitmentTone,
        darkSurface: TradeDetailPalette.reviewCommitmentDark,
        lightSurface: TradeDetailPalette.reviewCommitmentLight,
      ),
      (
        key: 'no-entry',
        title: _copy('أسباب عدم الدخول', 'Reasons for not entering'),
        count: noEntryCount,
        tone: TradeDetailPalette.noEntryTone,
        darkSurface: TradeDetailPalette.reviewNoEntryDark,
        lightSurface: TradeDetailPalette.reviewNoEntryLight,
      ),
    ];

    return _sectionCard(
      context,
      showHeader: false,
      title: _copy('سلوك التداول', 'Trading behavior'),
      icon: Icons.fact_check_outlined,
      tone: _behaviorTone,
      gradientColors: const [Color(0xFF312A57), Color(0xFF2B2549), Color(0xFF241F3E), Color(0xFF1D1933)],
      borderTone: const Color(0xFF7863C4),
      tint: .14,
      bodyHorizontalPadding: 6,
      children: [
        Row(
          children: [
            for (var index = 0; index < behaviorSections.length; index++) ...[
              if (index > 0) const SizedBox(width: 6),
              Expanded(
                child: _buildBehaviorSectionTab(
                  index: index,
                  keyName: behaviorSections[index].key,
                  title: behaviorSections[index].title,
                  count: behaviorSections[index].count,
                  tone: behaviorSections[index].tone,
                  darkSurface: behaviorSections[index].darkSurface,
                  lightSurface: behaviorSections[index].lightSurface,
                  isDark: isDark,
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        for (var index = 0; index < behaviorSections.length; index++)
          Visibility(
            visible: _activeBehaviorSectionIndex == index,
            maintainState: true,
            maintainAnimation: true,
            child: _buildBehaviorSectionPanel(
              keyName: behaviorSections[index].key,
              tone: behaviorSections[index].tone,
              darkSurface: behaviorSections[index].darkSurface,
              lightSurface: behaviorSections[index].lightSurface,
              isDark: isDark,
              child: _buildBehaviorSectionContent(context, index),
            ),
          ),
      ],
    );
  }

  Widget _buildBehaviorSectionTab({
    required int index,
    required String keyName,
    required String title,
    required int count,
    required Color tone,
    required Color darkSurface,
    required Color lightSurface,
    required bool isDark,
  }) {
    final tokens = TdTokens.of(context);
    final selected = _activeBehaviorSectionIndex == index;
    final surface = isDark
        ? darkSurface
        : lightSurface;
    return AnimatedContainer(
      key: ValueKey('trade-behavior-section-tab-surface-$keyName'),
      duration: const Duration(milliseconds: 170),
      curve: Curves.easeOutCubic,
      height: 66,
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: tone.withValues(
            alpha: selected ? (isDark ? .22 : .18) : (isDark ? .14 : .12),
          ),
          width: .8,
        ),
      ),
      child: Semantics(
        button: true,
        selected: selected,
        label: title,
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            key: ValueKey('trade-behavior-section-tab-$keyName'),
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              if (!selected) {
                setState(() => _activeBehaviorSectionIndex = index);
              } else if (index == 1 && count > 0) {
                // The Commitment tab itself is the title of its single list;
                // tapping it again folds the options into the shared summary.
                setState(() => _commitmentCollapsed = !_commitmentCollapsed);
              }
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 6),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Center(
                      child: Text(
                        title,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: selected ? tone : tokens.text2,
                          fontSize: 11.5,
                          fontWeight:
                              selected ? FontWeight.w800 : FontWeight.w600,
                          height: 1.15,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    '$count',
                    style: TextStyle(
                      color: tone.withValues(alpha: selected ? .96 : .76),
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      height: 1.05,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBehaviorSectionPanel({
    required String keyName,
    required Color tone,
    required Color darkSurface,
    required Color lightSurface,
    required bool isDark,
    required Widget child,
  }) {
    return AnimatedContainer(
      key: ValueKey('trade-behavior-section-panel-$keyName'),
      duration: const Duration(milliseconds: 170),
      curve: Curves.easeOutCubic,
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(5, 7, 5, 9),
      decoration: BoxDecoration(
        color: isDark ? darkSurface : lightSurface,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: tone.withValues(alpha: isDark ? .16 : .12),
          width: .8,
        ),
      ),
      child: child,
    );
  }

  Widget _buildCommitmentSelectionZone() {
    final selectedOptions = tradeCommitmentOptions
        .where((option) => _executionReviewKeys.contains(option.key))
        .toList();
    final count = selectedOptions.length;
    final collapsed = _commitmentCollapsed && count > 0;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      layoutBuilder: (current, previous) => Stack(
        alignment: Alignment.topCenter,
        children: [
          for (final old in previous)
            Positioned(top: 0, left: 0, right: 0, child: old),
          if (current != null) current,
        ],
      ),
      transitionBuilder: (child, animation) =>
          FadeTransition(opacity: animation, child: child),
      child: collapsed
          ? DecisionSelectionSummary(
              key: const ValueKey('trade-commitment-selection-summary'),
              itemKeyPrefix: 'commitment',
              stacked: true,
              latinLabels: !_ar,
              labels: [
                for (final option in selectedOptions)
                  _ar ? option.ar : option.en,
              ],
              tone: _commitmentTone,
              onTap: () => setState(() => _commitmentCollapsed = false),
            )
          : Column(
              key: const ValueKey('trade-commitment-selection-list'),
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < tradeCommitmentOptions.length; i++) ...[
                  if (i > 0) const SizedBox(height: 6),
                  _selectionRow(
                    tradeCommitmentOptions[i],
                    _executionReviewKeys,
                    keyPrefix: 'review',
                    accent: _commitmentTone,
                    enabled: _hasTradeDirection &&
                        !_commitmentLocked(tradeCommitmentOptions[i].key),
                    showArtwork: false,
                  ),
                ],
              ],
            ),
    );
  }

  Widget _buildBehaviorSectionContent(BuildContext context, int index) {
    return switch (index) {
      0 => Padding(
          padding: const EdgeInsets.fromLTRB(2, 2, 2, 5),
          child: TradeDecisionZones(
            key: const ValueKey('trade-decision-zones'),
            groups: tradeReviewGroups,
            selected: _executionReviewKeys,
            enabled: _hasTradeDirection,
            arabic: _ar,
            tone: _decisionTone,
            initialZone: _decisionZoneIndex,
            initialAnalysisCollapsed: _decisionAnalysisCollapsed,
            initialCollapsed: _decisionCollapsedZones,
            onZoneChanged: (index) => setState(() => _decisionZoneIndex = index),
            onCollapsedChanged: (values) => setState(() {
              _decisionCollapsedZones = {...values};
              _decisionAnalysisCollapsed = values.contains('analysis');
            }),
            onToggle: (key) => _toggleSet(
              _executionReviewKeys,
              key,
              !_executionReviewKeys.contains(key),
            ),
            listRowBuilder: (option) => _selectionRow(
              option,
              _executionReviewKeys,
              keyPrefix: 'review',
              accent: _decisionTone,
              enabled: _hasTradeDirection,
            ),
          ),
        ),
      1 => Padding(
          padding: const EdgeInsets.fromLTRB(2, 2, 2, 5),
          child: _buildCommitmentSelectionZone(),
        ),
      _ => Padding(
          padding: const EdgeInsets.fromLTRB(2, 2, 2, 5),
          child: TradeNoEntryZones(
            key: const ValueKey('trade-no-entry-zones'),
            groups: tradeNoEntryGroups,
            selected: _noEntryReasons,
            enabled: _hasTradeDirection,
            arabic: _ar,
            tone: _noEntryTone,
            initialZone: _noEntryZoneIndex,
            initialCollapsed: _noEntryCollapsedZones,
            onZoneChanged: (index) => setState(() => _noEntryZoneIndex = index),
            onCollapsedChanged: (value) => setState(() => _noEntryCollapsedZones = value),
            onToggle: (key) => _toggleSet(
              _noEntryReasons,
              key,
              !_noEntryReasons.contains(key),
            ),
          ),
        ),
    };
  }

  /// One selectable row of the Decisions and Commitment sections. Uses the same
  /// tonal tile as «أسباب عدم الدخول» so the three behavior areas read alike:
  /// full width, one item per line, a tonal step (no border, glow or check
  /// mark) when selected. The commitment illustrations stay, as the leading
  /// element of their own tile.
  Widget _selectionRow(
    TradeEntryOption option,
    Set<String> selected, {
    required String keyPrefix,
    required Color accent,
    required bool enabled,
    bool showArtwork = true,
  }) {
    final isSelected = selected.contains(option.key);
    final hasReviewArtwork =
        showArtwork && tradeReviewOptionEmojiAssets.containsKey(option.key);
    return DecisionOptionTile(
      inkKey: ValueKey('$keyPrefix-${option.key}'),
      surfaceKey: ValueKey('trade-behavior-option-surface-${option.key}'),
      label: _ar ? option.ar : option.en,
      selected: isSelected,
      enabled: enabled,
      tone: accent,
      fontSize: _tradeDataItemFontSize,
      leading: hasReviewArtwork
          ? TradeReviewOptionEmoji(
              key: ValueKey('review-art-${option.key}'),
              optionKey: option.key,
              size: 28,
            )
          : null,
      onTap: () => _toggleSet(selected, option.key, !isSelected),
    );
  }
}

/// One resolved choice from the outcome menu.
class _OutcomeChoice {
  const _OutcomeChoice(
    this.classification, {
    this.breakEvenType,
    this.missedOutcome,
  });

  final TradeClassification classification;
  final BreakEvenType? breakEvenType;
  final MissedTradeOutcome? missedOutcome;
}
