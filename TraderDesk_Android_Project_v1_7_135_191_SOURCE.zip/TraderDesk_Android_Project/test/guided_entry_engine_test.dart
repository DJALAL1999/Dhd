// Run: dart run test/guided_entry_engine_test.dart
// (plain Dart, no packages: it exercises lib/domain/guided_entry_engine.dart,
// the same engine the trade form uses). Exits with code 1 on any failure.
import 'dart:io';
import 'dart:math';

import '../lib/domain/guided_entry_engine.dart';

typedef S = GuidedStep;

int _passed = 0;
final List<String> _failed = [];

void check(String name, bool ok, [String detail = '']) {
  if (ok) {
    _passed++;
    stdout.writeln('PASS: $name');
  } else {
    _failed.add(name);
    stdout.writeln('FAIL: $name $detail');
  }
}

/// A model of the form's data with the same rules as the screen's
/// `_guidedSnapshot()`, driven through the real controller exactly like the
/// form drives it. `observe()` stands for the build hook that runs after every
/// change.
class FormSim {
  final c = GuidedEntryController();
  bool active = true, noEntryLink = false, resultOk = true, win = true;
  bool expectedLossOk = true, side = true, symbol = true, mindset = true;
  bool exitApplicable = true;
  final entry = <String>{}, confirmation = <String>{}, exit = <String>{};
  final reverse = <String>{}, bounce = <String>{};
  final anchors = <String, List<String>>{}; // anchor -> timeframes
  final visited = <S>[];

  GuidedSnapshot snap() => GuidedSnapshot(
        active: active,
        noEntryLink: noEntryLink,
        resultValid: resultOk,
        needsExpectedLoss: win,
        expectedLossValid: expectedLossOk,
        hasSide: side,
        hasSymbol: symbol,
        hasMindset: mindset,
        exitApplicable: exitApplicable,
        filled: {
          if (entry.isNotEmpty) S.entryReason,
          if (anchors.isNotEmpty) S.anchors,
          if (confirmation.isNotEmpty) S.confirmation,
          if (exit.isNotEmpty) S.exitReason,
          if (reverse.isNotEmpty) S.reverseSignals,
          if (bounce.isNotEmpty) S.bounceZone,
        },
      );

  void observe() => c.observe(snap());

  // --- mutations (each one ends with the build hook) ---
  void addAnchor(String k, String tf) {
    (anchors[k] ??= []).add(tf);
    observe();
  }

  /// Mirrors _removeAnchor(frame): removing the last frame removes the anchor.
  void removeAnchorFrame(String k, String tf) {
    final frames = anchors[k]!..remove(tf);
    if (frames.isEmpty) anchors.remove(k);
    observe();
  }

  void clearAnchors() {
    anchors.clear();
    observe();
  }

  void mutate(Set<String> set, String item, {bool add = true}) {
    add ? set.add(item) : set.remove(item);
    observe();
  }

  /// What the trader fills when the guide opens each section.
  final fillOnVisit = <S, void Function()>{};

  /// Runs the guide until idle, like _advanceGuidedEntry + _runGuidedSection.
  void runGuide() {
    for (var i = 0; i < 40; i++) {
      final step = c.next(snap());
      if (step == S.idle) return;
      visited.add(step);
      if (GuidedEntryEngine.isSection(step)) {
        fillOnVisit[step]?.call();
        observe();
        c.continuePressed(snap(), step);
      } else {
        // basic fields: the trader completes them
        switch (step) {
          case S.result:
            resultOk = true;
          case S.expectedLoss:
            expectedLossOk = true;
          case S.direction:
            side = true;
          case S.market:
            symbol = true;
          case S.mindset:
            mindset = true;
          default:
        }
        observe();
      }
    }
    throw StateError('guide did not settle');
  }

  /// First entry: every section is filled and passed with Continue.
  void completeFirstChain() {
    c.progress.continued.clear();
    fillOnVisit[S.entryReason] = () => entry.add('trendline');
    fillOnVisit[S.anchors] = () => addAnchor('zoneSd', '15m');
    fillOnVisit[S.confirmation] = () => confirmation.add('displacement');
    fillOnVisit[S.exitReason] = () => exit.add('target');
    fillOnVisit[S.reverseSignals] = () => reverse.add('sweep');
    fillOnVisit[S.bounceZone] = () => bounce.add('srTouch');
    side = symbol = mindset = true;
    runGuide();
    fillOnVisit.clear();
    visited.clear();
  }
}

FormSim finished() => FormSim()..completeFirstChain();

void main() {
  try {
    _run();
  } catch (error, stack) {
    stdout.writeln('FAIL: test run crashed: $error\n$stack');
    exit(1);
  }
}

void _run() {
  // --- sanity: the first chain visits every section once, in order ---
  {
    final f = FormSim()
      ..fillOnVisit[S.entryReason] = (() {})
      ..completeFirstChain();
    check('first chain completes with all six sections passed',
        f.c.next(f.snap()) == S.idle &&
            f.c.progress.continued.length == 6,
        '${f.c.progress.continued}');
  }

  // 1. Mandatory example: delete all anchors, open Bounce, pick an item.
  {
    final f = finished();
    f.clearAnchors();
    check('1a. emptied anchors detected although Continue was pressed before',
        GuidedEntryEngine.missingFor(f.snap(), f.c.progress, S.bounceZone)
                .first ==
            S.anchors);
    final plan = f.c.planTap(f.snap(), S.bounceZone);
    check('1b. tap on Bounce => deferred plan (list opens with Continue)',
        plan.mode == GuidedTapMode.deferred && plan.first == S.anchors);
    // the trader picks a bounce item inside that list, then presses Continue
    f.mutate(f.bounce, 'liquiditySweep');
    final target = f.c.applyDeferredContinue(f.snap(), S.bounceZone);
    check('1c. Continue goes straight to the anchors list', target == S.anchors);
    check('1d. bounce picks survived the detour',
        f.bounce.containsAll({'srTouch', 'liquiditySweep'}));
    // anchors list opens (guided): trader picks an anchor + timeframe
    f.fillOnVisit[S.anchors] = () => f.addAnchor('engulfing', '1h');
    f.visited.clear();
    f.runGuide();
    check('1e. guide visited only the anchors section',
        f.visited.length == 1 && f.visited.first == S.anchors,
        '${f.visited}');
    check('1f. after fixing anchors the Bounce context is resumed',
        f.c.takeResume(f.snap()) == S.bounceZone);
    check('1g. resume token is consumed once', f.c.takeResume(f.snap()) == null);
    check('1h. everything re-evaluated: nothing else missing',
        f.c.planTap(f.snap(), S.bounceZone).mode == GuidedTapMode.none);
  }

  // 2. Entry confirmation emptied, then a later area is opened.
  {
    final f = finished();
    f.mutate(f.confirmation, 'displacement', add: false);
    final plan = f.c.planTap(f.snap(), S.bounceZone);
    check('2a. emptied confirmation detected from a later area (immediate)',
        plan.mode == GuidedTapMode.immediate && plan.first == S.confirmation);
    f.c.applyImmediate(f.snap(), S.bounceZone);
    check('2b. guide now routes to confirmation',
        f.c.next(f.snap()) == S.confirmation);
    f.fillOnVisit[S.confirmation] = () => f.confirmation.add('closeAboveLevel');
    f.runGuide();
    check('2c. requested Bounce is re-queued after the fix',
        f.visited.first == S.confirmation && f.visited.contains(S.bounceZone),
        '${f.visited}');
  }

  // 3. All entry reasons emptied after the chain.
  {
    final f = finished();
    f.mutate(f.entry, 'trendline', add: false);
    check('3a. entry reasons emptied => next step is entryReason even though '
        'Continue was pressed',
        f.c.next(f.snap()) == S.entryReason);
    check('3b. detected when the trader taps Anchors',
        f.c.planTap(f.snap(), S.anchors).first == S.entryReason &&
            f.c.planTap(f.snap(), S.anchors).mode == GuidedTapMode.immediate);
    check('3c. detected from outside the guided sections (Decisions etc.)',
        f.c.planTap(f.snap(), S.idle).first == S.entryReason);
  }

  // 4. Removing the last timeframe of an anchor empties the area.
  {
    final f = finished();
    f.addAnchor('zoneSd', '1h');
    check('4a. two timeframes on one anchor: area filled',
        f.snap().isFilled(S.anchors));
    f.removeAnchorFrame('zoneSd', '15m');
    check('4b. one valid link left => still complete',
        f.snap().isFilled(S.anchors) &&
            f.c.planTap(f.snap(), S.bounceZone).mode == GuidedTapMode.none);
    f.removeAnchorFrame('zoneSd', '1h');
    check('4c. last timeframe removed => area incomplete',
        !f.snap().isFilled(S.anchors) &&
            f.c.planTap(f.snap(), S.bounceZone).first == S.anchors);
  }

  // 5. Partial deletion: other valid selections remain.
  {
    final f = finished();
    f.mutate(f.entry, 'liquidity');
    f.mutate(f.entry, 'trendline', add: false);
    f.mutate(f.bounce, 'x');
    f.mutate(f.bounce, 'srTouch', add: false);
    check('5. partial deletions with valid items left never flag a gap',
        f.c.planTap(f.snap(), S.reverseSignals).mode == GuidedTapMode.none &&
            f.c.planTap(f.snap(), S.idle).mode == GuidedTapMode.none &&
            f.c.next(f.snap()) == S.idle);
  }

  // 6. Several areas incomplete: first in ENTRY order, then the next.
  {
    final f = finished();
    f.clearAnchors();
    f.mutate(f.confirmation, 'displacement', add: false);
    final missing =
        GuidedEntryEngine.missingFor(f.snap(), f.c.progress, S.bounceZone);
    check('6a. anchors (earlier) listed before confirmation',
        missing.length == 2 && missing[0] == S.anchors && missing[1] == S.confirmation,
        '$missing');
    // tapping something while anchors+confirmation are empty: first is anchors
    check('6b. the plan targets anchors first, not the last edited area',
        f.c.planTap(f.snap(), S.bounceZone).first == S.anchors);
    final target = f.c.applyDeferredContinue(f.snap(), S.bounceZone);
    check('6c. Continue goes to anchors', target == S.anchors);
    f.fillOnVisit[S.anchors] = () => f.addAnchor('zoneSd', '4h');
    f.fillOnVisit[S.confirmation] = () => f.confirmation.add('displacement');
    f.visited.clear();
    f.runGuide();
    check('6d. after anchors is fixed it re-evaluates and moves to '
        'confirmation',
        f.visited.length == 2 &&
            f.visited[0] == S.anchors &&
            f.visited[1] == S.confirmation,
        '${f.visited}');
    check('6e. Bounce context resumed after both fixes',
        f.c.takeResume(f.snap()) == S.bounceZone);
  }

  // 7. Result / direction / classification changes re-evaluate the fields.
  {
    final f = finished();
    f.win = false; // result changed to a loss: expected loss not required
    f.expectedLossOk = false;
    check('7a. loss result: missing expected loss is not an incomplete field',
        f.c.next(f.snap()) == S.idle);
    f.win = true; // back to a win: planned loss is required again
    check('7b. win result: expected loss required again',
        f.c.next(f.snap()) == S.expectedLoss);
    f.expectedLossOk = true;
    f.side = false; // direction cleared while anchors are also emptied
    f.clearAnchors();
    check('7c. basic field (direction) has priority over an emptied area',
        f.c.next(f.snap()) == S.direction &&
            f.c.planTap(f.snap(), S.bounceZone).first == S.direction &&
            f.c.planTap(f.snap(), S.bounceZone).mode == GuidedTapMode.immediate);
    f.side = true;
    check('7d. direction restored: emptied anchors is the next step',
        f.c.next(f.snap()) == S.anchors);
    f.resultOk = false;
    check('7e. invalid result comes before everything',
        f.c.next(f.snap()) == S.result);
    f.resultOk = true;
    f.mindset = false;
    check('7f. cleared mindset detected', f.c.next(f.snap()) == S.mindset);
  }

  // 8. Selections are never lost while a gap is handled.
  {
    final f = finished();
    f.clearAnchors();
    f.mutate(f.reverse, 'extra');
    f.mutate(f.bounce, 'extra2');
    final before = {...f.reverse, ...f.bounce, ...f.entry, ...f.confirmation};
    f.c.planTap(f.snap(), S.bounceZone);
    f.c.applyDeferredContinue(f.snap(), S.bounceZone);
    f.fillOnVisit[S.anchors] = () => f.addAnchor('zoneSd', '1h');
    f.runGuide();
    final after = {...f.reverse, ...f.bounce, ...f.entry, ...f.confirmation};
    check('8a. no selection lost during the detour', after.containsAll(before));
    check('8b. returns to the pending action',
        f.c.takeResume(f.snap()) == S.bounceZone);
    // immediate path keeps data as well
    final g = finished();
    g.mutate(g.entry, 'trendline', add: false);
    g.mutate(g.bounce, 'new');
    g.c.applyImmediate(g.snap(), S.bounceZone);
    check('8c. immediate redirect keeps the picks and re-queues the section',
        g.bounce.contains('new') &&
            !g.c.progress.continued.contains(S.bounceZone) &&
            g.c.next(g.snap()) == S.entryReason);
  }

  // 9. Optional / not-applicable areas never cause wrong routing.
  {
    final f = FormSim()
      ..fillOnVisit[S.entryReason] = (() {})
      ..completeFirstChain();
    final g = FormSim();
    g.fillOnVisit[S.entryReason] = () => g.entry.add('a');
    g.fillOnVisit[S.confirmation] = () => g.confirmation.add('b');
    g.runGuide(); // anchors / reverse / bounce / exit left empty on purpose
    check('9a. optional areas never filled are not incomplete',
        g.c.planTap(g.snap(), S.bounceZone).mode == GuidedTapMode.none &&
            g.c.next(g.snap()) == S.idle);
    final h = finished();
    h.exitApplicable = false;
    h.mutate(h.exit, 'target', add: false);
    check('9b. exit area that does not apply (no classification) is ignored',
        h.c.planTap(h.snap(), S.bounceZone).mode == GuidedTapMode.none &&
            h.c.next(h.snap()) == S.idle);
    h.exitApplicable = true;
    check('9c. the same area counts again once it applies',
        h.c.planTap(h.snap(), S.bounceZone).first == S.exitReason);
    final i = finished();
    i.clearAnchors();
    i.noEntryLink = true;
    check('9d. no-entry link: monitoring is off',
        i.c.planTap(i.snap(), S.bounceZone).mode == GuidedTapMode.none &&
            i.c.next(i.snap()) == S.idle);
    final j = finished();
    j.clearAnchors();
    j.active = false;
    check('9e. existing-trade edit (not active): no routing',
        j.c.planTap(j.snap(), S.bounceZone).mode == GuidedTapMode.none);
    final k = finished();
    k.clearAnchors();
    k.c.continuePressed(k.snap(), S.anchors); // trader leaves it empty on purpose
    check('9f. Continue on an empty optional area is a conscious choice',
        k.c.planTap(k.snap(), S.bounceZone).mode == GuidedTapMode.none);
    k.addAnchor('zoneSd', '1h');
    k.clearAnchors();
    check('9g. fill then empty again => flagged again',
        k.c.planTap(k.snap(), S.bounceZone).first == S.anchors);
    final m = finished();
    m.mutate(m.entry, 'trendline', add: false);
    m.c.continuePressed(m.snap(), S.entryReason);
    check('9h. Continue on an empty REQUIRED area is still flagged later',
        m.c.planTap(m.snap(), S.anchors).first == S.entryReason);
    final n = finished();
    n.clearAnchors();
    check('9i. tapping the emptied area itself is not redirected',
        n.c.planTap(n.snap(), S.anchors).mode == GuidedTapMode.none);
    f.c.progress.clear();
    check('9j. progress can be cleared', f.c.progress.everFilled.isEmpty);
  }

  // Fuzz: arbitrary add/remove/edit order and count; the engine must agree
  // with an independent oracle after every operation.
  {
    final rnd = Random(20261127);
    var ok = true;
    String detail = '';
    for (var round = 0; round < 300 && ok; round++) {
      final f = finished();
      final everFilled = {...GuidedEntryEngine.sections};
      for (var op = 0; op < 60 && ok; op++) {
        final sec = GuidedEntryEngine.sections[rnd.nextInt(6)];
        final addIt = rnd.nextBool();
        switch (sec) {
          case S.entryReason:
            f.mutate(f.entry, 'e${rnd.nextInt(3)}', add: addIt);
          case S.anchors:
            if (addIt) {
              f.addAnchor('a${rnd.nextInt(2)}', 't${rnd.nextInt(3)}');
            } else if (f.anchors.isNotEmpty) {
              final k = f.anchors.keys.elementAt(rnd.nextInt(f.anchors.length));
              f.removeAnchorFrame(k, f.anchors[k]!.first);
            }
          case S.confirmation:
            f.mutate(f.confirmation, 'c${rnd.nextInt(3)}', add: addIt);
          case S.exitReason:
            f.mutate(f.exit, 'x${rnd.nextInt(3)}', add: addIt);
          case S.reverseSignals:
            f.mutate(f.reverse, 'r${rnd.nextInt(3)}', add: addIt);
          default:
            f.mutate(f.bounce, 'b${rnd.nextInt(3)}', add: addIt);
        }
        if (rnd.nextInt(6) == 0) f.exitApplicable = rnd.nextBool();
        final intent = [...GuidedEntryEngine.sections, S.idle][rnd.nextInt(7)];
        // oracle: sections empty now, all filled earlier (everFilled starts
        // full because the first chain filled every section), ignoring the
        // tapped one and a non-applicable exit area; required-empty before
        // the intent also counts (here every section was filled once, so the
        // two rules coincide).
        final expected = [
          for (final s in GuidedEntryEngine.sections)
            if (s != intent &&
                (s != S.exitReason || f.exitApplicable) &&
                everFilled.contains(s) &&
                !f.snap().isFilled(s))
              s
        ];
        final got = GuidedEntryEngine.missingFor(f.snap(), f.c.progress, intent);
        if ('$expected' != '$got') {
          ok = false;
          detail = 'round $round op $op intent $intent expected $expected got $got';
        }
        final plan = f.c.planTap(f.snap(), intent);
        if (expected.isEmpty != (plan.mode == GuidedTapMode.none)) {
          ok = false;
          detail = 'plan mismatch $detail';
        }
      }
    }
    check('fuzz: 300 random sessions x 60 edits agree with the oracle', ok, detail);
  }

  stdout.writeln('\n$_passed passed, ${_failed.length} failed');
  if (_failed.isNotEmpty) {
    stdout.writeln('Failed: $_failed');
    exit(1);
  }
}
