#!/usr/bin/env python3
"""Static wiring checks: the trade form delegates guided-entry decisions to
lib/domain/guided_entry_engine.dart and every add/edit path is guarded.
The behaviour itself is tested by: dart run test/guided_entry_engine_test.dart"""
import re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
ENG = (ROOT / "lib/domain/guided_entry_engine.dart").read_text(encoding="utf-8")
PUB = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
checks = []
def check(n, c): checks.append((n, bool(c)))

check("version is 1.7.135+191", "version: 1.7.135+191" in PUB)
check("engine has no Flutter imports", "package:flutter" not in ENG and "dart:ui" not in ENG)
check("form imports the engine", "import '../domain/guided_entry_engine.dart';" in FORM)
check("private enum replaced by alias", "typedef _AutoEntryStep = GuidedStep;" in FORM and "enum _AutoEntryStep" not in FORM)
check("next step comes from the engine", "_guided.next(_guidedSnapshot())" in FORM)
check("missing items come from the engine", "GuidedEntryEngine.missingFor(_guidedSnapshot(), _guided.progress, intent)" in FORM)
check("_guidedSectionsContinued is no longer the only authority (snapshot built from live data)",
      "GuidedSnapshot _guidedSnapshot() =>" in FORM)
for name, expr in [("entryReason", "_entrySetups.isNotEmpty"), ("anchors", "_anchors.isNotEmpty"),
                   ("confirmation", "_confirmationSetups.isNotEmpty"), ("exitReason", "_exitReasonSetups.isNotEmpty"),
                   ("reverseSignals", "_reverseSignalSetups.isNotEmpty"), ("bounceZone", "_bounceZoneSetups.isNotEmpty")]:
    check(f"snapshot reads live data of {name}", f"if ({expr}) _AutoEntryStep.{name}" in FORM)
check("tracking runs at the start of build (after every change)",
      re.search(r"Widget build\(BuildContext context\) \{\s*_trackFilledGuidedSections\(\);", FORM))
for sec in ["entryReason", "confirmation", "reverseSignals", "bounceZone", "exitReason", "anchors"]:
    check(f"add handler {sec} guarded", f"if (await _guideThroughMissing(_AutoEntryStep.{sec})) return;" in FORM)
for fn, sec in [("_editEntrySetup", "entryReason"), ("_editConfirmationSetup", "confirmation"),
                ("_editReverseSignalSetup", "reverseSignals"), ("_editBounceZoneSetup", "bounceZone"),
                ("_editExitReasonSetup", "exitReason"), ("_editAnchorTimeframe", "anchors")]:
    m = re.search(r"Future<void> " + fn + r"\(.*?\n  \}\n", FORM, re.S)
    check(f"edit handler {fn} guarded", m and f"_redirectToMissingGuidedField(_AutoEntryStep.{sec})" in m.group(0))
check("_toggleSet (decisions/commitment/no-entry) guarded",
      "if (selected && _redirectToMissingGuidedFieldAnywhere()) return;" in FORM)
check("Continue goes through the engine", "_guided.continuePressed(_guidedSnapshot(), step);" in FORM)
check("deferred Continue + resume wired",
      "_guided.applyDeferredContinue(_guidedSnapshot(), intent)" in FORM and "_guided.takeResume(_guidedSnapshot())" in FORM)
check("single shared Continue button widget (no new design)",
      FORM.count("Widget _guidedContinueButton(") == 1)
check("reconcile after basic changes still wired",
      FORM.count("_reconcileGuidedEntryAfterChange(") >= 4)
check("engine test file exists", (ROOT / "test/guided_entry_engine_test.dart").exists())
t = re.sub(r"'(?:[^'\\\n]|\\.)*'|\"(?:[^\"\\\n]|\\.)*\"", "''", FORM)
t = re.sub(r"//[^\n]*", "", t)
check("form brackets balanced", all(t.count(a) == t.count(b) for a, b in ["()", "[]", "{}"]))
p = sum(1 for _, ok in checks if ok)
for n, ok in checks: print(f"{'PASS' if ok else 'FAIL'}: {n}")
print(f"\n{p}/{len(checks)} checks passed")
sys.exit(0 if p == len(checks) else 1)
