#!/usr/bin/env bash
# Install the pinned Android NDK before Gradle starts. A failed SDK Manager
# extraction can leave a corrupt download cache and a partial ndk/<revision>.
set -euo pipefail

NDK_VERSION="${NDK_VERSION:-28.2.13676358}"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"

if [[ -z "$SDK_ROOT" || ! -d "$SDK_ROOT" ]]; then
  echo "ERROR: Android SDK root was not found (ANDROID_SDK_ROOT/ANDROID_HOME)." >&2
  exit 1
fi

SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  SDKMANAGER="$(find -L "$SDK_ROOT/cmdline-tools" -type f -name sdkmanager -perm -u+x 2>/dev/null | sort -V | tail -n 1 || true)"
fi
if [[ -z "$SDKMANAGER" || ! -x "$SDKMANAGER" ]]; then
  echo "ERROR: sdkmanager was not found under $SDK_ROOT/cmdline-tools." >&2
  exit 1
fi

NDK_DIR="$SDK_ROOT/ndk/$NDK_VERSION"
REVISION_FILE="$NDK_DIR/source.properties"

is_valid_ndk() {
  [[ -f "$REVISION_FILE" ]] && grep -Eq "^Pkg\.Revision[[:space:]]*=[[:space:]]*$NDK_VERSION[[:space:]]*$" "$REVISION_FILE"
}

if is_valid_ndk; then
  echo "Android NDK $NDK_VERSION is already installed and verified."
  exit 0
fi

# Remove only the SDK Manager's temporary download cache and this incomplete
# NDK revision; do not clear other SDK packages or any Gradle/Pub caches.
rm -rf "$SDK_ROOT/.downloadIntermediates" "$NDK_DIR"

for attempt in 1 2 3; do
  echo "Installing Android NDK $NDK_VERSION (attempt $attempt/3)..."
  if "$SDKMANAGER" --sdk_root="$SDK_ROOT" --install "ndk;$NDK_VERSION"; then
    if is_valid_ndk; then
      echo "Android NDK $NDK_VERSION installed and verified."
      exit 0
    fi
    echo "WARNING: sdkmanager finished without a valid NDK revision file." >&2
  else
    echo "WARNING: sdkmanager failed while installing NDK $NDK_VERSION." >&2
  fi

  # Discard a possibly corrupt archive and half-extracted directory before retry.
  rm -rf "$SDK_ROOT/.downloadIntermediates" "$NDK_DIR"
  if [[ "$attempt" -lt 3 ]]; then
    sleep 3
  fi
done

echo "ERROR: Could not install a valid Android NDK $NDK_VERSION after 3 attempts." >&2
exit 1
