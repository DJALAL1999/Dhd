# تقرير تحديث TraderDesk — 1.7.142+198

- السابق: `1.7.141+197`. الجديد: `1.7.142+198`.

## إصلاح توقف بناء Android عند تثبيت NDK
- سبب الفشل الظاهر في سجل GitHub Actions: تعذّر قراءة محتوى أرشيف حزمة
  `NDK (Side by side) 28.2.13676358` أثناء فك الضغط (`Error reading Zip content
  from a SeekableByteChannel`). هذا فشل في تنزيل/فك حزمة SDK، وليس خطأ Dart أو
  Kotlin أو في السطر 19 من `android/build.gradle.kts`.
- أُضيف `scripts/prepare_android_ndk.sh` لتثبيت إصدار NDK نفسه قبل تشغيل Gradle.
  يتحقق السكربت من `source.properties`، ويمسح فقط ذاكرة تنزيل SDK المؤقتة ومجلد
  NDK الجزئي عند الفشل، ثم يعيد المحاولة حتى ثلاث مرات.
- أُضيفت خطوة تهيئة NDK إلى `.github/workflows/release-arm64.yml` بعد تجهيز Flutter
  وقبل سكربت البناء. بقي Flutter مثبتاً على `3.47.7`، وNDK على `28.2.13676358`.
- لم يتم تخفيض NDK، ولم تتغير ملفات التطبيق أو الأصول أو قواعد البيانات أو وظائفه.

## الإصدار
- `pubspec.yaml`: `1.7.142+198`.
- أسماء Artifacts: `traderdesk-1.7.142-build198-arm64-v8a-release` و
  `traderdesk-1.7.142-build198-arm64-dart-symbols`.

## التحقق وحدوده
- فُحصت سلامة ZIP المصدر قبل التعديل.
- أُجريت فحوص Bash وYAML واتساق أرقام الإصدار ومواضع خطوات Workflow بعد التعديل.
- لا تتوفر Flutter/Android SDK في بيئة التحرير، لذلك لم يُنفذ بناء APK محلياً،
  ولم يُشغّل GitHub Actions من هذه البيئة. يلزم تشغيل Workflow للتحقق النهائي من
  نجاح تنزيل NDK وبناء APK على runner الخاص بـ GitHub.
