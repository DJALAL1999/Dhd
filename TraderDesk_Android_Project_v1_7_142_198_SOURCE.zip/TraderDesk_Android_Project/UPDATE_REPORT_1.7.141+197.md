# تقرير تحديث TraderDesk — 1.7.141+197

- السابق: `1.7.140+196`. الجديد: `1.7.141+197`.

## 1) اختصار جمل «الالتزام» ونقلها إلى «إدارة المخاطرة»
- `breakevenStopToEntry`: «نقلت وقف الخسارة إلى نقطة الدخول وخرجت بتعادل»
- `manualExitNearTarget`: «خرجت عند اقتراب السعر من الهدف»
- `autoExitAtTarget`: «خرجت تلقائيًا عند بلوغ الهدف»
- انتقلت الجمل الثلاث إلى نهاية مجموعة `risk` في `tradeReviewGroups` (إدارة المخاطرة).
  مفاتيح التخزين لم تتغير، فالصفقات المحفوظة تقرأ النص الجديد وتظهر في «إدارة المخاطرة»
  (النموذج وتفاصيل الصفقة والعدّادات) تلقائيًا لأن كل شيء يُبنى من الكتالوج.
- بقي في «الالتزام» عنصران فقط: «التزمت بشروط الدخول رغم الخوف من الخسارة» و«التزمت بالخطة كاملة».
- حُذفت رسوماتها الثلاث (`assets/emojis/commitment/*.webp`) وأُزيلت من
  `decision_option_emoji.dart` لأن منطقة القرارات (ومنها المخاطرة) نصية بلا رسومات.
- نصوص `app_strings.dart` (العربية والإنجليزية) اختُصرت بالمعنى نفسه.

## 2) خيار X Setup في «سبب الدخول»
- مفتاح جديد `directionalXSetup` في نهاية `tradeEntryReasons`، يظهر في القائمة باسم `X Setup`.
- بعد الاختيار تظهر قائمة الفريمات، ويُعرض العنصر في قائمة الفريمات وفي منطقة العناصر المختارة:
  - BUY → `X SETUP Buy`
  - SELL → `X SETUP Sell`
  - بلا اتجاه → `X SETUP`
- الصيغة تُحسب من `formatTradeEntryReasonLabel` فتتغير مع تغيير الاتجاه كبقية العناصر
  الاتجاهية (SFR/RFS مثلًا)، بلا تغيير في بنية التخزين.

## الملفات
- معدّل: `lib/domain/trade_entry_catalog.dart`، `lib/l10n/app_strings.dart`،
  `lib/widgets/decision_option_emoji.dart`، `pubspec.yaml`، `.github/workflows/release-arm64.yml`
- اختبارات: `test/trade_entry_catalog_test.dart` (جديدان)، `test/trade_decision_emoji_test.dart`،
  `test/custom_confirmation_test.dart`
- ملاحظة: لم يتوفر Flutter في بيئة العمل فلم أشغّل `flutter test`/`flutter analyze`.
