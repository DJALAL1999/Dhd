/// Decision logic of the guided (auto-advance) trade entry.
///
/// This file is plain Dart (no Flutter imports) so the exact same code that
/// drives the trade form is exercised by `test/guided_entry_engine_test.dart`.
/// The form only builds a [GuidedSnapshot] from its live fields, asks the
/// [GuidedEntryController] what to do, and performs the UI work (opening a
/// list, switching tab, scrolling).
///
/// Core rule: whether an area is complete is decided from its CURRENT data,
/// never from the history of the trader pressing Continue. History is kept
/// only as progress information:
///  * `continued`  – sections the trader passed with Continue (first pass).
///  * `everFilled` – sections that held valid data at some point. A section
///    that is in this set and is empty now is an incomplete area.
library;

enum GuidedStep {
  idle,
  result,
  expectedLoss,
  direction,
  market,
  mindset,
  // After Mindset the guide walks the selection sections in the order they
  // appear on the form.
  entryReason,
  anchors,
  confirmation,
  exitReason,
  reverseSignals,
  bounceZone,
}

/// Plain-data view of the form at one instant.
class GuidedSnapshot {
  const GuidedSnapshot({
    required this.active,
    this.noEntryLink = false,
    this.resultValid = false,
    this.resultSkipped = false,
    this.needsExpectedLoss = false,
    this.expectedLossValid = false,
    this.hasSide = false,
    this.hasSymbol = false,
    this.hasMindset = false,
    this.exitApplicable = false,
    this.filled = const <GuidedStep>{},
  });

  /// Guided monitoring is on (new trade, not linked to a no-entry reason).
  final bool active;
  final bool noEntryLink;
  final bool resultValid;

  /// The trader pressed Skip on the numeric keypad: the amount field needs no
  /// number for this record (missed setup / break-even). It satisfies the
  /// result step without being a valid amount, and no planned loss is asked.
  final bool resultSkipped;
  final bool needsExpectedLoss;
  final bool expectedLossValid;
  final bool hasSide;
  final bool hasSymbol;
  final bool hasMindset;

  /// The exit-reason area is shown for the current classification.
  final bool exitApplicable;

  /// Sections that currently hold at least one valid item.
  final Set<GuidedStep> filled;

  bool get monitoring => active && !noEntryLink;
  bool isFilled(GuidedStep section) => filled.contains(section);
}

/// How a tap on an area must be handled.
enum GuidedTapMode {
  /// Nothing is missing: open the requested list normally.
  none,

  /// Tap outside the six list sections (inline chips): take the trader to the
  /// missing item right away.
  immediate,

  /// Something is missing: open the requested list with Continue; Continue
  /// leads to the first missing item.
  deferred,
}

class GuidedTapPlan {
  const GuidedTapPlan(this.mode, this.missing);
  final GuidedTapMode mode;

  /// All incomplete items in entry order (first one is handled first).
  final List<GuidedStep> missing;
  GuidedStep? get first => missing.isEmpty ? null : missing.first;
}

abstract final class GuidedEntryEngine {
  static const List<GuidedStep> sections = [
    GuidedStep.entryReason,
    GuidedStep.anchors,
    GuidedStep.confirmation,
    GuidedStep.exitReason,
    GuidedStep.reverseSignals,
    GuidedStep.bounceZone,
  ];

  /// Required by the save rules.
  static const Set<GuidedStep> requiredSections = {
    GuidedStep.entryReason,
    GuidedStep.confirmation,
  };

  /// Fields of the trade-data area completed by hand after a Skip.
  static const Set<GuidedStep> tradeDataFields = {
    GuidedStep.direction,
    GuidedStep.market,
    GuidedStep.mindset,
  };

  /// After Skip the guide must not open the trade-data fields by itself: the
  /// trader stays in the current area and completes them. Once they are all
  /// filled, [next] is a section (or idle) and the guide resumes as usual.
  static bool holdsForTradeData(GuidedSnapshot s, GuidedStep next) =>
      s.monitoring && s.resultSkipped && tradeDataFields.contains(next);

  static bool isSection(GuidedStep step) => sections.contains(step);
  static bool isRequired(GuidedStep step) => requiredSections.contains(step);

  /// A section that does not apply to the current trade (exit reason without a
  /// win/loss/break-even classification) never counts as incomplete.
  static bool applies(GuidedSnapshot s, GuidedStep section) =>
      section != GuidedStep.exitReason || s.exitApplicable;

  /// First incomplete basic field in entry order, or [GuidedStep.idle].
  static GuidedStep firstBasicIncomplete(GuidedSnapshot s) {
    if (!s.monitoring) return GuidedStep.idle;
    if (!s.resultValid && !s.resultSkipped) return GuidedStep.result;
    if (!s.resultSkipped && s.needsExpectedLoss && !s.expectedLossValid) {
      return GuidedStep.expectedLoss;
    }
    if (!s.hasSide) return GuidedStep.direction;
    if (!s.hasSymbol) return GuidedStep.market;
    if (!s.hasMindset) return GuidedStep.mindset;
    return GuidedStep.idle;
  }

  /// A section filled earlier and empty now.
  static bool isEmptied(
    GuidedSnapshot s,
    GuidedProgress p,
    GuidedStep section,
  ) =>
      applies(s, section) &&
      p.everFilled.contains(section) &&
      !s.isFilled(section);

  /// The step the guide must run now: first incomplete basic field, then the
  /// first section that was emptied or has not been passed yet.
  static GuidedStep nextStep(GuidedSnapshot s, GuidedProgress p) {
    final basic = firstBasicIncomplete(s);
    if (basic != GuidedStep.idle || !s.monitoring) return basic;
    for (final section in sections) {
      if (!applies(s, section)) continue;
      if (isEmptied(s, p, section)) return section;
      if (!p.continued.contains(section)) return section;
    }
    return GuidedStep.idle;
  }

  /// Everything incomplete, in entry order, from the point of view of a trader
  /// acting in [intent] (the section they tapped, or [GuidedStep.idle] for any
  /// area outside the six guided sections: decisions, commitment, ...).
  ///  * the basic field that is missing (at most one, always first);
  ///  * a required section that is empty and comes BEFORE [intent];
  ///  * any section filled earlier and emptied now (except [intent] itself).
  static List<GuidedStep> missingFor(
    GuidedSnapshot s,
    GuidedProgress p,
    GuidedStep intent,
  ) {
    if (!s.monitoring) return const [];
    final basic = firstBasicIncomplete(s);
    if (basic != GuidedStep.idle) return [basic];
    final intentIndex =
        isSection(intent) ? sections.indexOf(intent) : sections.length;
    return [
      for (final section in sections)
        if (section != intent && applies(s, section))
          if ((isRequired(section) &&
                  sections.indexOf(section) < intentIndex &&
                  !s.isFilled(section)) ||
              isEmptied(s, p, section))
            section,
    ];
  }
}

/// Progress of one guided entry session. The only mutable state of the engine.
class GuidedProgress {
  final Set<GuidedStep> continued = <GuidedStep>{};
  final Set<GuidedStep> everFilled = <GuidedStep>{};

  /// Section whose list the trader was working in when an emptied area sent
  /// them elsewhere; reopened after the missing areas are completed.
  GuidedStep? resume;

  void clear() {
    continued.clear();
    everFilled.clear();
    resume = null;
  }
}

/// Orchestrates [GuidedEntryEngine] and [GuidedProgress]. Each public method
/// is one event of the trader's flow; the form calls them in the same order.
class GuidedEntryController {
  final GuidedProgress progress = GuidedProgress();

  /// Records which sections currently hold data. Must run after EVERY change
  /// of the form (the form calls it from build), so a section is recorded as
  /// filled before any later edit can empty it.
  void observe(GuidedSnapshot s) {
    if (!s.active) return;
    for (final section in GuidedEntryEngine.sections) {
      if (s.isFilled(section)) progress.everFilled.add(section);
    }
  }

  GuidedStep next(GuidedSnapshot s) => GuidedEntryEngine.nextStep(s, progress);

  /// True when the step the guide would run now is a trade-data field and the
  /// trader skipped the numeric entry: the form must wait, not open it.
  bool holdsAfterSkip(GuidedSnapshot s) =>
      GuidedEntryEngine.holdsForTradeData(s, next(s));

  /// The trader tapped a list/selection of [intent].
  GuidedTapPlan planTap(GuidedSnapshot s, GuidedStep intent) {
    final missing = GuidedEntryEngine.missingFor(s, progress, intent);
    if (missing.isEmpty) return const GuidedTapPlan(GuidedTapMode.none, []);
    // A tap on one of the six list sections always opens that list first, with
    // the Continue button; Continue then leads to the first missing item,
    // whatever it is (a basic field such as Mindset, or another area). Only
    // inline areas without a list (Decisions, Commitment, ...) redirect at once.
    final deferred = GuidedEntryEngine.isSection(intent);
    return GuidedTapPlan(
      deferred ? GuidedTapMode.deferred : GuidedTapMode.immediate,
      missing,
    );
  }

  /// Immediate redirect: re-queue every incomplete item and [intent] so the
  /// requested section opens again right after the missing ones.
  void applyImmediate(GuidedSnapshot s, GuidedStep intent) {
    final missing = GuidedEntryEngine.missingFor(s, progress, intent);
    progress.continued
      ..remove(intent)
      ..removeAll(missing);
    progress.resume = null;
  }

  /// The trader pressed Continue in the list of [intent] that was opened while
  /// another area was incomplete. Returns the step to run (the first missing
  /// one) or [GuidedStep.idle] when nothing is missing any more. [intent] is
  /// remembered so its list is reopened afterwards ([takeResume]).
  GuidedStep applyDeferredContinue(GuidedSnapshot s, GuidedStep intent) {
    final missing = GuidedEntryEngine.missingFor(s, progress, intent);
    if (missing.isEmpty) return GuidedStep.idle;
    progress.continued
      ..add(intent)
      ..removeAll(missing);
    progress.resume = intent;
    return next(s);
  }

  /// The trader pressed Continue in the guided list of [step]. Continue on an
  /// empty optional area is a conscious decision to leave it empty.
  void continuePressed(GuidedSnapshot s, GuidedStep step) {
    progress.continued.add(step);
    if (!GuidedEntryEngine.isRequired(step) && !s.isFilled(step)) {
      progress.everFilled.remove(step);
    }
  }

  /// After the missing areas were completed: the section to reopen, or null.
  GuidedStep? takeResume(GuidedSnapshot s) {
    final target = progress.resume;
    if (target == null) return null;
    if (next(s) != GuidedStep.idle) return null;
    progress.resume = null;
    return target;
  }
}
