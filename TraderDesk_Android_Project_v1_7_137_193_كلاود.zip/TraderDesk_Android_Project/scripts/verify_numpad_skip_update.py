"""Static wiring checks for the keypad Skip (تجاوز) update (1.7.137+193).
Source-text checks only: Flutter/Dart are not available in every environment."""
import re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
FORM = (root / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
ENGINE = (root / 'lib/domain/guided_entry_engine.dart').read_text(encoding='utf-8')
failed = []
def check(name, ok):
    print(('PASS: ' if ok else 'FAIL: ') + name)
    if not ok: failed.append(name)
def body(src, start, end):
    a = src.index(start); return src[a:src.index(end, a)]
pad = body(FORM, 'Widget _buildNumericPad()', 'void _handleResultChanged(')
skip = body(FORM, 'void _handleNumericPadSkip()', 'void _restoreResultSignChoices()')
check('keypad no longer shows the «الربح / الخسارة» title', "'الربح / الخسارة'" not in pad)
check('keypad no longer has the «مسح» button or its icon', "'مسح'" not in pad and 'Icons.backspace_outlined' not in pad and 'trade-numpad-clear' not in FORM)
check('Skip button «تجاوز» exists next to Hide', "ValueKey('trade-numpad-skip')" in pad and "'تجاوز'" in pad and pad.index('trade-numpad-close') < pad.index('trade-numpad-skip'))
check('Hide button keeps _dismissNumericPad and is first in an RTL row (physical right)', 'onPressed: _dismissNumericPad' in pad and 'TextDirection.rtl' in pad)
check('first Profit/Loss choice is stored separately', 'int? _originalOutcomeSign;' in FORM and '_originalOutcomeSign = sign;' in FORM)
check('Skip never overwrites the original choice with a different value', '_originalOutcomeSign = sign;' in skip and '_originalOutcomeSign = -' not in skip and '_originalOutcomeSign = 1' not in skip)
check('no-entry reasons do not clear the original choice', '_originalOutcomeSign' not in body(FORM, 'void _enforceMissedOnlyOutcome()', 'void _selectResultSign') .replace('// _originalOutcomeSign is kept on purpose: it is the would-be result.', ''))
check('missed outcome is derived from the original choice', 'MissedTradeOutcome.win' in FORM and '_derivedMissedOutcome' in body(FORM, 'void _reconcileClassification()', '@override'))
check('saved trades restore the original choice (compat)', '_originalOutcomeSign = _resultSign ??' in FORM and 'trade?.missedOutcome' in FORM)
check('Win/Loss list is not shown when the choice is known', 'final derived = _derivedMissedOutcome;' in FORM and "keyName: 'missed'," in FORM)
check('fallback list is kept only when no first choice exists', "'missedWin'" in FORM and 'bool get _outcomeHasMenu' in FORM and '_derivedMissedOutcome == null' in body(FORM, 'bool get _outcomeHasMenu', 'void _applyOutcomeChoice'))
check('Skip does not call the guide to advance', '_advanceGuidedEntry' not in skip and '_reconcileGuidedEntryAfterChange' not in skip)
check('Skip leaves the guide idle instead of opening the next field', '_autoEntryStep = _AutoEntryStep.idle' in skip)
check('engine: Skip satisfies result without completing the area', 'resultSkipped' in ENGINE and 'holdsForTradeData' in ENGINE)
check('form passes resultSkipped to the engine', 'resultSkipped: _resultSkipped && _resultSign == null' in FORM)
check('reconcile holds after Skip and resumes by the normal rules', '_guided.holdsAfterSkip(_guidedSnapshot())' in FORM)
check('expected loss of a real win cannot be skipped', "tr(context, 'expectedLossNeeded')" in skip)
check('amount already entered is never deleted by Skip', 'hasAmount' in skip and '_result.clear();' in skip and skip.index('hasAmount ||') < skip.index('_result.clear();'))
check('storage format unchanged (Trade model untouched)', 'originalOutcome' not in (root / 'lib/models/trade.dart').read_text(encoding='utf-8'))
print(f"\n{len([1 for _ in failed])} failed")
sys.exit(1 if failed else 0)
