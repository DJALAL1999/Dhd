#!/usr/bin/env python3
"""Verify 1.7.134+190: any guided area that was filled and then emptied
(Anchors, Exit reason, Opposing signals, Bounce area, ...) is detected as
incomplete; the requested list opens with the Continue button and Continue
leads to the emptied area."""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
PUB = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
checks = []
def check(n, c): checks.append((n, bool(c)))

check("version is 1.7.134+190", "version: 1.7.134+190" in PUB)
check("ever-filled set declared", "_guidedSectionsEverFilled = <_AutoEntryStep>{}" in FORM)
check("ever-filled cleared with the no-entry reset",
      re.search(r"_guidedSectionsContinued\.clear\(\);\s*_guidedSectionsEverFilled\.clear\(\);", FORM))
for sec, expr in [("entryReason", "_entrySetups.isNotEmpty"), ("anchors", "_anchors.isNotEmpty"),
                  ("confirmation", "_confirmationSetups.isNotEmpty"),
                  ("exitReason", "_exitReasonSetups.isNotEmpty"),
                  ("reverseSignals", "_reverseSignalSetups.isNotEmpty"),
                  ("bounceZone", "_bounceZoneSetups.isNotEmpty")]:
    check(f"_isGuidedSectionFilled covers {sec}", f"_AutoEntryStep.{sec} => {expr}" in FORM)
check("tracking runs at the start of build",
      re.search(r"Widget build\(BuildContext context\) \{\s*_trackFilledGuidedSections\(\);", FORM))
check("_firstMissingGuidedField falls through to emptied sections",
      "final emptied = _emptiedGuidedSections(intent);" in FORM)
check("emptied detection skips the tapped section and a hidden exit section",
      "if (section != intent &&" in FORM and "_exitSectionTitle == null)" in FORM)
check("redirect re-queues every emptied section", "..removeAll(_emptiedGuidedSections(intent));" in FORM)
check("_guideThroughMissing exists and keeps required-field redirect immediate",
      "Future<bool> _guideThroughMissing(_AutoEntryStep intent) async {" in FORM
      and "_isRequiredGuidedSection(missing)" in FORM)
check("deferred flow opens the requested list in guided mode (Continue)",
      re.search(r"outcome = await _openGuidedSectionList\(intent\);", FORM))
check("Continue then advances to the emptied area",
      re.search(r"\.\.remove\(target\)\s*\n\s*\.\.removeAll\(_emptiedGuidedSections\(intent\)\);\s*\n\s*_guidedReconciliationRevision\+\+;\s*\n\s*await _advanceGuidedEntry\(\);", FORM))
check("Continue on an empty optional area stops counting it as emptied",
      "_guidedSectionsEverFilled.remove(step);" in FORM)
for sec in ["entryReason", "confirmation", "reverseSignals", "bounceZone", "exitReason", "anchors"]:
    check(f"add handler for {sec} uses _guideThroughMissing",
          f"if (await _guideThroughMissing(_AutoEntryStep.{sec})) return;" in FORM)
check("_toggleSet still routes through the anywhere-check",
      "if (selected && _redirectToMissingGuidedFieldAnywhere()) return;" in FORM)
t = re.sub(r"'(?:[^'\\\n]|\\.)*'|\"(?:[^\"\\\n]|\\.)*\"", "''", FORM)
t = re.sub(r"//[^\n]*", "", t)
check("brackets balanced", all(t.count(a) == t.count(b) for a, b in ["()", "[]", "{}"]))

p = sum(1 for _, ok in checks if ok)
for n, ok in checks: print(f"{'PASS' if ok else 'FAIL'}: {n}")
print(f"\n{p}/{len(checks)} checks passed")
sys.exit(0 if p == len(checks) else 1)
