import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_outcome_palette.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';
import 'package:trader_desk/widgets/decision_section_logo.dart';
import 'package:trader_desk/widgets/trade_save_bar.dart';

Future<void> _selectTradeFormTab(
  WidgetTester tester,
  String section,
) async {
  final tab = find.byKey(ValueKey('trade-form-section-tab-$section'));
  await tester.ensureVisible(tab);
  await tester.tap(tab);
  await tester.pumpAndSettle();
}

Future<void> _selectBehaviorSection(
  WidgetTester tester,
  String section,
) async {
  final tab = find.byKey(ValueKey('trade-behavior-section-tab-$section'));
  await tester.ensureVisible(tab);
  await tester.tap(tab);
  await tester.pumpAndSettle();
}

Future<void> _enterSignedResult(
  WidgetTester tester,
  String amount, {
  required bool negative,
}) async {
  final input = find.byKey(const ValueKey('trade-result-input'));
  final signOption = find.byKey(ValueKey(
    negative ? 'trade-result-sign-negative' : 'trade-result-sign-positive',
  ));
  if (signOption.evaluate().isEmpty) {
    final resultField = tester.widget<TextFormField>(input);
    final existingText = resultField.controller?.text ?? '';
    final wasSigned = RegExp(r'^[+\-−]').hasMatch(existingText);
    if (wasSigned && !resultField.readOnly) {
      // Removing the leading symbol is the supported way to reopen sign choice.
      await tester.enterText(input, existingText.replaceFirst(RegExp(r'^[+\-−]'), ''));
    } else {
      await tester.tap(input);
    }
    await tester.pumpAndSettle();
  }
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsOneWidget,
      reason: 'the editable amount exposes + and − choices whenever its sign is absent');
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsOneWidget);
  await tester.tap(signOption);
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);
  await tester.enterText(input, '${negative ? '−' : '+'}$amount');
  await tester.pumpAndSettle();
  expect(
    tester.widget<TextFormField>(input).controller!.text,
    '${negative ? '−' : '+'}$amount',
    reason: 'the selected sign is stored as an editable leading character in the amount',
  );
}

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_entry_v151_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'entry-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'entry-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('adds Windows entry reason, custom confirmation and review selections', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketSelector = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await tester.tap(marketSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-market-option-NQ')));
    await tester.pumpAndSettle();
    await _enterSignedResult(tester, '42.5', negative: false);
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-risk-input'))).controller!.text, '1.00');
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-reward-risk-input'))).controller!.text, '0.43');

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Zone S/D'), findsOneWidget);
    expect(find.text('SFR / RFS'), findsOneWidget);
    expect(find.text('Trendline Touch 3'), findsOneWidget);
    expect(find.text('Trend Line Touch 3 Breakout'), findsOneWidget);
    expect(find.text('Trendline Sell 3 Touch'), findsNothing);
    expect(find.text('Trendline Buy 3 Touch'), findsNothing);
    expect(find.text('Trend Line Touch 3 Sell Breakout'), findsNothing);
    expect(find.text('Trend Line Touch 3 Buy Breakout'), findsNothing);
    expect(find.text('Supply Zone'), findsNothing,
        reason: 'Supply Zone is no longer a direct Entry Reason choice');
    await tester.tap(find.text('Zone S/D').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Demand Zone for BUY');

    // The same saved semantic Zone S/D key follows direction changes.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Supply Zone for SELL');
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);

    // A single BREAKOUT choice resolves to the correct scenario from direction.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    expect(find.text('SBR'), findsNothing);
    expect(find.text('RBS'), findsNothing);
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    final breakoutTouchDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(breakoutTouchDialog, findsOneWidget,
        reason: 'BREAKOUT opens the same centered optional Touch 2 chooser');
    expect(find.text('RBS Touch — اختياري'), findsOneWidget,
        reason: 'BUY-side BREAKOUT detail identifies the resulting RBS scenario');
    expect(find.text('Touch 2'), findsOneWidget);
    expect(find.text('متابعة'), findsOneWidget);
    expect(tester.widget<ListTile>(find.byKey(
      const ValueKey('touch2-choice-directionalBreakout'),
    )).selected, isFalse);
    expect(tester.widget<ListTile>(find.byKey(
      const ValueKey('skip-touch2-directionalBreakout'),
    )).selected, isFalse,
        reason: 'Continue is not preselected when no Touch 2 qualifier exists');
    expect(tester.getRect(breakoutTouchDialog).width, lessThan(340));
    await tester.tap(find.text('Touch 2').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('سبب الدخول · RBS Touch 2'), findsOneWidget,
        reason: 'BUY resolves BREAKOUT Touch 2 to RBS');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS Touch 2 15MIN'), findsOneWidget);

    // The same semantic Breakout resolves to SBR after changing to SELL.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SBR Touch 2 15MIN'), findsOneWidget);
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · SBR'), findsOneWidget);
    expect(find.text('SBR Touch — اختياري'), findsOneWidget,
        reason: 'SELL-side BREAKOUT detail identifies the resulting SBR scenario');
    await tester.tap(find.text('متابعة').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('SBR 30MIN'), findsOneWidget);

    // Return to BUY for the remaining reason, confirmation and review checks.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    // SFR / RFS share one row. BUY displays RFS; SELL displays SFR.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('SFR / RFS'), findsOneWidget);
    await tester.tap(find.text('SFR / RFS').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · RFS'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 5MIN'), findsOneWidget);

    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SFR 5MIN'), findsOneWidget,
        reason: 'the unified SFR/RFS setup follows the selected SELL direction');

    // Trendline Touch 3 is one generic row and resolves to the chosen side.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3'), findsOneWidget);
    await tester.tap(find.text('Trendline Touch 3').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · Trendline Touch 3 Sell'), findsOneWidget);
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3 Sell 30MIN'), findsOneWidget);

    // Changing back to BUY updates the concrete Trendline label.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3 Buy 30MIN'), findsOneWidget);

    // The new Trendline breakout row uses the inverse side in its final label.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Breakout'), findsOneWidget);
    await tester.tap(find.text('Trend Line Touch 3 Breakout').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · Trend Line Touch 3 Sell Breakout'), findsOneWidget);
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Sell Breakout 4H'), findsOneWidget);

    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Buy Breakout 4H'), findsOneWidget,
        reason: 'BUY maps to Sell Breakout and SELL maps to Buy Breakout');

    // Return to BUY before continuing with the existing Breakout edit assertion.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    // Editing the semantic Breakout choice keeps BREAKOUT selected in its picker.
    final savedBreakout = find.text('RBS 15MIN');
    await tester.ensureVisible(savedBreakout);
    await tester.tap(savedBreakout);
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    final breakoutOption = find.text('BREAKOUT').last;
    await tester.tap(breakoutOption);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · RBS'), findsOneWidget);
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS 2MIN'), findsOneWidget);

    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    await tester.ensureVisible(addConfirmation);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Reject ᴷᵉʸ ᴸᵉᵛᵉˡ'), findsOneWidget);
    await tester.tap(find.text('مخصص').last);
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField).last, 'ارتداد من مستوى يومي');
    await tester.tap(find.text('تأكيد').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مستوى يومي 2MIN'), findsOneWidget);

    await _selectTradeFormTab(tester, 'behavior');
    await _selectBehaviorSection(tester, 'decisions');
    final decisionOption = find.byKey(const ValueKey('review-enteredEarly'));
    final decisionOptionText = find.descendant(
      of: decisionOption,
      matching: find.byType(Text),
    );
    expect(
      tester.widget<Text>(decisionOptionText).style?.fontSize,
      14.5,
      reason: 'trading behavior option text should be comfortably readable',
    );
    expect(
      find.byType(DecisionSectionLogo),
      findsNothing,
      reason: 'the decisions mark is reserved for the saved trade details',
    );
    await tester.tap(find.byKey(const ValueKey('review-enteredEarly')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-enteredEarly')), findsNothing,
        reason: 'the Decisions area carries no emoji artwork');
    final selectedDecisionSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-enteredEarly')),
    );
    final restingDecisionSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-lateEntry')),
    );
    expect(
      (selectedDecisionSurface.decoration as BoxDecoration).color,
      isNot((restingDecisionSurface.decoration as BoxDecoration).color),
      reason: 'a selected decision sits one tonal step above the others, like the no-entry tiles, without a checkbox square',
    );
    expect(
      (restingDecisionSurface.decoration as BoxDecoration).color,
      isNot(Colors.transparent),
      reason: 'every decision item is a filled tile, not a bare row',
    );
    expect(
      find.descendant(of: decisionOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(
      find.descendant(of: decisionOption, matching: find.byIcon(Icons.check)),
      findsNothing,
    );

    await _selectBehaviorSection(tester, 'commitment');
    final commitmentOption = find.byKey(
      const ValueKey('review-fullPlanCompliance'),
    );
    // A violation is selected, so the two "followed the plan / entry
    // conditions" commitments are locked; the other commitments stay usable.
    expect(tester.widget<InkWell>(commitmentOption).onTap, isNull,
        reason: 'full plan compliance contradicts a chosen violation');
    expect(
      tester.widget<InkWell>(
        find.byKey(const ValueKey('review-enteredDespiteFear')),
      ).onTap,
      isNull,
      reason: 'following the entry conditions contradicts a chosen violation',
    );
    expect(
      tester.widget<InkWell>(
        find.byKey(const ValueKey('review-autoExitAtTarget')),
      ).onTap,
      isNotNull,
    );
    // Clearing the violation unlocks them again.
    await _selectBehaviorSection(tester, 'decisions');
    final retainedDecisionSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-enteredEarly')),
    );
    expect(
      (retainedDecisionSurface.decoration as BoxDecoration).color,
      (selectedDecisionSurface.decoration as BoxDecoration).color,
      reason: 'the selected decision remains selected while its panel is hidden',
    );
    await tester.ensureVisible(decisionOption);
    await tester.tap(decisionOption);
    await tester.pumpAndSettle();
    await _selectBehaviorSection(tester, 'commitment');
    expect(tester.widget<InkWell>(commitmentOption).onTap, isNotNull);
    await tester.ensureVisible(commitmentOption);
    expect(
      tester.widget<Text>(find.descendant(
        of: commitmentOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(commitmentOption);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-fullPlanCompliance')), findsNothing,
        reason: 'commitment tiles carry no emoji artwork');
    final selectedCommitmentSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fullPlanCompliance')),
    );
    final restingCommitmentSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-autoExitAtTarget')),
    );
    expect(
      (selectedCommitmentSurface.decoration as BoxDecoration).color,
      isNot((restingCommitmentSurface.decoration as BoxDecoration).color),
      reason: 'commitment selections use the same tonal tile step as the no-entry reasons, without checkbox squares',
    );
    expect(
      find.descendant(of: commitmentOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(find.byType(TradeReviewOptionEmoji), findsNothing);

    // The active Commitment tab is also the title of its single list.
    await tester.tap(find.byKey(
      const ValueKey('trade-behavior-section-tab-commitment'),
    ));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-commitment-selection-list')),
      findsNothing,
    );
    expect(
      find.byKey(const ValueKey('trade-commitment-selection-summary')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('decision-selection-item-commitment-0')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-commitment-selection-summary')),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-commitment-selection-list')),
      findsOneWidget,
    );

    // Choosing a violation afterwards releases the contradicting commitment.
    await _selectBehaviorSection(tester, 'decisions');
    await tester.ensureVisible(decisionOption);
    await tester.tap(decisionOption);
    await tester.pumpAndSettle();
    await _selectBehaviorSection(tester, 'commitment');
    await tester.ensureVisible(commitmentOption);
    expect(tester.widget<InkWell>(commitmentOption).onTap, isNull);
    final releasedCommitmentSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fullPlanCompliance')),
    );
    final lockedRestingSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-enteredDespiteFear')),
    );
    expect(
      (releasedCommitmentSurface.decoration as BoxDecoration).color,
      (lockedRestingSurface.decoration as BoxDecoration).color,
      reason: 'the full-plan commitment was cleared when a violation was chosen',
    );

    await _selectBehaviorSection(tester, 'no-entry');
    final noEntryOption = find.byKey(
      const ValueKey('no-entry-fearRepeatLossAfterLoss'),
    );
    expect(
      tester.widget<Text>(find.descendant(
        of: noEntryOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(noEntryOption);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('review-art-fearRepeatLossAfterLoss')),
      findsNothing,
      reason: 'the no-entry tiles are plain tonal rectangles without artwork',
    );
    final selectedNoEntrySurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fearRepeatLossAfterLoss')),
    );
    final selectedFill = (selectedNoEntrySurface.decoration as BoxDecoration).color;
    final restingSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fearGivingBackProfit')),
    );
    expect(
      selectedFill,
      isNot((restingSurface.decoration as BoxDecoration).color),
      reason: 'a selected no-entry reason sits one tonal step above the others, without a checkbox square',
    );
    expect(find.byType(Checkbox), findsNothing);
    expect(
      find.descendant(of: noEntryOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(
      find.descendant(of: noEntryOption, matching: find.byIcon(Icons.check)),
      findsNothing,
    );
    expect(find.byType(TradeReviewOptionEmoji), findsNothing,
        reason: 'neither the commitment tiles nor the no-entry tiles carry artwork');
    expect(tester.widget<TextFormField>(find.byKey(
      const ValueKey('trade-result-input'),
    )).controller!.text, isEmpty,
        reason: 'a no-entry reason clears the realized P/L and changes the record to a missed setup');
    expect(find.byKey(const ValueKey('trade-result-sign-indicator')), findsNothing,
        reason: 'no-entry evidence removes the previously selected positive sign');
    expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
    expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);

    // A no-entry reason makes the trade a missed setup automatically: the
    // merged save bar is already in the missed style, asking only for the
    // would-be result.
    final pill = find.byKey(const ValueKey('trade-outcome-pill'));
    final pillTitle = find.byKey(const ValueKey('trade-outcome-pill-title'));
    final pillSubtitle = find.byKey(const ValueKey('trade-outcome-pill-subtitle'));
    await tester.ensureVisible(pill);
    expect(find.byKey(const ValueKey('choose-trade-classification-button')), findsNothing);
    expect(tester.widget<Text>(pillTitle).data, 'ضائعة');
    expect(tester.widget<Text>(pillSubtitle).data, 'حدد النتيجة');
    final brightness = Theme.of(tester.element(pill)).brightness;
    expect(
      tester.widget<Text>(pillTitle).style!.color,
      TradeOutcomePalette.missed(brightness),
      reason: 'missed uses its own neutral-grey outcome colour',
    );
    expect(
      TradeOutcomePalette.missed(brightness),
      isNot(TradeOutcomePalette.breakEven(brightness)),
      reason: 'missed and break-even must be visually distinguishable',
    );

    // A missed opportunity must be explicitly labelled as a hypothetical win
    // or loss. Pressing save without it opens the menu instead of saving.
    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();
    expect(savedTrade, isNull,
        reason: 'a missed opportunity without a win/loss choice must not be saved');
    expect(find.byKey(const ValueKey('trade-outcome-menu')), findsOneWidget,
        reason: 'save asks for the missing choice right in place');
    expect(find.byKey(const ValueKey('trade-outcome-option-missedWin')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-outcome-option-missedLoss')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-outcome-option-balanced')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('trade-outcome-option-missedWin')));
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(pillSubtitle).data, 'كانت رابحة');

    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.missed);
    expect(savedTrade!.effectiveClassification, TradeClassification.missed);
    expect(savedTrade!.missedOutcome, MissedTradeOutcome.win,
        reason: 'the missed setup hypothetical outcome survives save independently of result=0');
    expect(savedTrade!.market, 'NQ');
    expect(savedTrade!.entrySetups, const [
      TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalBreakout Touch 2', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '2MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '30MIN'),
      TradeEntrySetup(reason: 'directionalSfrRfs', timeframe: '5MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3', timeframe: '30MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3Breakout', timeframe: '4H'),
    ]);
    expect(savedTrade!.confirmationSetups, const [TradeConfirmationSetup(type: 'ارتداد من مستوى يومي', timeframe: '2MIN')]);
    expect(savedTrade!.executionReviewKeys, contains('enteredEarly'));
    expect(savedTrade!.executionReviewKeys, isNot(contains('fullPlanCompliance')),
        reason: 'a violation and full plan compliance never coexist');
    expect(savedTrade!.noEntryReasons, ['fearRepeatLossAfterLoss']);
    expect(savedTrade!.expectedLoss, 100);
    expect(savedTrade!.riskPercent, 1);
    expect(savedTrade!.result, 0,
        reason: 'a record containing a no-entry reason must save with zero realized P/L');
  });

  Future<void> _pumpEmptyTradeForm(WidgetTester tester) async {
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
  }

  testWidgets('without a result sign the save bar offers break-even and missed in one menu', (tester) async {
    await _pumpEmptyTradeForm(tester);
    final pill = find.byKey(const ValueKey('trade-outcome-pill'));
    final title = find.byKey(const ValueKey('trade-outcome-pill-title'));
    await tester.ensureVisible(pill);
    expect(find.byKey(const ValueKey('choose-trade-classification-button')), findsNothing,
        reason: 'the separate classification button is replaced by the merged bar');
    expect(find.byKey(const ValueKey('save-trade-button')), findsOneWidget);
    expect(tester.widget<Text>(title).data, 'اختر التصنيف');

    await tester.tap(pill);
    await tester.pumpAndSettle();
    for (final key in const ['balanced', 'atEntry', 'missedWin', 'missedLoss']) {
      expect(find.byKey(ValueKey('trade-outcome-option-$key')), findsOneWidget,
          reason: 'the menu lists $key');
    }
    await tester.tap(find.byKey(const ValueKey('trade-outcome-option-atEntry')));
    await tester.pumpAndSettle();

    final brightness = Theme.of(tester.element(pill)).brightness;
    expect(tester.widget<Text>(title).data, 'تعادل');
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-subtitle'))).data,
      'عند منطقة الدخول',
    );
    expect(tester.widget<Text>(title).style!.color,
        TradeOutcomePalette.breakEven(brightness));

    await tester.tap(pill);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-outcome-option-missedLoss')));
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(title).data, 'ضائعة');
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-subtitle'))).data,
      'كانت خاسرة',
    );
    expect(tester.widget<Text>(title).style!.color,
        TradeOutcomePalette.missed(brightness));
    expect(tester.takeException(), isNull);
  });

  testWidgets('save bar is slightly smaller with muted win/loss tones and a quiet outline', (tester) async {
    tester.view.setLogicalSize(const Size(420, 120));
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    for (final classification in [
      TradeClassification.win,
      TradeClassification.loss,
    ]) {
      await tester.pumpWidget(
        MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 380,
                child: TradeSaveBar(
                  classification: classification,
                  title: classification == TradeClassification.win
                      ? 'رابحة'
                      : 'خاسرة',
                  subtitle: 'USD 100+',
                  subtitleLtr: true,
                  saveLabel: 'حفظ',
                  ready: true,
                  busy: false,
                  hasMenu: false,
                  onSave: () {},
                  onOpenMenu: null,
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      final tokens = TdTokens.of(tester.element(
        find.byKey(const ValueKey('trade-save-bar')),
      ));
      final baseAccent = classification == TradeClassification.win
          ? tokens.profit
          : tokens.loss;
      final softenedAccent = Color.alphaBlend(
        baseAccent.withValues(alpha: .84),
        tokens.surface2,
      );
      final bar = tester.widget<AnimatedContainer>(
        find.byKey(const ValueKey('trade-save-bar')),
      );
      expect(bar.height, TradeSaveBar.height);
      expect(TradeSaveBar.height, 64);
      final barDecoration = bar.decoration! as BoxDecoration;
      final border = barDecoration.border! as Border;
      expect(border.top.width, .8);
      expect(border.top.color, softenedAccent.withValues(alpha: .22));

      final saveSurface = tester.widget<AnimatedContainer>(
        find.byKey(const ValueKey('trade-save-button-surface')),
      );
      expect(
        (saveSurface.decoration! as BoxDecoration).color,
        softenedAccent,
      );
      expect(
        tester.widget<Text>(
          find.byKey(const ValueKey('trade-outcome-pill-title')),
        ).style!.color,
        softenedAccent,
      );
    }
    expect(tester.takeException(), isNull);
  });

  testWidgets('save opens the outcome menu in place when a choice is missing', (tester) async {
    await _pumpEmptyTradeForm(tester);
    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    final popup = find.byKey(const ValueKey('trade-outcome-menu'));
    expect(popup, findsOneWidget);
    final balanced = find.byKey(const ValueKey('trade-outcome-option-balanced'));
    final atEntry = find.byKey(const ValueKey('trade-outcome-option-atEntry'));
    expect(balanced, findsOneWidget);
    expect(atEntry, findsOneWidget);
    const viewport = Rect.fromLTWH(0, 0, 420, 900);
    final popupRect = tester.getRect(popup);
    expect(viewport.contains(popupRect.topLeft), isTrue);
    expect(viewport.contains(popupRect.bottomRight), isTrue);
    for (final option in [balanced, atEntry]) {
      final rect = tester.getRect(option);
      expect(rect.height, greaterThanOrEqualTo(48),
          reason: 'each option is a full-size, finger-friendly target');
      expect(popupRect.contains(rect.topLeft), isTrue);
      expect(popupRect.contains(rect.bottomRight), isTrue);
    }

    // The popup grows from the bottom edge of the save slot.
    final slotRect = tester.getRect(find.byWidgetPredicate(
      (widget) => widget is SizedBox && widget.key is GlobalKey &&
          (widget.key as GlobalKey).toString().contains('trade-save-slot'),
    ));
    expect((popupRect.bottom - slotRect.bottom).abs(), lessThan(14),
        reason: 'the popup is anchored over the save bar position');

    // Dismissing without a choice leaves the bar in place, still unresolved.
    await tester.tapAt(const Offset(10, 10));
    await tester.pumpAndSettle();
    expect(popup, findsNothing);
    expect(find.byKey(const ValueKey('trade-save-bar')), findsOneWidget);
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-title'))).data,
      'اختر التصنيف',
    );

    // One tap selects and closes the popup, and the choice shows in the pill.
    await tester.tap(find.byKey(const ValueKey('trade-outcome-pill')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-outcome-option-balanced')));
    await tester.pumpAndSettle();
    expect(popup, findsNothing);
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-subtitle'))).data,
      'متساوي',
    );
    expect(find.byKey(const ValueKey('save-trade-button')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('editing a legacy RBS Touch 2 setup restores the shared BREAKOUT detail dialog', (tester) async {
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    final legacyTrade = Trade(
      id: 'legacy-rbs-touch2-edit',
      accountId: 'entry-account',
      market: 'NQ',
      reason: 'RBS Touch 2',
      result: 0,
      riskPercent: 1,
      side: TradeSide.buy,
      confirmation: '',
      sequence: '',
      mood: 'moodCalm',
      tradedAt: DateTime(2026, 1, 1),
      entrySetups: const [
        TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '15MIN'),
      ],
    );

    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: TradeFormScreen(trade: legacyTrade),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final legacyChip = find.text('RBS Touch 2 15MIN');
    expect(legacyChip, findsOneWidget);
    await tester.ensureVisible(legacyChip);
    await tester.tap(find.byKey(const ValueKey('trade-setup-edit-entry-reason-0')));
    await tester.pumpAndSettle();

    expect(find.text('BREAKOUT'), findsOneWidget);
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();

    final touchDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(touchDialog, findsOneWidget);
    expect(find.text('RBS Touch — اختياري'), findsOneWidget);
    expect(find.text('Touch 2'), findsOneWidget);
    expect(find.text('متابعة'), findsOneWidget);
    final selectedContinue = find.byKey(
      const ValueKey('skip-touch2-directionalBreakout'),
    );
    expect(tester.widget<ListTile>(selectedContinue).selected, isFalse);
    final selectedTouch2 = find.byKey(
      const ValueKey('touch2-choice-directionalBreakout'),
    );
    expect(selectedTouch2, findsOneWidget);
    expect(tester.widget<ListTile>(selectedTouch2).selected, isTrue,
        reason: 'the legacy Touch 2 choice must be restored when editing');

    await tester.tap(find.text('Touch 2').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('15MIN'), findsOneWidget);
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS Touch 2 15MIN'), findsOneWidget);

    final directionSelector = find.byKey(
      const ValueKey('trade-direction-selector'),
    );
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SBR Touch 2 15MIN'), findsOneWidget,
        reason: 'the semantic Touch 2 breakout follows direction after editing');
  });

}
