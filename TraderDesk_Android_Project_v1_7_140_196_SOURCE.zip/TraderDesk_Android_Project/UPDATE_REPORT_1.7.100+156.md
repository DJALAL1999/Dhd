# تقرير تحديث TraderDesk 1.7.100+156

## المشروع المرجعي

`TraderDesk_Android_Project_v1.7.99+155_GPT_SOURCE.zip`

## التغييرات المنفذة

1. أضيف `BreakEvenType` بقيمتي `balanced` و`atEntry` إلى نموذج الصفقة.
2. عند اختيار «تعادل» في نموذج الإضافة، يظهر الخياران «متساوي» و«عند منطقة الدخول» تلقائيًا، بتصميم هادئ متوافق مع عناصر النموذج الحالية.
3. يبقى زر «حفظ الصفقة» مخفيًا حتى يختار المستخدم أحد الخيارين، مع تحقق إضافي داخل دالة الحفظ لمنع تجاوز الشرط.
4. يُحفظ النوع الفرعي في JSON، ويُستعاد عند فتح الصفقة، ويُحافظ عليه عند نسخ الصفقة عبر `withStrategyAdherence` وعند النسخ الاحتياطي/الاستعادة.
5. أضيف زر فرعي بجوار «تعادل» في قائمة تصنيف الصفقات، بنفس نمط زر القائمة الفرعية الموجود أمام «ضائعة». الخيارات هي «الكل» و«متساوي» و«عند منطقة الدخول».
6. التصفية تقارن النوع الفرعي المخزن فعليًا. السجلات القديمة التي لا تحتوي على نوع فرعي لا تُسند تخمينًا إلى أحد النوعين، لكنها تبقى ظاهرة ضمن «الكل».
7. أضيفت تسميات عربية وإنجليزية، واختبارات نموذج وواجهة للتخزين والتصفية.

## الملفات المعدلة

- `lib/models/trade.dart`
- `lib/screens/trade_form_screen.dart`
- `lib/screens/trades_screen.dart`
- `lib/data/local_store.dart`
- `lib/l10n/app_strings.dart`
- `test/trade_classification_test.dart`
- `test/trades_screen_filter_test.dart`
- `scripts/verify_break_even_subtypes.py`
- `pubspec.yaml` و`.github/workflows/android-build.yml` وملفات التوثيق والإصدار

## نتائج التحقق

- فحص التحقق الساكن الخاص بهذا التحديث: **16/16** نجاحًا.
- مجموعة التحقق الساكن الكاملة: **22 سكربتًا، 508/508** تأكيدات ناجحة.
- `python3 -m py_compile scripts/*.py`: ناجح.
- تحليل YAML لملفي `pubspec.yaml` و`.github/workflows/android-build.yml`: ناجح.
- `python3 -m py_compile scripts/*.py`: ناجح.
- لم تتوفر أوامر `flutter` و`dart` في بيئة التنفيذ؛ لذلك لم يتم تشغيل `flutter analyze` أو `flutter test` أو بناء APK.
- يجب تشغيل اختبارات Flutter والبناء على بيئة تحتوي على Flutter SDK قبل نشر APK.
