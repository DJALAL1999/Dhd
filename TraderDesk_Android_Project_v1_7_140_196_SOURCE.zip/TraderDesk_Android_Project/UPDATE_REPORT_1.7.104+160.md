# تقرير تحديث TraderDesk 1.7.104+160

## المشروع المرجعي

`TraderDesk_Android_Project_v1.7.103+159_GPT_SOURCE.zip`

## المطلوب

إعادة تنظيم قائمة «منطقة الارتداد» في نموذج الصفقة:

1. دمج «سحب سيولة داخلي» و«سحب السيولة خارجي» في صف واحد «سحب سيولة» يفتح نافذة منبثقة فيها «سيولة داخلية» و«سيولة خارجية»، ثم قائمة الفريمات.
2. تحويل «ارتداد من ترند لاين» إلى «إرتداد من Trendline» ويفتح نافذة فيها `Trendline Touch 3-4` و`Trend Line Touch 3-4 Breakout`.
3. تحويل «ارتداد من ترند لاين و Supply Zone» إلى «ارتداد من Zone S/D»: ينتقل مباشرة إلى قائمة الفريمات بنفس أسلوب «أسباب الدخول»، ويُظهر تلقائيًا Supply Zone عند BUY وDemand Zone عند SELL مع الفريم المختار.

## ما نُفّذ (بالدليل من الملفات)

- `lib/domain/trade_entry_catalog.dart`
  - `tradeBounceZoneOptions` صارت أربعة صفوف بالترتيب: S/R، سحب سيولة، إرتداد من Trendline، ارتداد من Zone S/D.
  - `tradeLiquiditySweepOptions` (سيولة داخلية / سيولة خارجية) و`tradeTrendlineBounceOptions` (Trendline Touch 3-4 / Trend Line Touch 3-4 Breakout) كقائمتين منبثقتين.
  - `tradeBounceZoneLabelOptions`: كل مفاتيح الحفظ الجديدة والقديمة مع تسمياتها للشارات والتفاصيل المحفوظة.
  - `tradeBounceZoneSubOptions` و`tradeBounceZoneMenuKey` (تمييز الصف المجمَّع عند تعديل اختيار محفوظ).
  - `formatTradeEntryConditionSetupLabel`: فرع جديد لـ `bounceFromZoneSd` (BUY ← Supply Zone، SELL ← Demand Zone، ثم الفريم)، وبقي فرع السجلات القديمة (ترند لاين + Supply) كما هو.
- `lib/screens/trade_form_screen.dart`: `_showEntryConditionSetup` صار: قائمة الاختيار ← (نافذة فرعية للصفوف المجمَّعة / Touch 2 لـ S/R فقط) ← الفريم. حُذف مسار الفريمين القديم. أُضيف `subtitle` اختياري لنافذة الاختيار المركزية، فالنافذة الفرعية تعرض «ظروف الدخول · منطقة الارتداد» بنفس اتساق قوائم الفريمات. النوافذ نفسها (الألوان والحواف والارتفاع والصفوف) هي نوافذ التطبيق الحالية دون أي تصميم جديد.
- `lib/screens/trades_screen.dart`: تفاصيل الصفقة المحفوظة تقرأ التسميات من القائمة الكاملة.
- `lib/l10n/app_strings.dart`: مفاتيح النصوص مطابقة للتسميات الجديدة.

## ما لم يتغير

مفاتيح الحفظ القديمة (`internalLiquiditySweep`, `majorStructureLiquiditySweep`, `bounceFromTrendline`, `bounceFromTrendlineAndSupplyZone`) ما زالت تُقرأ، فالصفقات والنسخ الاحتياطية المحفوظة سابقًا لا تتغير بياناتها. السجل القديم «ترند لاين + Supply» يُعرض بصيغته القديمة بفريميه. S/R وTouch 2 والإشارات العكسية وكل بقية الشاشات دون تغيير.

## التحقق الفعلي

- نُفّذت **25** سكربتًا ثابتًا في `scripts/` (24 قائمة + `verify_bounce_area_menu_update.py` الجديد بـ 50 فحصًا) وكلها نجحت. سكربتات قديمة حُدّثت لأنها كانت تثبّت النصوص والمسار المستبدَل: `verify_text_cleanup.py`، `verify_sr_bounce_liquidity_label_update.py`، `verify_timeframe_header_update.py`، `verify_precision_update.py`، مع رفع رقم الإصدار في الجميع.
- فحص توازن الأقواس لملفات Dart المعدَّلة نجح.
- حُدّثت اختبارات Flutter وأُضيفت اختبارات جديدة (`test/entry_conditions_test.dart`، `test/trade_entry_catalog_test.dart`): ترتيب الخيارات والتسميات، نافذتا السيولة وTrendline، ارتباط Zone S/D بالاتجاه (BUY/SELL) وتبدّله فورًا عند تغيير الاتجاه، حفظ JSON، وقراءة السجلات القديمة.

## ما لم يُنفَّذ

- Flutter SDK وDart غير متوفرين في بيئة التنفيذ ولا يوجد اتصال بالإنترنت: **لم يُشغَّل** `flutter analyze` ولا `flutter test` ولم يُبنَ APK ولم تجرَ معاينة على جهاز. اختبارات Dart المحدَّثة والجديدة كُتبت وراجعتها يدويًا لكنها **لم تُنفَّذ**.
- **يجب** تشغيل `flutter analyze` و`flutter test` ومعاينة النوافذ الثلاث على جهاز قبل نشر APK.

## قرارات تحتاج تأكيدك

1. **ربط الاتجاه بالمنطقة:** نُفّذ كما كتبته: BUY ← Supply Zone وSELL ← Demand Zone. هذا عكس مفتاح «الارتكاز» (Zone S/D هناك: BUY ← Demand) ويطابق منطق «الإشارات العكسية». إن كان المقصود غير ذلك فهو تعديل سطرين في `formatTradeEntryConditionSetupLabel`.
2. **صياغة الشارة:** كتبتَ لـ BUY «Supply Zone» فقط ولـ SELL «ارتد من Demand Zone 15MIN». وحّدت الاثنين على «ارتداد من Supply Zone 15MIN» / «ارتداد من Demand Zone 15MIN» (مع الفريم) كما في شارة S/R.
3. **Trendline:** بعد النافذة الفرعية تُفتح قائمة الفريمات، وتظهر الشارة «إرتداد من Trendline Touch 3-4 1H» (أو Breakout).
4. **تسمية السيولة المحفوظة:** صارت «سحب سيولة داخلية / خارجية» (تصحيح التأنيث)، فتظهر بها حتى الصفقات القديمة المحفوظة، والبيانات المخزَّنة نفسها لم تتغير.
