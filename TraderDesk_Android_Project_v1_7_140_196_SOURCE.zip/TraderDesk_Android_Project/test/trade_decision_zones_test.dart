import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/trade_decision_zones.dart';

const _tone = Color(0xFFC6A071);

Future<Set<String>> _pump(
  WidgetTester tester, {
  bool enabled = true,
  Set<String>? initial,
  bool arabic = true,
}) async {
  final selected = <String>{...?initial};
  await tester.pumpWidget(
    MaterialApp(
      theme: buildAppTheme(Brightness.dark),
      locale: Locale(arabic ? 'ar' : 'en'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: Scaffold(
        body: StatefulBuilder(
          builder: (context, setState) => SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            child: TradeDecisionZones(
              groups: tradeReviewGroups,
              selected: selected,
              enabled: enabled,
              arabic: arabic,
              tone: _tone,
              onToggle: (key) => setState(() {
                if (!selected.remove(key)) selected.add(key);
              }),
              listRowBuilder: (option) => InkWell(
                key: ValueKey('review-${option.key}'),
                onTap: enabled
                    ? () => setState(() {
                          if (!selected.remove(option.key)) {
                            selected.add(option.key);
                          }
                        })
                    : null,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(arabic ? option.ar : option.en),
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
  await tester.pumpAndSettle();
  return selected;
}

Future<void> _openAnalysis(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
  await tester.pumpAndSettle();
}

Color _surface(WidgetTester tester, String key) {
  final box = tester.widget<AnimatedContainer>(
    find.byKey(ValueKey('decision-analysis-surface-$key')),
  );
  return (box.decoration as BoxDecoration).color!;
}

void main() {
  testWidgets('three zones sit side by side and open on violations', (tester) async {
    await _pump(tester);

    final tabs = [
      for (final id in ['violations', 'analysis', 'risk'])
        find.byKey(ValueKey('decision-zone-tab-$id')),
    ];
    for (final tab in tabs) {
      expect(tab, findsOneWidget);
    }
    expect(find.text('مخالفات التنفيذ'), findsOneWidget);
    expect(find.text('جودة تحليل'), findsOneWidget);
    expect(find.text('إدارة المخاطرة'), findsOneWidget);

    final rects = tabs.map(tester.getRect).toList();
    expect(rects[0].top, closeTo(rects[1].top, .5));
    expect(rects[1].top, closeTo(rects[2].top, .5));
    expect(rects[0].width, closeTo(rects[1].width, .5));
    expect(rects[1].width, closeTo(rects[2].width, .5));
    // Arabic reads right-to-left: violations is the right-most rectangle.
    expect(rects[0].left, greaterThan(rects[1].left));
    expect(rects[1].left, greaterThan(rects[2].left));

    for (final key in [
      'enteredEarly',
      'lateEntry',
      'hesitationPartialSize',
      'stopLossReducedWithoutReason',
      'stopLossIncreasedWithoutReason',
      'exitedEarlyBecauseFearOfLosingProfit',
    ]) {
      expect(find.byKey(ValueKey('review-$key')), findsOneWidget, reason: key);
    }
    expect(find.text('دخول مبكر'), findsOneWidget);
    expect(find.text('دخول متأخر'), findsOneWidget);
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsNothing);
  });

  testWidgets('switching zones slides content in place without a dialog', (tester) async {
    await _pump(tester);

    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pump(const Duration(milliseconds: 90));
    expect(
      find.byKey(const ValueKey('decision-zone-panel-violations')),
      findsOneWidget,
      reason: 'the leaving zone is still sliding out mid-transition',
    );
    expect(
      find.byKey(const ValueKey('decision-zone-panel-analysis')),
      findsOneWidget,
    );
    expect(find.byType(Dialog), findsNothing);
    expect(find.byType(BottomSheet), findsNothing);

    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('decision-zone-panel-violations')),
      findsNothing,
    );
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-risk')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('review-stopLossIncreasedForLiquiditySafety')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('review-stopLossReducedForNegativeClose')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('review-partialSizeAwaitingDeepCorrection')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('review-partialExitNegativeCloseAgainstDirection')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('review-highMomentumReducedSizeForRiskManagement')),
      findsOneWidget,
    );
    expect(
      find.text('إبعاد وقف الخسارة إلى منطقة أمان أبعد قليلًا — زخم عالٍ'),
      findsOneWidget,
    );
    expect(
      find.text('تقريب وقف الخسارة إلى أقرب منطقة أمان — إغلاق سلبي لا يدعم اتجاه الصفقة'),
      findsOneWidget,
    );
    expect(
      find.text('إغلاق جزء من الصفقة بسبب إغلاق سلبي لا يدعم الاتجاه'),
      findsOneWidget,
    );
    expect(
      find.text('زخم عالٍ — لم أفتح الحجم الكامل ليتوافق وقف الخسارة مع إدارة رأس المال'),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsNothing);
  });

  testWidgets('violations and risk items stack one per line with an even gap', (tester) async {
    await _pump(tester);
    for (final zone in ['violations', 'risk']) {
      await tester.tap(find.byKey(ValueKey('decision-zone-tab-$zone')));
      await tester.pumpAndSettle();
      final keys = tradeReviewGroups
          .singleWhere((group) => group.id == zone)
          .options
          .map((option) => option.key)
          .toList();
      Rect rect(String key) =>
          tester.getRect(find.byKey(ValueKey('review-$key')));
      for (var i = 1; i < keys.length; i++) {
        final previous = rect(keys[i - 1]);
        final current = rect(keys[i]);
        expect(current.top, greaterThan(previous.bottom - .5),
            reason: '$zone items sit under each other');
        expect(current.top - previous.bottom, closeTo(6, .6),
            reason: '$zone items use the same gap as the no-entry tiles');
        expect(current.width, closeTo(previous.width, .5),
            reason: '$zone items share one width');
      }
    }
  });

  testWidgets('analysis tiles follow the requested arrangement exactly', (tester) async {
    await _pump(tester);
    await _openAnalysis(tester);

    Offset at(String key) => tester.getTopLeft(find.byKey(ValueKey('review-$key')));

    final analysisKeys = tradeReviewGroups
        .singleWhere((group) => group.id == 'analysis')
        .options
        .map((option) => option.key)
        .toList();
    expect(analysisKeys, hasLength(12));

    // Row 1: RBS · RBS Touch 2 · RFS
    expect(at('missedRbs').dy, closeTo(at('missedRbsTouch2').dy, .5));
    expect(at('missedRbs').dy, closeTo(at('missedRfs').dy, .5));
    // Row 2: SBR · SBR Touch 2 · SFR, below row 1
    expect(at('missedSbr').dy, closeTo(at('missedSfr').dy, .5));
    expect(at('missedSbr').dy, greaterThan(at('missedRbs').dy));
    // Row 3: Zone Supply · Zone Demand
    expect(at('missedZoneSupply').dy, closeTo(at('missedZoneDemand').dy, .5));
    expect(at('missedZoneSupply').dy, greaterThan(at('missedSbr').dy));
    // Rows 4-7: one full-width tile each, in the requested order.
    final single = [
      'missedTrendlineTouch3Sell',
      'missedTrendlineTouch3Buy',
      'missedTrendlineTouch3SellBreakout',
      'missedTrendlineTouch3BuyBreakout',
    ];
    for (var i = 0; i < single.length; i++) {
      if (i > 0) {
        expect(at(single[i]).dy, greaterThan(at(single[i - 1]).dy));
      }
      expect(
        tester.getSize(find.byKey(ValueKey('review-${single[i]}'))).width,
        greaterThan(tester.getSize(find.byKey(const ValueKey('review-missedRbs'))).width * 2.5),
      );
    }
    expect(find.text('Trendline Touch 3 Sell'), findsOneWidget);
    expect(find.text('Trend Line Touch 3 Buy Breakout'), findsOneWidget);
  });

  testWidgets('selecting a tile only shifts its tone: no border, no glow', (tester) async {
    final selected = await _pump(tester);
    await _openAnalysis(tester);

    final before = _surface(tester, 'missedRbs');
    await tester.tap(find.byKey(const ValueKey('review-missedRbs')));
    await tester.pumpAndSettle();
    final after = _surface(tester, 'missedRbs');

    expect(selected, {'missedRbs'});
    expect(after, isNot(before));
    expect(after.a, greaterThanOrEqualTo(0.99), reason: 'opaque tonal fill');
    final decoration = tester
        .widget<AnimatedContainer>(
          find.byKey(const ValueKey('decision-analysis-surface-missedRbs')),
        )
        .decoration as BoxDecoration;
    expect(decoration.border, isNull);
    expect(decoration.boxShadow, isNull);
    expect(_surface(tester, 'missedSbr'), before,
        reason: 'unselected tiles keep the resting tone');
    expect(find.byType(Checkbox), findsNothing);
    expect(find.byIcon(Icons.check), findsNothing);

    await tester.tap(find.byKey(const ValueKey('review-missedRbs')));
    await tester.pumpAndSettle();
    expect(selected, isEmpty);
    expect(_surface(tester, 'missedRbs'), before);
  });

  testWidgets('tapping the analysis name folds the list into a summary', (tester) async {
    final selected = await _pump(tester);
    await _openAnalysis(tester);

    // Nothing chosen yet: tapping the name does not fold anything.
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsOneWidget);
    expect(find.byKey(const ValueKey('decision-analysis-summary')), findsNothing);

    // One item → «لم أنتبه لوجود» followed by that item.
    await tester.tap(find.byKey(const ValueKey('review-missedSfr')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsNothing);
    expect(find.byKey(const ValueKey('decision-analysis-summary')), findsOneWidget);
    expect(find.text('لم أنتبه لوجود'), findsOneWidget);
    expect(find.text('لم أنتبه لوجود سيناريو'), findsNothing);
    expect(find.text('SFR'), findsOneWidget);
    expect(find.text('RBS'), findsNothing, reason: 'unselected items are hidden');

    // Unfold again by tapping the summary, add a second item, fold again.
    await tester.tap(find.byKey(const ValueKey('decision-analysis-summary')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('review-missedZoneDemand')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();

    // Several items → «لم أنتبه لوجود سيناريو» followed by the items.
    expect(find.text('لم أنتبه لوجود سيناريو'), findsOneWidget);
    expect(find.text('لم أنتبه لوجود'), findsNothing);
    expect(find.text('SFR'), findsOneWidget);
    expect(find.text('Zone Demand'), findsOneWidget);
    expect(selected, {'missedSfr', 'missedZoneDemand'});

    // Folding never discards the selection.
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-analysis-grid')), findsOneWidget);
    expect(selected, {'missedSfr', 'missedZoneDemand'});
  });

  testWidgets('violations and risk lists also fold into the shared selected summary', (tester) async {
    final selected = await _pump(tester, initial: {'enteredEarly'});

    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-violations')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-zone-list-violations')), findsNothing);
    expect(find.byKey(const ValueKey('decision-zone-summary-violations')), findsOneWidget);
    expect(find.text('دخول مبكر'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('decision-selection-item-decision-violations-0')),
      findsOneWidget,
    );
    final selectedDecisionCard = tester.widget<Container>(
      find.byKey(const ValueKey('decision-selection-item-decision-violations-0')),
    ).decoration as BoxDecoration;
    expect(selectedDecisionCard.border, isNull);
    expect(selectedDecisionCard.boxShadow, isNull);

    await tester.tap(find.byKey(const ValueKey('decision-zone-summary-violations')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-zone-list-violations')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-risk')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('review-stopLossReducedForNegativeClose')));
    await tester.pumpAndSettle();
    selected.add('stopLossReducedForNegativeClose');
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-risk')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-zone-list-risk')), findsNothing);
    expect(find.byKey(const ValueKey('decision-zone-summary-risk')), findsOneWidget);
    expect(
      find.text('تقريب وقف الخسارة إلى أقرب منطقة أمان — إغلاق سلبي لا يدعم اتجاه الصفقة'),
      findsOneWidget,
    );

    // The new risk-management options are selectable and survive folding.
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-risk')));
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(const ValueKey('review-partialExitNegativeCloseAgainstDirection')),
    );
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(const ValueKey('review-highMomentumReducedSizeForRiskManagement')),
    );
    await tester.pumpAndSettle();
    selected.addAll({
      'partialExitNegativeCloseAgainstDirection',
      'highMomentumReducedSizeForRiskManagement',
    });
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-risk')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('decision-zone-list-risk')), findsNothing);
    expect(
      find.text('إغلاق جزء من الصفقة بسبب إغلاق سلبي لا يدعم الاتجاه'),
      findsOneWidget,
    );
    expect(
      find.text('زخم عالٍ — لم أفتح الحجم الكامل ليتوافق وقف الخسارة مع إدارة رأس المال'),
      findsOneWidget,
    );
    expect(
      selected,
      containsAll({
        'stopLossReducedForNegativeClose',
        'partialExitNegativeCloseAgainstDirection',
        'highMomentumReducedSizeForRiskManagement',
      }),
    );
  });

  testWidgets('the folded summary puts the sentence first and the items below it as plain text', (tester) async {
    await _pump(tester, initial: {'missedRbsTouch2', 'missedTrendlineTouch3SellBreakout'});
    await _openAnalysis(tester);
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();

    final sentence = tester.getRect(
      find.byKey(const ValueKey('decision-analysis-summary-sentence')),
    );
    final first = tester.getRect(find.text('RBS Touch 2'));
    final second = tester.getRect(find.text('Trend Line Touch 3 Sell Breakout'));
    expect(find.text('لم أنتبه لوجود سيناريو'), findsOneWidget);
    expect(first.top, greaterThanOrEqualTo(sentence.bottom),
        reason: 'items sit below the sentence, not beside it');
    expect(first.center.dy, closeTo(second.center.dy, 1),
        reason: 'both items share one line');
    // Gap between the two items is a clear space, not a box edge.
    final gap = first.center.dx < second.center.dx
        ? second.left - first.right
        : first.left - second.right;
    expect(gap, greaterThanOrEqualTo(12));
    // Plain text: the items are not wrapped in their own decorated boxes.
    for (final label in ['RBS Touch 2', 'Trend Line Touch 3 Sell Breakout']) {
      expect(
        find.ancestor(
          of: find.text(label),
          matching: find.byWidgetPredicate(
            (w) =>
                w is Container &&
                w.decoration is BoxDecoration &&
                (w.decoration as BoxDecoration).borderRadius ==
                    BorderRadius.circular(9),
          ),
        ),
        findsNothing,
        reason: label,
      );
    }
  });

  testWidgets('zone badges count the selections of each zone', (tester) async {
    await _pump(
      tester,
      initial: {'enteredEarly', 'lateEntry', 'missedRbs', 'stopLossReducedForNegativeClose'},
    );
    Finder badge(String id, String text) => find.descendant(
          of: find.byKey(ValueKey('decision-zone-tab-$id')),
          matching: find.text(text),
        );
    expect(badge('violations', '2'), findsOneWidget);
    expect(badge('analysis', '1'), findsOneWidget);
    expect(badge('risk', '1'), findsOneWidget);
  });

  testWidgets('English locale uses English zone names and sentences', (tester) async {
    await _pump(tester, arabic: false, initial: {'missedRbs', 'missedRfs'});
    expect(find.text('Violations'), findsOneWidget);
    expect(find.text('Analysis quality'), findsOneWidget);
    expect(find.text('Risk management'), findsOneWidget);
    await _openAnalysis(tester);
    await tester.tap(find.byKey(const ValueKey('decision-zone-tab-analysis')));
    await tester.pumpAndSettle();
    expect(find.text('Did not notice a scenario with'), findsOneWidget);
  });

  testWidgets('without a trade direction the tiles are locked', (tester) async {
    await _pump(tester, enabled: false);
    await _openAnalysis(tester);
    final tile = tester.widget<InkWell>(find.byKey(const ValueKey('review-missedRbs')));
    expect(tile.onTap, isNull);
  });
}
