import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  Trade makeTrade({required String mood, List<String> moods = const []}) => Trade(
        id: 'mood-round-trip',
        accountId: 'account',
        market: 'NQ',
        reason: 'setup',
        result: 25,
        riskPercent: 1,
        side: TradeSide.buy,
        confirmation: '',
        sequence: '',
        mood: mood,
        moods: moods,
        tradedAt: DateTime(2026, 11, 25),
      );

  test('multiple mood selections survive JSON round-trip', () {
    final original = makeTrade(
      mood: 'moodCalm',
      moods: const ['moodCalm', 'moodConfident'],
    );
    final restored = Trade.fromJson(original.toJson());
    expect(restored.effectiveMoods, ['moodCalm', 'moodConfident']);
    expect(restored.mood, 'moodCalm',
        reason: 'the legacy primary mood remains available to older callers');
  });

  test('legacy single mood records remain readable', () {
    final legacy = makeTrade(mood: 'moodAnxious');
    final restored = Trade.fromJson(legacy.toJson()..remove('moods'));
    expect(restored.effectiveMoods, ['moodAnxious']);
  });
}
