# تقرير تحديث TraderDesk — 1.7.128+184

## المصدر والإصدار
- الإصدار السابق: `1.7.127+183`. الإصدار الجديد: `1.7.128+184`.

## التعديل: قائمة مستطيل «أسباب الخروج / قرار الاحتفاظ» حسب ملف الجدول
- القائمة صارت 6 عناصر بالاختصارات: `SBR - RBS`، `RFS - SFR`، `Trend Line Touch 3`، `Trend Line Touch 3 Breakout`، `Zone S/D`، `HNS`.
- بعد اختيار العنصر والفريم يظهر الاسم الفعلي حسب اتجاه الصفقة:
  - SBR - RBS: BUY ← SBR، SELL ← RBS
  - RFS - SFR: BUY ← SFR، SELL ← RFS
  - Trend Line Touch 3: BUY ← Trend Line Touch 3 Sell، SELL ← Trend Line Touch 3 Buy
  - Trend Line Touch 3 Breakout: BUY ← ... Sell Breakout، SELL ← ... Buy Breakout
  - Zone S/D: BUY ← Supply Zone، SELL ← Demand Zone
  - HNS: كما هو
- نفس الحل في نموذج الإضافة/التعديل وفي شاشة تفاصيل الصفقة.
- التصميم لم يتغيّر: المستطيل وقائمة الاختيار وقائمة الفريمات تستخدم نفس مكوّنات «سبب الدخول» (`_setupSelectionField` + نافذة الاختيار المركزية + `_showTimeframeSheet`).

## التوافق
- المفاتيح القديمة (`exitSbr`, `exitRbs`, `exitSfr`, `exitRfs`, `exitSupplyZone`, `exitDemandZone`, `exitTrendlineTouch3*`) تبقى مقروءة بنفس اسمها، وتتحول للصف الجديد عند التعديل. لا تغيير في شكل التخزين.

## التحقق
- حُدّث `test/trade_exit_reasons_test.dart` (ترتيب القائمة، الحل حسب الاتجاه، المفاتيح القديمة).
- لا يوجد Flutter SDK في بيئة التنفيذ: لم تُشغَّل `flutter analyze` ولا `flutter test` ولم يُبنَ APK. شغّلها عندك قبل الاعتماد.
