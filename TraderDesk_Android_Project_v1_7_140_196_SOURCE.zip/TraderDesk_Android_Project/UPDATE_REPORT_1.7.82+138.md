# تقرير تحديث TraderDesk — الإصدار 1.7.82+138

## مصدر التعديل والإصدار
- المصدر المستخدم حصراً: `TraderDesk_Android_Project_v1.7.81+137_GPT_SOURCE.zip`.
- الإصدار الناتج: `1.7.82`، رقم البناء `138`.
- التسليم: مشروع Flutter المصدري الكامل بصيغة ZIP.
- لم تُستورد تعديلات من إصدارات لاحقة للمصدر المحدد.

## التغييرات المنفذة

### 1. أسباب الدخول: دمج SBR وRBS في خيار BREAKOUT واحد
- أزيل خيارا الاختيار المنفصلان `SBR` و`RBS` من القائمة النشطة.
- أضيف خيار واحد باسم `BREAKOUT`.
- عند اختيار `BREAKOUT` مع اتجاه `BUY`، تُعرض تسمية السيناريو `RBS`.
- عند اختيار `BREAKOUT` مع اتجاه `SELL`، تُعرض تسمية السيناريو `SBR`.
- ينعكس السيناريو نفسه في رأس نافذة اختيار الفريم، وفي العنصر المحدد، وشرائح أسباب الدخول، وتفاصيل الصفقة المحفوظة، وملخص اليوم.
- لا يظهر `BREAKOUT` كاسم السيناريو بعد تحديد اتجاه؛ يبقى الاسم في قائمة الاختيار فقط. عند عدم وجود اتجاه، تكون التسمية الاحتياطية `BREAKOUT`.
- مفاتيح الصفقات التاريخية `SBR` و`RBS` و`SBR Touch 2` و`RBS Touch 2` ما زالت قابلة للقراءة. عند فتح سجل قديم للتحرير، يُربط الاختيار بخيار `BREAKOUT` الجديد؛ أما السجل غير المعدّل فيحتفظ بالقيمة التي حُفظت به تاريخياً.
- أزيل مسار اختيار Touch 2 من الخيار الجديد BREAKOUT، مع إبقاء مساعدات قراءة قيم Touch 2 القديمة للتوافق مع السجلات السابقة.

### 2. منطقة الارتكاز: دمج Demand Zone وSupply Zone في Zone S/D
- أزيل خيارا الاختيار المنفصلان `Demand Zone` و`Supply Zone` من قائمة الارتكاز النشطة.
- أضيف خيار واحد باسم `Zone S/D`.
- عند اختيار `Zone S/D` مع `BUY`، يظهر في العناصر المحددة ورأس نافذة الفريم باسم `Demand Zone`.
- عند اختياره مع `SELL`، يظهر باسم `Supply Zone`.
- تغيير اتجاه الصفقة يحدّث التسمية المعروضة تلقائياً مع الإبقاء على الفريم المرتبط بالمفتاح الدلالي `zoneSd`.
- عند اختيار Zone S/D الجديد، تُزال مفاتيح الارتكاز القديمة المتعارضة `supplyZone` و`demandZone` من التحديد الجديد وخريطة فريماتها لتجنب ازدواج المنطقة.
- السجلات التاريخية التي تحتوي على `supplyZone` أو `demandZone` تبقى قابلة للقراءة وتظهر باسمها التاريخي؛ لا يجري تحويلها بصمت إلى منطقة أخرى.

## الحفاظ على البيانات والوظائف
- لم يتغير نموذج `TradeEntrySetup` أو `Trade`، ولم تتغير بنية JSON الأساسية.
- بقيت مفاتيح Trend Line وRFS وSFR وHNS وبقية الخيارات الأخرى كما هي.
- بقي ترتيب الفريمات الثمانية وآلية اختيارها كما كانا.
- التغيير الدلالي الجديد يستخدم المفتاح `directionalBreakout` لأسباب الدخول والمفتاح `zoneSd` للارتكاز.
- تم تحديث اختبارات الكتالوج واختبارات الواجهة المتعلقة بالاختيار والاتجاه وحفظ الفريم وقراءة السجلات القديمة.

## الملفات المعدلة
1. `.github/workflows/android-build.yml`
2. `BUILD_INFO_AR.md`
3. `README.md`
4. `RELEASE_NOTES_AR.md`
5. `lib/domain/trade_entry_catalog.dart`
6. `lib/screens/trade_form_screen.dart`
7. `lib/screens/trades_screen.dart`
8. `pubspec.yaml`
9. `scripts/verify_base_anchor_update.py`
10. `scripts/verify_bounce_direction_gate.py`
11. `scripts/verify_entry_reason_names_update.py`
12. `scripts/verify_font_migration.py`
13. `scripts/verify_precision_update.py`
14. `scripts/verify_saved_trade_detail_update.py`
15. `scripts/verify_sr_bounce_liquidity_label_update.py`
16. `scripts/verify_text_cleanup.py`
17. `scripts/verify_timeframe_header_update.py`
18. `test/custom_confirmation_test.dart`
19. `test/entry_conditions_test.dart`
20. `test/trade_entry_catalog_test.dart`

لم تُحذف ملفات من المشروع.

## نتائج التحقق المنفذة فعلياً
- تسعة سكربتات تحقق ساكنة: **264/264 فحصاً ناجحاً**.
  - `verify_base_anchor_update.py`: 18/18
  - `verify_bounce_direction_gate.py`: 40/40
  - `verify_entry_reason_names_update.py`: 32/32
  - `verify_font_migration.py`: 17/17، إضافة إلى نجاح عينتي تغطية المحارف العربية واللاتينية/الأرقام
  - `verify_precision_update.py`: 26/26
  - `verify_saved_trade_detail_update.py`: 29/29
  - `verify_sr_bounce_liquidity_label_update.py`: 25/25
  - `verify_text_cleanup.py`: 44/44
  - `verify_timeframe_header_update.py`: 33/33
- `python3 -m compileall -q scripts`: ناجح.
- فحص صياغة Bash باستخدام `bash -n` على `android/gradlew` وكل `scripts/*.sh`: ناجح.
- تحليل YAML لـ `pubspec.yaml` و`.github/workflows/android-build.yml`: ناجح.
- تحليل ملفات Android XML: **8/8** ناجح.
- مطابقة رقم الإصدار ومعرّفات Artifacts في ملف GitHub Actions: ناجحة ضمن فحوصات التحقق.

## القيود والاختبارات التي لم يمكن تنفيذها
- لا يتوفر Flutter SDK أو Dart SDK في بيئة التنفيذ.
- جرت محاولة تشغيل `flutter analyze` و`flutter test` و`flutter build apk --release --target-platform android-arm64`، لكن كل أمر توقف قبل التنفيذ برسالة `flutter: command not found` (رمز الخروج 127).
- لذلك لم يُنفذ تحليل Dart الفعلي، ولم تُشغّل اختبارات Flutter، ولم يُبنَ APK. ملفات الاختبارات موجودة ومحدّثة لكنها غير منفذة في هذه البيئة.
- التسليم ZIP للمصدر الكامل فقط، وليس APK.

## التحقق من الأرشيف
سيُفحص أرشيف ZIP النهائي بواسطة `unzip -t` قبل التسليم.
