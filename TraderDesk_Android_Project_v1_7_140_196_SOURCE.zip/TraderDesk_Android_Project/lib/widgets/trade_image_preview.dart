import 'dart:async';
import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/trade_file_service.dart';
import '../l10n/app_strings.dart';
import '../theme/app_theme.dart';

/// One image in a trade's ordered, swipeable image gallery.
class TradeImageItem {
  const TradeImageItem({
    required this.path,
    required this.label,
    required this.fileNamePrefix,
  });

  final String path;
  final String label;
  final String fileNamePrefix;
}

/// A tappable local trade-image preview that opens the trade's full-screen
/// gallery. When [galleryImages] is supplied, the viewer can swipe between
/// every image belonging to the trade, regardless of which thumbnail opened it.
class TradeImagePreview extends StatelessWidget {
  const TradeImagePreview({
    super.key,
    required this.path,
    required this.label,
    required this.fileNamePrefix,
    this.height = 100,
    this.galleryImages = const [],
    this.tradedAt,
  });

  final String path;
  final String label;
  final String fileNamePrefix;
  final double height;
  final List<TradeImageItem> galleryImages;
  final DateTime? tradedAt;

  @override
  Widget build(BuildContext context) {
    final file = File(path);
    final tokens = TdTokens.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(
            context,
          ).textTheme.labelMedium?.copyWith(color: tokens.text2),
        ),
        const SizedBox(height: 8),
        Material(
          color: tokens.surface2,
          borderRadius: BorderRadius.circular(14),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            key: ValueKey('trade-image-preview-$fileNamePrefix-$path'),
            onTap: () => _openViewer(context),
            child: Container(
              height: height,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: tokens.lineSubtle, width: 0.8),
              ),
              child: file.existsSync()
                  ? Image.file(
                      file,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          _unavailable(context),
                    )
                  : _unavailable(context),
            ),
          ),
        ),
      ],
    );
  }

  Widget _unavailable(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.broken_image_outlined,
          size: 28,
          color: TdTokens.of(context).text3,
        ),
        if (height >= 96) ...[
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              tr(context, 'imageUnavailable'),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: TdTokens.of(context).text3,
              ),
            ),
          ),
        ],
      ],
    ),
  );

  Future<void> _openViewer(BuildContext context) {
    final images = galleryImages.isEmpty
        ? <TradeImageItem>[
            TradeImageItem(
              path: path,
              label: label,
              fileNamePrefix: fileNamePrefix,
            ),
          ]
        : List<TradeImageItem>.unmodifiable(galleryImages);
    final initialIndex = images.indexWhere((image) => image.path == path);
    return Navigator.of(context).push(
      PageRouteBuilder<void>(
        opaque: true,
        barrierColor: Colors.black,
        pageBuilder: (context, animation, secondaryAnimation) =>
            _TradeImageViewerScreen(
              images: images,
              initialIndex: initialIndex < 0 ? 0 : initialIndex,
              tradedAt: tradedAt,
            ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) =>
            FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 150),
        reverseTransitionDuration: const Duration(milliseconds: 120),
      ),
    );
  }
}

class _TradeImageViewerScreen extends StatefulWidget {
  const _TradeImageViewerScreen({
    required this.images,
    required this.initialIndex,
    required this.tradedAt,
  });

  final List<TradeImageItem> images;
  final int initialIndex;
  final DateTime? tradedAt;

  @override
  State<_TradeImageViewerScreen> createState() =>
      _TradeImageViewerScreenState();
}

class _TradeImageViewerScreenState extends State<_TradeImageViewerScreen> {
  static const double _zoomScale = 2.5;

  late final PageController _pageController;
  late final List<TransformationController> _transformationControllers;
  late int _currentIndex;
  bool _saving = false;
  bool _showOverlay = false;
  bool _isMultiTouch = false;
  Offset? _doubleTapPosition;
  final Map<int, Offset> _activePointers = <int, Offset>{};
  double? _pinchStartDistance;
  double _pinchStartScale = 1;
  Offset _pinchStartTranslation = Offset.zero;
  Offset _pinchStartFocalPoint = Offset.zero;

  TransformationController get _activeTransformationController =>
      _transformationControllers[_currentIndex];

  bool get _isZoomed =>
      _activeTransformationController.value.getMaxScaleOnAxis() > 1.05;

  int _orientationRequestToken = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
    _transformationControllers = List<TransformationController>.generate(
      widget.images.length,
      (_) => TransformationController(),
      growable: false,
    );
    // The image viewer is deliberately edge-to-edge: the photo uses the full
    // physical display, including the area normally occupied by system bars.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_applyOrientationForImage(_currentIndex));
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _orientationRequestToken++;
    for (final controller in _transformationControllers) {
      controller.dispose();
    }
    // Restore the application's normal edge-to-edge system UI when leaving
    // the viewer; do not leave Android status/navigation bars hidden elsewhere.
    SystemChrome.setPreferredOrientations(const <DeviceOrientation>[]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _onPageChanged(int index) {
    _transformationControllers[index].value = Matrix4.identity();
    _pinchStartDistance = null;
    _isMultiTouch = false;
    setState(() {
      _currentIndex = index;
      _doubleTapPosition = null;
    });
    unawaited(_applyOrientationForImage(index));
  }

  void _toggleOverlay() {
    setState(() => _showOverlay = !_showOverlay);
  }

  void _toggleZoomAt(Size viewportSize) {
    final controller = _activeTransformationController;
    if (_isZoomed) {
      controller.value = Matrix4.identity();
      if (mounted) setState(() {});
      return;
    }

    final point = _doubleTapPosition ??
        Offset(viewportSize.width / 2, viewportSize.height / 2);
    final dx = point.dx * (1 - _zoomScale);
    final dy = point.dy * (1 - _zoomScale);
    controller.value = Matrix4.identity()
      ..translateByDouble(dx, dy, 0, 1)
      ..scaleByDouble(_zoomScale, _zoomScale, _zoomScale, 1);
    if (mounted) setState(() {});
  }

  void _onPointerDown(PointerDownEvent event) {
    _activePointers[event.pointer] = event.localPosition;
    if (_activePointers.length == 2) {
      if (!_isMultiTouch) setState(() => _isMultiTouch = true);
      final points = _activePointers.values.toList(growable: false);
      _pinchStartDistance = (points[0] - points[1]).distance;
      _pinchStartScale = _activeTransformationController.value
          .getMaxScaleOnAxis();
      final matrix = _activeTransformationController.value;
      _pinchStartTranslation = Offset(matrix.entry(0, 3), matrix.entry(1, 3));
      _pinchStartFocalPoint = _midpoint(points[0], points[1]);
    } else if (_activePointers.length > 2) {
      _pinchStartDistance = null;
    }
  }

  void _onPointerMove(PointerMoveEvent event, Size viewportSize) {
    if (!_activePointers.containsKey(event.pointer)) return;
    _activePointers[event.pointer] = event.localPosition;
    if (_activePointers.length != 2) return;

    final startDistance = _pinchStartDistance;
    if (startDistance == null || startDistance <= 0) return;
    final points = _activePointers.values.toList(growable: false);
    final currentDistance = (points[0] - points[1]).distance;
    final rawScale = _pinchStartScale * currentDistance / startDistance;
    final nextScale = rawScale.clamp(1.0, 5.0).toDouble();
    final scaleRatio = nextScale / _pinchStartScale;
    final focalPoint = _midpoint(points[0], points[1]);

    var dx = focalPoint.dx -
        scaleRatio * (_pinchStartFocalPoint.dx - _pinchStartTranslation.dx);
    var dy = focalPoint.dy -
        scaleRatio * (_pinchStartFocalPoint.dy - _pinchStartTranslation.dy);
    if (nextScale <= 1.001) {
      dx = 0;
      dy = 0;
    } else {
      dx = dx.clamp(viewportSize.width * (1 - nextScale), 0).toDouble();
      dy = dy.clamp(viewportSize.height * (1 - nextScale), 0).toDouble();
    }

    final controller = _activeTransformationController;
    final wasZoomed = controller.value.getMaxScaleOnAxis() > 1.05;
    controller.value = Matrix4.identity()
      ..translateByDouble(dx, dy, 0, 1)
      ..scaleByDouble(nextScale, nextScale, nextScale, 1);
    final isZoomedNow = controller.value.getMaxScaleOnAxis() > 1.05;
    // The image itself listens through AnimatedBuilder. Rebuild the gallery
    // only when scrolling must be locked/unlocked, not for every pinch frame.
    if (wasZoomed != isZoomedNow && mounted) setState(() {});
  }

  void _onPointerEnd(PointerEvent event) {
    _activePointers.remove(event.pointer);
    if (_activePointers.length < 2) {
      _pinchStartDistance = null;
      if (_isMultiTouch && mounted) setState(() => _isMultiTouch = false);
    }
  }

  Future<void> _applyOrientationForImage(int index) async {
    if (index < 0 || index >= widget.images.length) return;
    final requestToken = ++_orientationRequestToken;
    final file = File(widget.images[index].path);
    if (!await file.exists()) return;
    if (!mounted || requestToken != _orientationRequestToken) return;

    final stream = FileImage(file).resolve(const ImageConfiguration());
    final completer = Completer<Size>();
    late final ImageStreamListener listener;
    listener = ImageStreamListener(
      (info, synchronousCall) {
        stream.removeListener(listener);
        final imageSize = Size(
          info.image.width.toDouble(),
          info.image.height.toDouble(),
        );
        info.dispose();
        if (!completer.isCompleted) completer.complete(imageSize);
      },
      onError: (error, stackTrace) {
        stream.removeListener(listener);
        if (!completer.isCompleted) completer.completeError(error, stackTrace);
      },
    );
    stream.addListener(listener);

    Size imageSize;
    try {
      imageSize = await completer.future.timeout(const Duration(seconds: 5));
    } catch (_) {
      stream.removeListener(listener);
      return;
    }

    if (!mounted || requestToken != _orientationRequestToken) return;
    final isLandscape = imageSize.width > imageSize.height;
    try {
      await SystemChrome.setPreferredOrientations(
        isLandscape
            ? const <DeviceOrientation>[
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
              ]
            : const <DeviceOrientation>[DeviceOrientation.portraitUp],
      );
    } catch (_) {
      // Some Android form factors do not permit app-requested orientation
      // changes. The image still uses a true full-bleed crop in that case.
    }
  }

  Offset _midpoint(Offset first, Offset second) =>
      Offset((first.dx + second.dx) / 2, (first.dy + second.dy) / 2);

  Future<void> _saveCurrentImage() async {
    if (_saving) return;
    final messenger = ScaffoldMessenger.of(context);
    final image = widget.images[_currentIndex];
    setState(() => _saving = true);
    try {
      final file = File(image.path);
      if (!await file.exists()) {
        throw const FileSystemException('Image file is unavailable');
      }
      final extension = _imageExtension(image.path);
      final bytes = await file.readAsBytes();
      final saved = await TradeFileService.saveImage(
        bytes,
        fileName:
            '${_safeFileName(image.fileNamePrefix)}_${_timestamp()}.$extension',
        extension: extension,
        mimeType: _mimeType(extension),
      );
      if (!mounted) return;
      if (saved != null) {
        messenger.showSnackBar(
          SnackBar(content: Text(tr(context, 'imageSaved'))),
        );
      }
    } catch (error) {
      if (mounted) {
        messenger.showSnackBar(
          SnackBar(content: Text('${tr(context, 'operationFailed')}: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentImage = widget.images[_currentIndex];
    final timeText = widget.tradedAt == null
        ? null
        : TimeOfDay.fromDateTime(widget.tradedAt!.toLocal()).format(context);
    final topInset = MediaQuery.viewPaddingOf(context).top;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox.expand(
        child: Stack(
          fit: StackFit.expand,
          children: [
            LayoutBuilder(
              builder: (context, constraints) {
                final viewportSize = constraints.biggest;
                return Listener(
                  key: const ValueKey('trade-image-multi-touch-listener'),
                  onPointerDown: _onPointerDown,
                  onPointerMove: (event) =>
                      _onPointerMove(event, viewportSize),
                  onPointerUp: _onPointerEnd,
                  onPointerCancel: _onPointerEnd,
                  child: PageView.builder(
                    key: const ValueKey('trade-image-gallery'),
                    controller: _pageController,
                    itemCount: widget.images.length,
                    allowImplicitScrolling: true,
                    pageSnapping: true,
                    padEnds: false,
                    dragStartBehavior: DragStartBehavior.down,
                    physics: _isZoomed || _isMultiTouch
                        ? const NeverScrollableScrollPhysics()
                        : const PageScrollPhysics(
                            parent: ClampingScrollPhysics(),
                          ),
                    onPageChanged: _onPageChanged,
                    itemBuilder: (context, index) {
                      final image = widget.images[index];
                      final file = File(image.path);
                      final imageContent = SizedBox(
                        width: viewportSize.width,
                        height: viewportSize.height,
                        child: file.existsSync()
                            ? Image.file(
                                file,
                                key: ValueKey('trade-image-fullbleed-$index'),
                                width: viewportSize.width,
                                height: viewportSize.height,
                                // Paint the actual photo edge-to-edge. No
                                // blurred duplicate or grey side panels are
                                // composed behind it. Matching orientation to
                                // the source image above limits the crop.
                                fit: BoxFit.cover,
                                alignment: Alignment.center,
                                gaplessPlayback: true,
                                filterQuality: FilterQuality.medium,
                                errorBuilder: (context, error, stackTrace) =>
                                    _viewerUnavailable(context),
                              )
                            : _viewerUnavailable(context),
                      );

                      return GestureDetector(
                        key: ValueKey('trade-image-viewer-gestures-$index'),
                        behavior: HitTestBehavior.opaque,
                        onTap: _toggleOverlay,
                        onDoubleTapDown: (details) {
                          _doubleTapPosition = details.localPosition;
                        },
                        onDoubleTap: () => _toggleZoomAt(viewportSize),
                        child: ClipRect(
                          child: AnimatedBuilder(
                            animation: _transformationControllers[index],
                            builder: (context, child) => Transform(
                              key: ValueKey('zoomable-trade-image-$index'),
                              alignment: Alignment.topLeft,
                              transform: _transformationControllers[index].value,
                              child: child,
                            ),
                            child: imageContent,
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: IgnorePointer(
                ignoring: !_showOverlay,
                child: AnimatedOpacity(
                  key: const ValueKey('trade-image-overlay-opacity'),
                  opacity: _showOverlay ? 1 : 0,
                  duration: const Duration(milliseconds: 170),
                  curve: Curves.easeOut,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _toggleOverlay,
                    child: Container(
                      padding: EdgeInsetsDirectional.fromSTEB(
                        8,
                        topInset + 6,
                        10,
                        12,
                      ),
                      decoration: const BoxDecoration(
                        color: Color(0xB8000000),
                      ),
                      child: Row(
                        children: [
                          IconButton(
                            key: const ValueKey('trade-image-viewer-back'),
                            tooltip: MaterialLocalizations.of(context)
                                .backButtonTooltip,
                            onPressed: () =>
                                Navigator.of(context).maybePop(),
                            color: Colors.white,
                            icon: const Icon(Icons.arrow_back_rounded),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  currentImage.label,
                                  key: const ValueKey(
                                    'trade-image-viewer-image-label',
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    height: 1.25,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                if (timeText != null) ...[
                                  const SizedBox(height: 3),
                                  Text(
                                    timeText,
                                    key: const ValueKey(
                                      'trade-image-viewer-trade-time',
                                    ),
                                    textDirection: TextDirection.ltr,
                                    style: const TextStyle(
                                      color: Color(0xFFD0D0D0),
                                      fontSize: 12,
                                      height: 1.2,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            key: const ValueKey('save-trade-image'),
                            tooltip: tr(context, 'saveImage'),
                            visualDensity: VisualDensity.compact,
                            iconSize: 20,
                            onPressed: _saving ? null : _saveCurrentImage,
                            color: Colors.white,
                            icon: _saving
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : const Icon(Icons.download_outlined),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _viewerUnavailable(BuildContext context) => Center(
    child: Text(
      tr(context, 'imageUnavailable'),
      style: const TextStyle(color: Colors.white),
    ),
  );
}

String _safeFileName(String prefix) {
  final safe = prefix.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
  return safe.isEmpty ? 'traderdesk_image' : safe;
}

String _imageExtension(String path) {
  final basename = path.split(Platform.pathSeparator).last;
  final dot = basename.lastIndexOf('.');
  final extension = dot < 0 ? '' : basename.substring(dot + 1).toLowerCase();
  const supported = {'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'};
  return supported.contains(extension) ? extension : 'jpg';
}

String _mimeType(String extension) => switch (extension) {
  'png' => 'image/png',
  'webp' => 'image/webp',
  'gif' => 'image/gif',
  'bmp' => 'image/bmp',
  _ => 'image/jpeg',
};

String _timestamp() {
  final now = DateTime.now();
  return '${now.year.toString().padLeft(4, '0')}'
      '${now.month.toString().padLeft(2, '0')}'
      '${now.day.toString().padLeft(2, '0')}_'
      '${now.hour.toString().padLeft(2, '0')}'
      '${now.minute.toString().padLeft(2, '0')}'
      '${now.second.toString().padLeft(2, '0')}';
}
