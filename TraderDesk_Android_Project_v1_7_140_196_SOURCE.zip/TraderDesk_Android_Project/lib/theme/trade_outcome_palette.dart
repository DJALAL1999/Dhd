import 'package:flutter/material.dart';

import '../models/trade.dart';
import 'app_theme.dart';

/// Single source of truth for the outcome colour of a trade.
///
/// Win and loss keep the app's profit / loss tokens. The two "no P&L" outcomes
/// are deliberately separated by hue, not only by brightness:
///  * break-even — a cool indigo-periwinkle (blue-violet hue, visible chroma);
///  * missed — a neutral cool grey (almost no chroma).
/// Every surface that tints a trade by its outcome (save bar, classification
/// filter, trade cards, day rows, popups) must read the colour from here so
/// the user can tell the trade type from the colour alone.
abstract final class TradeOutcomePalette {
  static Color breakEven(Brightness brightness) => brightness == Brightness.dark
      ? const Color(0xFF8C99D6)
      : const Color(0xFF5663B3);

  static Color missed(Brightness brightness) => brightness == Brightness.dark
      ? const Color(0xFFA9B1BC)
      : const Color(0xFF6A7381);

  /// Accent for a classification; `null` (unclassified) uses the muted text
  /// tone supplied by the caller's tokens.
  static Color of(TradeClassification? value, TdTokens tokens, Brightness brightness) =>
      switch (value) {
        TradeClassification.win => tokens.profit,
        TradeClassification.loss => tokens.loss,
        TradeClassification.breakEven => breakEven(brightness),
        TradeClassification.missed => missed(brightness),
        null => tokens.text3,
      };
}
