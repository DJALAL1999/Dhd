import '../models/trade.dart';
import 'trade_ordering.dart';

class TradeAnalytics {
  const TradeAnalytics({
    required this.tradeCount,
    required this.recordCount,
    required this.missedTradeCount,
    required this.unclassifiedTradeCount,
    required this.wins,
    required this.losses,
    required this.breakEven,
    required this.netProfit,
    required this.averageWin,
    required this.averageLoss,
    required this.winRatePercent,
    required this.maxDrawdownAmount,
    required this.maxDrawdownPercent,
  });

  /// Executed trades only: wins + losses + break-even trades.
  final int tradeCount;
  /// Every saved journal record, including missed and unresolved legacy rows.
  final int recordCount;
  final int missedTradeCount;
  final int unclassifiedTradeCount;
  final int wins;
  final int losses;
  final int breakEven;
  final double netProfit;
  final double averageWin;
  final double averageLoss;
  final double winRatePercent;
  final double maxDrawdownAmount;
  final double maxDrawdownPercent;

  factory TradeAnalytics.calculate(
    List<Trade> input, {
    double startingBalance = 0,
  }) {
    if (!startingBalance.isFinite) {
      throw ArgumentError.value(startingBalance, 'startingBalance');
    }
    final trades = [...input]..sort(compareTradesAscending);
    var wins = 0;
    var losses = 0;
    var breakEven = 0;
    var missed = 0;
    var unclassified = 0;
    var winTotal = 0.0;
    var lossTotal = 0.0;
    var net = 0.0;

    var equity = startingBalance;
    var peak = startingBalance;
    var maxDrawdown = 0.0;
    var maxDrawdownPercent = 0.0;
    for (final trade in trades) {
      final result = trade.result;
      if (!result.isFinite) throw ArgumentError.value(result, 'trade.result');
      final classification = trade.effectiveClassification;
      if (classification == null) {
        unclassified++;
        continue;
      }
      if (classification == TradeClassification.missed) {
        missed++;
        continue;
      }

      net += result;
      switch (classification) {
        case TradeClassification.win:
          wins++;
          winTotal += result;
          break;
        case TradeClassification.loss:
          losses++;
          lossTotal += result.abs();
          break;
        case TradeClassification.breakEven:
          breakEven++;
          break;
        case TradeClassification.missed:
          // Handled above.
          break;
      }
      equity += result;
      if (equity > peak) peak = equity;
      final drawdown = peak - equity;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
      final drawdownPercent = peak > 0 ? drawdown / peak * 100 : 0.0;
      if (drawdownPercent > maxDrawdownPercent) {
        maxDrawdownPercent = drawdownPercent;
      }
    }
    if (![net, winTotal, lossTotal, equity].every((value) => value.isFinite)) {
      throw ArgumentError('Trade totals exceed the supported numeric range.');
    }
    final averageWin = wins == 0 ? 0.0 : winTotal / wins;
    final averageLoss = losses == 0 ? 0.0 : lossTotal / losses;
    final executedCount = wins + losses + breakEven;

    return TradeAnalytics(
      tradeCount: executedCount,
      recordCount: trades.length,
      missedTradeCount: missed,
      unclassifiedTradeCount: unclassified,
      wins: wins,
      losses: losses,
      breakEven: breakEven,
      netProfit: net,
      averageWin: averageWin,
      averageLoss: averageLoss,
      // Break-even trades are closed trades and remain in the denominator;
      // missed opportunities and unresolved legacy rows are not.
      winRatePercent: executedCount == 0 ? 0 : wins / executedCount * 100,
      maxDrawdownAmount: maxDrawdown,
      maxDrawdownPercent: maxDrawdownPercent,
    );
  }
}
