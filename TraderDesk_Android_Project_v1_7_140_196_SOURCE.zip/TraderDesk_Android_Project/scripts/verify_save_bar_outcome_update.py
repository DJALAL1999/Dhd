#!/usr/bin/env python3
"""Static checks for 1.7.110+166: merged outcome + save bar and outcome colours."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
def read(p): return (ROOT / p).read_text(encoding='utf-8')
FORM = read('lib/screens/trade_form_screen.dart')
BAR = read('lib/widgets/trade_save_bar.dart')
PALETTE = read('lib/theme/trade_outcome_palette.dart')
TRADES = read('lib/screens/trades_screen.dart')
DAYS = read('lib/screens/days_screen.dart')
PUBSPEC = read('pubspec.yaml')
WORKFLOW = read('.github/workflows/android-build.yml')
T_CC = read('test/custom_confirmation_test.dart')
T_EC = read('test/entry_conditions_test.dart')
T_APP = read('test/trading_app_test.dart')
STRINGS = read('lib/l10n/app_strings.dart')
failed = []
def check(name, ok):
    print(('PASS' if ok else 'FAIL'), '|', name)
    if not ok: failed.append(name)

# version
check('pubspec is 1.7.110+166', 'version: 1.7.110+166' in PUBSPEC)
check('workflow identity updated', 'TraderDesk 1.7.110+166' in WORKFLOW and 'traderdesk-1.7.110-build166-arm64-v8a-release' in WORKFLOW)
check('update report exists', (ROOT / 'UPDATE_REPORT_1.7.110+166.md').exists())

# 1) automatic outcome
check('outcome derived automatically (reconcile helper)', 'void _reconcileClassification()' in FORM)
check('reconcile runs on init, sign pick, sign edit and no-entry link',
      FORM.count('_reconcileClassification();') >= 4)
check('positive sign => win, negative => loss, link => missed',
      'if (_resultSign == 1) return const [TradeClassification.win];' in FORM and
      'if (_resultSign == -1) return const [TradeClassification.loss];' in FORM and
      'return const [TradeClassification.missed];' in FORM)
check('old classification sheet and chips are gone',
      '_chooseClassification' not in FORM and '_buildMissedOutcomeChip' not in FORM and
      '_buildBreakEvenTypeChip' not in FORM and 'choose-trade-classification-button' not in FORM)

# 2) merged bar with menus
check('form uses the merged TradeSaveBar inside the save slot',
      'TradeSaveBar(' in FORM and 'key: _saveSlotKey,' in FORM)
check('four outcome styles map to distinct icons',
      all(i in BAR for i in ['Icons.trending_up_rounded', 'Icons.trending_down_rounded', 'Icons.drag_handle_rounded', 'Icons.visibility_off_outlined']))
check('pill shows title, subtitle, chevron only when a menu exists', "'trade-outcome-pill-title'" in BAR and "'trade-outcome-pill-subtitle'" in BAR and 'if (hasMenu)' in BAR)
check('win/loss subtitle is the amount, left-to-right ("USD 250+")', "'$currency $text${result > 0 ? '+' : '−'}'" in FORM and 'subtitleLtr = true;' in FORM)
check('break-even and missed sub-choices live in one in-place menu',
      "_OutcomeChoice(" in FORM and 'TradeClassification.breakEven,' in FORM and 'MissedTradeOutcome.values' in FORM and 'BreakEvenType.values' in FORM)
check('menu only for break-even / missed (no menu when sign decides)', 'bool get _outcomeHasMenu' in FORM and 'hasMenu: _outcomeHasMenu' in FORM)
check('save with a missing sub-choice opens the menu', '_needsOutcomeChoice && _outcomeHasMenu' in FORM and '? _openOutcomeMenu' in FORM)
check('save validation still guards break-even type and missed outcome',
      'Choose the break-even type before saving.' in FORM and 'Choose whether the missed opportunity was a win or loss before saving.' in FORM)

# 3) the word "الصفقة" under "حفظ" is removed
check('button label is just save (حفظ)', "saveLabel: tr(context, 'save')" in FORM and "'save': 'حفظ'," in STRINGS and 'الصفقة' not in BAR)

# 4) colours
check('palette defines separate break-even and missed colours',
      'static Color breakEven(' in PALETTE and 'static Color missed(' in PALETTE and 'static Color of(' in PALETTE)
check('no surface still colours missed with the generic neutral token',
      'TradeClassification.missed => tokens.neutral' not in TRADES and
      'TradeClassification.missed => TdTokens.of(context).neutral' not in DAYS and
      '_TradeFilter.missed => tokens.neutral' not in TRADES)
check('trades list, filters, cards and days use the shared missed colour',
      TRADES.count('TradeOutcomePalette.missed(') >= 3 and DAYS.count('TradeOutcomePalette.missed(') >= 3)

# 5) tests
check('widget tests cover the merged bar', 'without a result sign the save bar offers break-even and missed in one menu' in T_CC and 'save opens the outcome menu in place when a choice is missing' in T_CC)
check('win/loss/missed auto-style tests updated', 'A positive result is a win' in T_EC and 'a negative result permits only the loss outcome' in T_APP)
sys.exit(1 if failed else 0)
