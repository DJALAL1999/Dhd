#!/usr/bin/env python3
"""Regression guard for the optionEdgeOpacity Dart final-field compile failure."""
from pathlib import Path
import re

source = Path('lib/screens/trades_screen.dart').read_text(encoding='utf-8')

# This property is specific to chip borders. It must be declared only by
# _TradeDetailChipField, whose constructor explicitly initializes it.
assert source.count('final double optionEdgeOpacity;') == 1, \
    'optionEdgeOpacity must have exactly one field declaration'

chip_start = source.index('class _TradeDetailChipField')
chip_end = source.find('\nclass ', chip_start + 1)
chip = source[chip_start:chip_end if chip_end >= 0 else len(source)]
assert 'this.optionEdgeOpacity = 1,' in chip, \
    '_TradeDetailChipField constructor must initialize optionEdgeOpacity'
assert 'final double optionEdgeOpacity;' in chip
assert '.withValues(alpha: optionEdgeOpacity)' in chip

# Unrelated detail widgets must not declare this final field.
for class_name in (
    '_TradeDetailMarketDirectionField',
    '_TradeDetailMindsetField',
    '_TradeDetailRow',
):
    start = source.index(f'class {class_name}')
    end = source.find('\nclass ', start + 1)
    block = source[start:end if end >= 0 else len(source)]
    assert 'final double optionEdgeOpacity;' not in block, \
        f'{class_name} must not declare an uninitialized optionEdgeOpacity'

print('PASS: optionEdgeOpacity is initialized only in _TradeDetailChipField')
print('PASS: unrelated detail widgets no longer contain uninitialized final fields')
print('2/2 checks passed')
