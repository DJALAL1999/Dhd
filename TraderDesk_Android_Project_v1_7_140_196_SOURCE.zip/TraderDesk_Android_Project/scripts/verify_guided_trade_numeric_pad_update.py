#!/usr/bin/env python3
"""Static regression checks for the in-app trade numeric keypad update."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/release-arm64.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []


def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))


def method_body(signature: str, next_signature: str) -> str:
    if signature not in FORM or next_signature not in FORM:
        return ''
    return FORM.split(signature, 1)[1].split(next_signature, 1)[0]


check('version is 1.7.125+181', 'version: 1.7.125+181' in PUBSPEC)
check('ARM64 APK artifact uses build 181', 'traderdesk-1.7.125-build181-arm64-v8a-release' in WORKFLOW)
check('Dart symbols artifact uses build 181', 'traderdesk-1.7.125-build181-arm64-dart-symbols' in WORKFLOW)
check('build information identifies 1.7.125+181', '1.7.125+181' in BUILD_INFO and 'UPDATE_REPORT_1.7.125+181.md' in BUILD_INFO)
check('release notes identify 1.7.125+181', '1.7.125+181' in RELEASE_NOTES)

# Native keyboard suppression and keypad presentation.
result_field = method_body('Widget _resultAmountField(', 'Widget _numericField(')
numeric_field = method_body('Widget _numericField(', 'Widget _readoutField(')
check('Result field always suppresses the system keyboard', 'readOnly: true' in result_field and 'keyboardType: TextInputType.none' in result_field)
check('Expected Loss always suppresses the system keyboard', 'readOnly: true' in numeric_field and 'keyboardType: TextInputType.none' in numeric_field)
check('both amount fields open the in-app keypad', '_activateNumericPad(_NumericEntryTarget.result)' in result_field and '_activateNumericPad(_NumericEntryTarget.expectedLoss)' in numeric_field)
check('keypad input starts at the end of the selected amount', 'controller.selection = TextSelection.collapsed(' in method_body('void _activateNumericPad(', 'void _dismissNumericPad(') and 'numeric keypad entry starts at the end' in TESTS)
check('keypad contains all ten digits', all(row in FORM for row in ("['1', '2', '3']", "['4', '5', '6']", "['7', '8', '9']")) and "_numericPadKey('0', '0', tokens)" in FORM)
check('locale decimal separator is displayed and inserted', "final decimalLabel = _ar ? ',' : '.';" in FORM and "final decimal = _ar ? ',' : '.';" in FORM)
check('keypad supports backspace and clear', "key == 'backspace'" in FORM and "key == 'clear'" in FORM)
check('result sign can be changed without losing its magnitude', 'void _changeResultSignFromPad()' in FORM and 'final magnitude = current.replaceFirst' in FORM)
check('keypad action is labelled Continue in Arabic and English', "_copy('متابعة', 'Continue')" in FORM and 'انتهاء' not in method_body('Widget _buildNumericPad()', 'void _handleResultChanged'))
check('keypad is anchored to the bottom and respects safe area', 'Positioned(\n                  left: 0,\n                  right: 0,\n                  bottom: 0' in FORM and 'return SafeArea(' in method_body('Widget _buildNumericPad()', 'void _handleResultChanged'))
check('scrollable content reserves space for the keypad', '_activeNumericPad == null ? 34 : 350' in FORM)

# The action reuses the existing single-source smart-guidance path.
continue_handler = method_body('void _handleNumericPadContinue()', 'Widget _numericPadKey(')
check('Continue routes Result into existing guarded submit handler', '_submitGuidedResultOnce()' in continue_handler)
check('Continue routes Expected Loss into existing guarded submit handler', '_submitGuidedExpectedLossOnce()' in continue_handler)
advance = method_body('Future<void> _advanceGuidedEntry()', 'Future<void> _prepareAutoPopup')
check('smart resolver shows keypad only for numeric incomplete fields', '_AutoEntryStep.result => _NumericEntryTarget.result' in advance and '_AutoEntryStep.expectedLoss => _NumericEntryTarget.expectedLoss' in advance and '_ => null' in advance)
check('smart resolver hides keypad before choice overlays', '_activeNumericPad = switch (next)' in advance and '_AutoEntryStep.direction' in advance and '_AutoEntryStep.market' in advance and '_AutoEntryStep.mindset' in advance)
check('Continue validates result before advancing', '_resultValidator(_result.text)' in method_body('Future<void> _continueAfterResult()', 'Future<void> _continueAfterExpectedLoss'))
check('Continue validates expected loss before advancing', '_expectedLossValidator(_expectedLoss.text)' in method_body('Future<void> _continueAfterExpectedLoss()', 'Future<void> _advanceGuidedEntry'))
check('completed amounts are skipped by the unchanged first-incomplete resolver', '_nextIncompleteGuidedStep' in advance)
check('saved-trade manual keypad Continue closes rather than starting guidance', 'if (!_guidedEntryActive) {\n      _dismissNumericPad();\n      return;' in continue_handler)
check('negative result skips Expected Loss only during new-trade guidance', '_guidedEntryActive' in method_body('void _activateNumericPad(', 'void _dismissNumericPad') and "(_parseResult() ?? 0) < 0" in method_body('void _activateNumericPad(', 'void _dismissNumericPad') and 'losing new trade skips planned loss' in method_body('void _activateNumericPad(', 'void _dismissNumericPad'))

# Widget tests exercise keypad UI, amount entry, continue, and sign replacement.
check('widget tests use custom keypad keys instead of system text entry', 'trade-numpad-key-$key' in TESTS and 'tester.enterText(' not in TESTS)
check('widget tests assert custom Continue and no native keyboard type', 'trade-numpad-continue' in TESTS and 'TextInputType.none' in TESTS)
check('widget tests exercise decimal and backspace keys; the Clear key is gone', all(key in TESTS for key in ('trade-numpad-key-decimal', 'trade-numpad-key-backspace')) and "findsNothing,\n        reason: 'the keypad no longer has a Clear key'" in TESTS and 'trade-numpad-clear' not in FORM and "controller!.text, '+1,5'" in TESTS and "controller!.text, '+'" in TESTS)
check('widget tests cover positive flow into Expected Loss then Direction', "'profit advances through expected loss, direction, market, and multi-mindset'" in TESTS and "await tester.tap(find.byKey(const ValueKey('trade-numpad-continue')))" in TESTS)
check('widget tests cover negative flow skipping Expected Loss', "'loss skips expected loss and advances through direction, market, and mindset'" in TESTS)
check('widget tests cover replacing the result sign without losing amount', "'the result sign can be deleted from the amount and chosen again'" in TESTS and 'trade-numpad-change-sign' in TESTS)
check('live monitoring regression test remains present', 'live guidance detects cleared Mindset after a later Market edit' in TESTS)
check('saved losing trades can still edit historical Expected Loss manually', 'expectedLoss: 35' in TESTS and 'saved losing trade keeps its historical Expected Loss field manually editable' in TESTS and 'Continue only closes the keypad while editing an existing trade' in TESTS)
check('original saved-trade/manual editing tests remain in place', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
