#!/usr/bin/env python3
"""Static regression checks for TraderDesk 1.7.115+171 selection-list folding and retained form section tabs."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
REPORT = ROOT / "UPDATE_REPORT_1.7.115+171.md"

checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


check("package version is 1.7.115+171", "version: 1.7.115+171" in PUBSPEC)
check("workflow names release 1.7.115+171", "TraderDesk 1.7.115+171 Android Release APK" in WORKFLOW)
check("workflow artifact names use build 171", "traderdesk-1.7.115-build171-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.115-build171-arm64-dart-symbols" in WORKFLOW)
check("new release report exists", REPORT.is_file())

check("section navigation is one horizontal Row", "Widget _buildFormSectionNavigation(BuildContext context)" in FORM and "return Row(" in FORM[FORM.index("Widget _buildFormSectionNavigation(BuildContext context)"):FORM.index("Widget _buildFormSectionTab(")])
check("all three tabs have separate stable keys", all(f"key: '{key}'" in FORM for key in ("details", "conditions", "behavior")) and "trade-form-section-tab-$keyName" in FORM)
check("full Arabic titles are defined", all(title in FORM for title in ("بيانات الصفقة", "ظروف الدخول", "سلوك التداول")))
check("short Arabic labels are defined", all(title in FORM for title in ("shortAr: 'بيانات'", "shortAr: 'ظروف'", "shortAr: 'سلوك'")))
check("selected label uses full title and idle label uses short title", "selected ? fullTitle : shortTitle" in FORM)
check("original icons are used", all(icon in FORM for icon in ("Icons.receipt_long_outlined", "Icons.radar_rounded", "Icons.fact_check_outlined")))
check("original section tone constants are used", all(token in FORM for token in ("tone: _dataTone", "tone: conditionsTone", "tone: _behaviorTone")))
check("form tabs use saved-detail fills and soft thin borders", "TradeDetailPalette.dataSurfaceDark" in FORM and "TradeDetailPalette.entryConditionsPanelDark" in FORM and "TradeDetailPalette.reviewOuterDark" in FORM and "width: .8" in FORM)
check("tab children expand equally", "Expanded(\n            child: _buildFormSectionTab(" in FORM)
check("form side padding is 6dp", "padding: const EdgeInsets.fromLTRB(6, 10, 6, 34)" in FORM)
check("all panels keep their state while hidden", FORM.count("maintainState: true") >= 3 and FORM.count("maintainAnimation: true") >= 3)
check("each separate panel reuses the same existing card and hides duplicate header", all(f"showHeader: false" in FORM[FORM.index(marker):FORM.index(end, FORM.index(marker))] for marker, end in (("Widget _buildTradeDetailsSection", "String _confirmationLabel"), ("Widget _buildEntryConditionsSection", "Widget _buildBehaviorCard"), ("Widget _buildBehaviorCard", "/// One selectable row"))))
check("conditions retain practical-link state and field controls", "_hasPracticalNoEntryReason" in FORM and "_togglePracticalNoEntryReverseSignal" in FORM and "practical-no-entry-link-${setups[index].optionKey}" in FORM)
check("behavior headings remain in requested order", FORM.index("title: _copy('القرارات'", FORM.index("Widget _buildBehaviorCard")) < FORM.index("title: _copy('الالتزام'", FORM.index("Widget _buildBehaviorCard")) < FORM.index("title: _copy('أسباب عدم الدخول'", FORM.index("Widget _buildBehaviorCard")))
check("save bar remains after images", FORM.index("_sectionCard(\n                    context,\n                    title: _copy('صور الصفقة'") < FORM.index("_buildSaveBar(account.currency)"))
check("obsolete cross-card rail painter is removed from the separated layout", "_LinkedSectionConnectorPainter" not in FORM and "_linkedSectionsRailKey" not in FORM)
check("behavior subsections are one horizontal row", "trade-behavior-section-tab-$keyName" in FORM and "trade-behavior-section-tab-surface-$keyName" in FORM and "Row(" in FORM[FORM.index("Widget _buildBehaviorCard(BuildContext context)"):FORM.index("Widget _buildBehaviorSectionTab(")])
check("behavior subsections reuse saved decision, commitment and no-entry surfaces", all(name in FORM for name in ("TradeDetailPalette.reviewDecisionDark", "TradeDetailPalette.reviewCommitmentDark", "TradeDetailPalette.reviewNoEntryDark", "TradeDetailPalette.reviewDecisionLight", "TradeDetailPalette.reviewCommitmentLight", "TradeDetailPalette.reviewNoEntryLight")))
check("behavior contents retain independent state while switching", FORM.count("maintainState: true") >= 4 and "trade-decision-zones" in FORM and "trade-no-entry-zones" in FORM)
SAVE_BAR = (ROOT / "lib/widgets/trade_save_bar.dart").read_text(encoding="utf-8")
check("save bar height reduced to 64dp", "static const double height = 64" in SAVE_BAR)
check("win/loss save accent is blended into app surface", "final isWinOrLoss" in SAVE_BAR and "baseAccent.withValues(alpha: isDark ? .84 : .88)" in SAVE_BAR)
check("save bar outer edge is softened", "accent.withValues(alpha: isDark ? .22 : .16)" in SAVE_BAR and "width: .8" in SAVE_BAR)
check("widget tests cover horizontal behavior tabs and the save bar", "trade-behavior-section-tab-decisions" in TESTS and "muted win/loss tones" in (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8"))
check("widget test covers layout, names, icons, navigation and state retention", all(part in TESTS for part in ("trade form section and behavior tabs are horizontal", "detailsRect.width", "find.text('بيانات الصفقة')", "find.text('ظروف الدخول')", "find.text('سلوك التداول')", "trade-behavior-section-tab-decisions", "trade-decision-zones")))


# Selection-list folding: each multi-selection field uses the same selected-summary component.
DECISIONS = (ROOT / "lib/widgets/trade_decision_zones.dart").read_text(encoding="utf-8")
check("decision violations, analysis and risk all fold through the shared summary", "_setCollapsed(group.id, !_collapsed.contains(group.id))" in DECISIONS and "child: collapsed ? summary : list" in DECISIONS and "decision-zone-summary-${group.id}" in DECISIONS)
check("legacy analysis summary sentence and stable key are retained", "decision-analysis-summary-sentence" in DECISIONS and "tradeAnalysisMissedSentence(" in DECISIONS)
check("selected-summary component supports optional practical-link markers", "final List<Widget?> trailingWidgets" in DECISIONS and "trailingWidgets[i]!" in DECISIONS)
check("data selection fields expose title toggles and selected summaries", all(token in FORM for token in ("trade-selection-field-title-$fieldId", "trade-setup-summary-$fieldId", "trade-anchor-selected-summary")))
check("all data multi-select fields are connected to fold state", all(token in FORM for token in ("fieldId: 'entry-reason'", "fieldId: 'confirmation'", "fieldId: 'anchors'", "_anchorValuesCollapsed")))
check("entry-condition fields use the shared summary for both categories", all(token in FORM for token in ("fieldId: 'reverse-signals'", "fieldId: 'bounce-area'", "entry-condition-summary-$fieldId")))
check("practical link marker remains visible in folded opposing-signal summary", "trailingWidgets: [" in FORM and "practicalNoEntrySetups.contains(setup)" in FORM and "Icons.link_rounded" in FORM)
check("commitment folds into a shared selected summary", "trade-commitment-selection-summary" in FORM and "trade-commitment-selection-list" in FORM and "_commitmentCollapsed" in FORM)
check("selection summary tests cover confirmation, anchors, entry reason and entry conditions", all(token in TESTS for token in ("trade-setup-summary-confirmation", "trade-anchor-selected-summary", "trade-setup-summary-entry-reason", "entry-condition-summary-reverse-signals")))
DECISION_TESTS = (ROOT / "test/trade_decision_zones_test.dart").read_text(encoding="utf-8")
BEHAVIOR_TESTS = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
check("decision tests cover folding violations and risk groups", "violations and risk lists also fold into the shared selected summary" in DECISION_TESTS)
check("commitment test verifies fold and reopen behavior", "trade-commitment-selection-summary" in BEHAVIOR_TESTS and "trade-commitment-selection-list" in BEHAVIOR_TESTS)

failed = [name for name, passed in checks if not passed]
for name, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
