#!/usr/bin/env python3
"""Static checks for 1.7.110+166: Mindset rectangle height and classification submenu buttons."""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
T_ENTRY = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
T_FILTER = (ROOT / 'test/trades_screen_filter_test.dart').read_text(encoding='utf-8')

passed = 0
total = 0
def check(name, ok):
    global passed, total
    total += 1
    passed += bool(ok)
    print(('PASS' if ok else 'FAIL') + ': ' + name)

def between(src, start, end):
    i = src.index(start)
    return src[i:src.index(end, i)]

# ---- release identity
check('pubspec version is 1.7.110+166', 'version: 1.7.110+166' in PUBSPEC)
check('workflow name and artifacts use 1.7.103 / build159',
      'TraderDesk 1.7.110+166' in WORKFLOW and 'traderdesk-1.7.110-build166-arm64-v8a-release' in WORKFLOW
      and 'traderdesk-1.7.110-build166-arm64-dart-symbols' in WORKFLOW)
check('build info names version, parent and APK-less source delivery',
      '1.7.104`؛ رقم البناء: `160' in BUILD_INFO and 'TraderDesk_Android_Project_v1.7.100+156_GPT_SOURCE.zip' in BUILD_INFO
      and 'لا يتضمن هذا التسليم APK' in BUILD_INFO)
check('update report for this release exists', (ROOT / 'UPDATE_REPORT_1.7.110+166.md').exists())

# ---- request 1: mindset rectangle == market/direction rectangle
check('shared content-height constant is declared (30dp)',
      re.search(r'const double _tradeDataContentHeight = 30;', FORM) is not None)
compact = between(FORM, 'Widget _compactPopupChoice<T>', 'Widget build(BuildContext context)')
check('market/direction choice row uses the shared content height',
      'height: _tradeDataContentHeight,' in compact)
market = between(FORM, "key: const ValueKey('trade-market-direction-field')", "const SizedBox(width: identifierGap)")
check('market/direction divider uses the shared content height', 'height: _tradeDataContentHeight,' in market)
mood = between(FORM, 'Widget _buildMindsetSelector', 'Widget _setupSelectionField')
check('mindset content is wrapped in a SizedBox with the shared content height',
      re.search(r"SizedBox\(\s*key: const ValueKey\('trade-mood-content'\),[^)]*?height: _tradeDataContentHeight", mood, re.S) is not None)
check('mindset keeps the identical 10/8/10/8 content padding as market/direction',
      mood.count('fromSTEB(\n                  10,\n                  8,\n                  10,\n                  8,') == 1
      and 'EdgeInsetsDirectional.fromSTEB(10, 8, 10, 8)' in market)
check('both fields still use the same 72dp outer height and equal-column width',
      FORM.count('height: _tradeDataControlHeight,') == 2
      and 'const double _tradeDataControlHeight = 72;' in FORM
      and '(constraints.maxWidth - identifierGap) / 2' in FORM
      and FORM.count('width: marketControlWidth,') == 2)
check('mindset still uses the shared blue selector decoration and keeps its popup behaviour',
      '_blueSelectorDecoration(' in mood and "ValueKey('trade-mood-dropdown')" in mood
      and "ValueKey('trade-mood-selected-value')" in mood and 'onSelected: (value) => setState(() => _mood = value)' in mood)
check('mindset keeps the disabled dimming only on content', 'opacity: enabled ? 1 : .52' in mood)
check('entry_conditions_test compares mindset content height to market content row',
      "trade-mood-content" in T_ENTRY and "trade-market-direction-choices-row" in T_ENTRY)

# ---- request 2: break-even button == missed button
check('shared submenu button widget exists', 'class _ClassificationSubmenuButton<T> extends StatelessWidget' in TRADES)
check('break-even submenu uses the shared widget',
      re.search(r"_ClassificationSubmenuButton<_BreakEvenTradeFilter>\(\s*key: const ValueKey\('trades-filter-break-even-submenu'\)", TRADES) is not None)
check('missed submenu uses the shared widget',
      re.search(r"_ClassificationSubmenuButton<_MissedTradeFilter>\(\s*key: const ValueKey\('trades-filter-missed-submenu'\)", TRADES) is not None)
check('no raw PopupMenuButton remains for the two sub-filters',
      'PopupMenuButton<_BreakEvenTradeFilter>' not in TRADES and 'PopupMenuButton<_MissedTradeFilter>' not in TRADES)
btn = between(TRADES, 'class _ClassificationSubmenuButton<T>', 'class _TradesDropdownSurface')
check('button keeps the 28x32 hit area and 16dp glyph', 'width: 28' in btn and 'height: 32' in btn and 'size: 16' in btn)
check('button colour is resolved explicitly from text3 with the disabled-item opacity (0.5 dark / 0.38 light)',
      'tokens.text3.withValues' in btn and 'dark ? .5 : .38' in btn)
check('inherited icon opacity is reset so the host row state cannot change the tone',
      'IconThemeData(opacity: 1)' in btn)
check('missed row is still a disabled menu item with its own label tap target',
      'enabled: filter != _TradeFilter.missed' in TRADES and "ValueKey('trades-filter-missed-select')" in TRADES)
check('count column helper reserves one width for every row',
      '_classificationCount(itemContext, tokens, filterCounts, filter)' in TRADES
      and 'trades-filter-count-${filter.name}' in TRADES and 'AlignmentDirectional.centerEnd' in TRADES)
check('sub-filter behaviour is unchanged (break-even)',
      '_breakEvenTradeFilter = selection;' in TRADES and "trades-break-even-subfilter-${selection.name}" in TRADES)
check('sub-filter behaviour is unchanged (missed)',
      '_missedTradeFilter = selection;' in TRADES and "trades-missed-subfilter-${selection.name}" in TRADES)
check('widget test covers alignment, size, count column and glyph tone',
      'share one vertical line, size and tone' in T_FILTER and 'trades-filter-count-' in T_FILTER)

print(f'RESULT: {passed}/{total}')
sys.exit(0 if passed == total else 1)
