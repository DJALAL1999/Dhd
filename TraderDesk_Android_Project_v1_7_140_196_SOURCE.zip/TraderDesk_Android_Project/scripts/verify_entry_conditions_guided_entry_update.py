#!/usr/bin/env python3
"""Verify that Opposing signals / Bounce area joined the guided auto-entry
sequence: same Continue-button list design, tab auto-switch, and missing-step
redirect detection as the other guided sections."""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")

ENGINE = (ROOT / "lib/domain/guided_entry_engine.dart").read_text(encoding="utf-8")

checks = []


def check(name, condition):
    checks.append((name, bool(condition)))


# 1. The two new steps exist in the enum and in the guided walkthrough order.
check(
    "enum defines reverseSignals and bounceZone steps",
    re.search(r"reverseSignals,\s*\n\s*bounceZone,\s*\n}", ENGINE),
)
check(
    "_guidedSections appends reverseSignals then bounceZone after exitReason",
    re.search(
        r"GuidedStep\.exitReason,\s*\n\s*GuidedStep\.reverseSignals,"
        r"\s*\n\s*GuidedStep\.bounceZone,\s*\n\s*\];",
        ENGINE,
    ),
)

# 2. Tab auto-switching: both guided-entry drivers switch tabs for these steps.
check(
    "_formSectionIndexForGuidedStep routes reverseSignals/bounceZone to tab 1",
    "_entryConditionsTabSections.contains(step) ? 1 : 0" in FORM
    and "_AutoEntryStep.reverseSignals,\n    _AutoEntryStep.bounceZone,\n  };" in FORM,
)
check(
    "_advanceGuidedEntry uses _formSectionIndexForGuidedStep (not hardcoded tab 0)",
    FORM.count("_activeFormSectionIndex = _formSectionIndexForGuidedStep(next);") == 2,
)
check(
    "_reconcileGuidedEntryAfterChange also switches tabs (no one-frame flash)",
    "_reconcileGuidedEntryAfterChange" in FORM
    and FORM.index("_reconcileGuidedEntryAfterChange(")
    < FORM.index("_activeFormSectionIndex = _formSectionIndexForGuidedStep(next);"),
)

# 3. Anchor keys + section-list routing wired for both new steps.
check(
    "dedicated GlobalKeys exist for both Entry Conditions fields",
    "_reverseSignalSectionKey = GlobalKey()" in FORM
    and "_bounceZoneSectionKey = GlobalKey()" in FORM,
)
check(
    "_guidedSectionAnchorKey maps both steps to their GlobalKeys",
    "_AutoEntryStep.reverseSignals => _reverseSignalSectionKey," in FORM
    and "_AutoEntryStep.bounceZone => _bounceZoneSectionKey," in FORM,
)
check(
    "_openGuidedSectionList routes both steps to their round functions",
    "_AutoEntryStep.reverseSignals => _reverseSignalRound(guided: true)," in FORM
    and "_AutoEntryStep.bounceZone => _bounceZoneRound(guided: true)," in FORM,
)
check(
    "_advanceGuidedEntry's section switch handles both new steps",
    re.search(
        r"case _AutoEntryStep\.exitReason:\s*\n\s*case _AutoEntryStep\.reverseSignals:"
        r"\s*\n\s*case _AutoEntryStep\.bounceZone:",
        FORM,
    ),
)

# 4. Same list/continue design as Trade Data: _showEntryConditionSetup now
#    supports guided mode and forwards it into the shared _showChoiceSheet.
check(
    "_showEntryConditionSetup accepts guided + selectedKeys params",
    re.search(
        r"Future<TradeEntryConditionSetup\?> _showEntryConditionSetup\(\{[^}]*"
        r"bool guided = false,\s*\n\s*Set<String>\? selectedKeys,",
        FORM,
        re.S,
    ),
)
check(
    "_showEntryConditionSetup forwards guided/selectedKeys to _showChoiceSheet",
    "guidedContinue: guided,\n      selectedKeys: selectedKeys,\n    );" in FORM,
)
check(
    "Continue in the top-level list resolves to a dedicated sentinel",
    "_entryConditionGuidedContinueSentinel" in FORM
    and "if (menuKey == _guidedContinueValue) {\n      return _entryConditionGuidedContinueSentinel;"
    in FORM,
)

# 5. Guided round functions exist and recognize the sentinel.
check(
    "_reverseSignalRound exists and returns .continued on the sentinel",
    re.search(
        r"Future<_GuidedListOutcome> _reverseSignalRound\(\{bool guided = false\}\) async \{"
        r".*?_GuidedListOutcome\.continued;",
        FORM,
        re.S,
    ),
)
check(
    "_bounceZoneRound exists and returns .continued on the sentinel",
    re.search(
        r"Future<_GuidedListOutcome> _bounceZoneRound\(\{bool guided = false\}\) async \{"
        r".*?_GuidedListOutcome\.continued;",
        FORM,
        re.S,
    ),
)

# 6. Manual "add" entry points now detect an earlier emptied required section
#    (Entry reason / Entry confirmation) and redirect back to it first, same
#    as the pre-existing sections.
check(
    "_addReverseSignalSetup redirects to a missing earlier guided field",
    "_guideThroughMissing(_AutoEntryStep.reverseSignals)) return;" in FORM,
)
check(
    "_addBounceZoneSetup redirects to a missing earlier guided field",
    "_guideThroughMissing(_AutoEntryStep.bounceZone)) return;" in FORM,
)
check(
    "both add functions short-circuit into the live guided round when active",
    FORM.count("if (_isGuidedSection(_AutoEntryStep.reverseSignals)) {") == 1
    and FORM.count("if (_isGuidedSection(_AutoEntryStep.bounceZone)) {") == 1,
)

# 7. Both fields are reachable by Scrollable.ensureVisible via KeyedSubtree.
check(
    "Opposing signals field is wrapped with its GlobalKey",
    "KeyedSubtree(\n          key: _reverseSignalSectionKey," in FORM,
)
check(
    "Bounce area field is wrapped with its GlobalKey",
    "KeyedSubtree(\n          key: _bounceZoneSectionKey," in FORM,
)

# 8. The same missing-field detection now also fires from Decisions,
#    Commitment and No-entry reasons (they all funnel through _toggleSet),
#    not only from the five guided sections' own "add" entry points.
check(
    "_firstMissingGuidedField treats a non-guided-section intent as "
    "coming after the whole walkthrough",
    "isSection(intent) ? sections.indexOf(intent) : sections.length" in
    " ".join(ENGINE.split()),
)
check(
    "_redirectToMissingGuidedFieldAnywhere wrapper exists",
    "bool _redirectToMissingGuidedFieldAnywhere() =>\n"
    "      _redirectToMissingGuidedField(_AutoEntryStep.idle);" in FORM,
)
check(
    "_toggleSet (Decisions/Commitment/No-entry) checks it before selecting",
    re.search(
        r"void _toggleSet\(Set<String> values, String key, bool selected\) \{"
        r"\s*\n\s*if \(!_hasTradeDirection\) return;"
        r".*?if \(selected && _redirectToMissingGuidedFieldAnywhere\(\)\) return;",
        FORM,
        re.S,
    ),
)

passed = sum(1 for _, ok in checks if ok)
total = len(checks)
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{passed}/{total} checks passed")

if passed != total:
    sys.exit(1)
