#!/usr/bin/env python3
"""Focused static verification for TraderDesk 1.7.117+173."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
MODEL = (ROOT / 'lib/models/trade.dart').read_text(encoding='utf-8')
STORE = (ROOT / 'lib/data/local_store.dart').read_text(encoding='utf-8')
DETAILS = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
MOOD_TEST = (ROOT / 'test/trade_mood_multi_select_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

check('project version is 1.7.117+173', 'version: 1.7.117+173' in PUBSPEC)
check('Android workflow names version 1.7.117+173', 'TraderDesk 1.7.117+173 Android Release APK' in WORKFLOW)
check('Android artifacts use build 173', 'traderdesk-1.7.117-build173-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.117-build173-arm64-dart-symbols' in WORKFLOW)
check('profit and loss are centered as the initial choice', 'if (showTypeChoices)' in FORM and 'child: Center(' in FORM and 'Directionality(' in FORM)
check('profit choice maps to a positive sign', "label: _copy('الربح', 'Profit')" in FORM and "sign: 1" in FORM)
check('loss choice maps to a negative sign', "label: _copy('الخسارة', 'Loss')" in FORM and "sign: -1" in FORM)
check('profit/loss choices retain the familiar test keys', 'trade-result-sign-positive' in FORM and 'trade-result-sign-negative' in FORM)
check('result field uses keyboard Next action', 'textInputAction: TextInputAction.next' in FORM and 'onFieldSubmitted: (_) => _continueAfterResult()' in FORM)
check('positive result advances to expected-loss focus', '_autoEntryStep = _AutoEntryStep.expectedLoss' in FORM and '_expectedLossFocusNode.requestFocus()' in FORM)
check('expected-loss field submits to the next stage', 'onSubmitted: (_) => _continueAfterExpectedLoss()' in FORM)
check('keyboard default focus traversal is controlled during the guided flow', 'onEditingComplete: () {' in FORM and '_autoEntryStep == _AutoEntryStep.expectedLoss' in FORM and 'onEditingComplete: onEditingComplete' in FORM)
check('negative result opens direction without enabling expected loss', 'if (_resultSign == -1)' in FORM and 'readOnly: (_parseResult() ?? 0) < 0' in FORM)
check('direction auto-selection advances to market', 'if (continueFlow) {\n        _autoEntryStep = _AutoEntryStep.market;' in FORM)
check('market auto-selection advances to mindset', 'if (continueFlow) {\n        _autoEntryStep = _AutoEntryStep.mindset;' in FORM)
check('auto flow is restricted to a new initial entry', 'widget.trade == null' in FORM and '!_autoEntrySequenceUsed' in FORM and '_side == null' in FORM and '_symbol == null' in FORM)
check('manual direction or market edits cancel auto progression', 'else if (_autoEntryStep != _AutoEntryStep.idle)' in FORM)
check('mindset selection supports more than one checkbox', 'CheckboxListTile(' in FORM and 'trade-mood-option-${item.key}' in FORM)
check('unknown mindset remains an exclusive fallback', "draft.remove('moodUnknown')" in FORM and "draft.add(item.key)" in FORM)
check('mindset selector preserves its original 72dp field height', 'key: const ValueKey(\'trade-mood-field\'),' in FORM and 'height: _tradeDataControlHeight' in FORM and 'const double _tradeDataControlHeight = 72' in FORM)
check('multi-mindset selections are stored in the trade model', 'final List<String> moods;' in MODEL and 'List<String> get effectiveMoods' in MODEL)
check('multi-mindset selections serialize and deserialize', "'moods': effectiveMoods" in MODEL and "json['moods']" in MODEL)
check('legacy single mood remains the fallback', 'return mood.trim().isEmpty ? const [] : [mood.trim()]' in MODEL)
check('backup restore preserves all selected moods', 'moods: trade.effectiveMoods' in STORE)
check('trade summaries and details render all selected moods', 'trade.effectiveMoods' in DETAILS and "selectedMoods.join('، ')" in DETAILS)
check('positive and negative automatic-flow tests are present', 'profit advances through expected loss' in TESTS and 'loss skips expected loss' in TESTS)
check('editing an existing trade does not cascade automatically', 'manual edits of an existing direction and market do not auto-advance' in TESTS)
check('multi-mood serialization regression tests are present', 'multiple mood selections survive JSON round-trip' in MOOD_TEST and 'legacy single mood records remain readable' in MOOD_TEST)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
