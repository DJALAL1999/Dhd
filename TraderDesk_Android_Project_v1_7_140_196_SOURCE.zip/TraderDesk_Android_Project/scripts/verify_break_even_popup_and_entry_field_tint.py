#!/usr/bin/env python3
"""Static checks for 1.7.110+166: break-even popup anchored on the save slot and
tinted Opposing signals / Bounce area inner fields."""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
TEST_CC = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
TEST_EC = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
failed = []

def check(name, ok):
    print(('PASS' if ok else 'FAIL'), name)
    if not ok:
        failed.append(name)

def body(start_marker, end_marker):
    a = FORM.index(start_marker)
    return FORM[a:FORM.index(end_marker, a)]

check('release is 1.7.110+166', 'version: 1.7.110+166' in PUBSPEC)
check('workflow identity updated', 'TraderDesk 1.7.110+166' in WORKFLOW and 'traderdesk-1.7.110-build166-arm64-v8a-release' in WORKFLOW)
check('update report exists', (ROOT / 'UPDATE_REPORT_1.7.110+166.md').exists())

# --- Request 1: menu in place of the save bar -----------------------------
BAR = (ROOT / 'lib/widgets/trade_save_bar.dart').read_text(encoding='utf-8')
check('inline stacked chooser removed', '_buildBreakEvenTypeChoice' not in FORM)
check('save slot key exists', "_saveSlotKey = GlobalKey(debugLabel: 'trade-save-slot')" in FORM)
popup = body('Future<void> _openOutcomeMenu()', '/// "USD 250+"')
check('menu is a dialog route (not inline)', 'showGeneralDialog<_OutcomeChoice>' in popup)
check('menu anchored to slot rect', '_saveSlotKey.currentContext' in popup and 'slotRect.bottom' in popup)
check('slot scrolled into view first', 'Scrollable.ensureVisible' in popup)
check('menu positioned by bottom edge', 'bottom: bottom' in popup and 'Positioned(' in popup)
check('all four options keep their test keys', "ValueKey('trade-outcome-option-$keyName')" in popup and "keyName: type.name" in popup and "'missedWin'" in popup and "'missedLoss'" in popup)
check('option min height >= 48', 'minHeight: 50' in popup)
check('one tap selects and closes', 'Navigator.of(dialogContext).pop(choice)' in popup)
check('re-entrancy guard', '_outcomeMenuOpen' in popup)
check('classification is derived automatically from the result sign / no-entry link',
      '_reconcileClassification()' in FORM and 'if (_resultSign == 1) return const [TradeClassification.win];' in FORM)
slot = body('Widget _buildSaveBar(String currency)', 'class _OutcomeChoice') if 'class _OutcomeChoice' in FORM else ''
check('slot wraps the merged bar', 'key: _saveSlotKey,' in FORM and 'height: TradeSaveBar.height' in FORM and 'TradeSaveBar(' in FORM)
check('save button lives only inside the shared bar widget', FORM.count("ValueKey('save-trade-button')") == 0 and BAR.count("ValueKey('save-trade-button')") == 1)
check('save with a missing choice reopens the menu', '? _openOutcomeMenu' in FORM)
check('save gate for missing subtype preserved', 'Choose the break-even type before saving.' in FORM)
check('save label has no trailing "الصفقة" word', "saveLabel: tr(context, 'save')" in FORM and "'save': 'حفظ'," in (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8'))

# --- Request 2: tinted inner fields ---------------------------------------
check('shared surface helper exists', 'Color _entryConditionsSurface({' in FORM)
dialog = body('Future<T?> _showCenteredTradeChoiceDialog<T>', 'Future<String?> _showTimeframeSheet')
check('timeframe/choice popup uses shared helper', '_entryConditionsSurface(' in dialog)
field = body('Widget _entryConditionField({', 'Widget _buildLinkedEntryBehaviorSections')
check('fields use shared helper when unlinked', '_entryConditionsSurface(' in field and ': tokens.surface2;' not in field)
check('purple linked fill untouched', 'TradeDetailPalette.linkedEntryConditionsFieldDark' in field and '_noEntryTone.withValues(alpha: .075)' in field)
check('both fields still go through the helper-backed widget', FORM.count('_entryConditionField(') >= 3)
check('tests updated for tinted fills', 'neutralConditionFill' not in TEST_EC and 'reverseConditionFill' in TEST_EC and 'bounceConditionFill' in TEST_EC)
check('popup widget test added', 'save opens the outcome menu in place when a choice is missing' in TEST_CC)

# --- Hygiene ---------------------------------------------------------------
check('no localStorage/cartoon assets introduced', 'localStorage' not in FORM)
sys.exit(1 if failed else 0)
