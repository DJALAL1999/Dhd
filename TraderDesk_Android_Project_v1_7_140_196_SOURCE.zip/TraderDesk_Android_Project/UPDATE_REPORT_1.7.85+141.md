# تقرير تحديث أسباب الدخول — TraderDesk 1.7.85+141

## مصدر التعديل

- المصدر المباشر: `TraderDesk_Android_Project_v1.7.84+140_GPT_SOURCE.zip`.
- الإصدار الناتج: `1.7.85` — رقم البناء `141`.
- التسليم: مشروع Flutter المصدري الكامل بصيغة ZIP.

## التغييرات المنفذة

### 1. دمج SFR وRFS

- استبدال صفّي `SFR` و`RFS` بصف واحد في قائمة أسباب الدخول: `SFR / RFS`.
- عند اتجاه `BUY`، يظهر السبب المحدد في مستطيل العناصر المختارة باسم `RFS`.
- عند اتجاه `SELL`، يظهر باسم `SFR`.
- يظل الاختيار مرتبطاً بالفريم الزمني نفسه، ويتغير الاسم فور تبديل اتجاه الصفقة.

### 2. دمج Trendline Touch 3

- استبدال الخيارين المنفصلين بخيار واحد في القائمة: `Trendline Touch 3`.
- عند `BUY`، يظهر في العناصر المختارة `Trendline Touch 3 Buy`.
- عند `SELL`، يظهر `Trendline Touch 3 Sell`.
- تم اعتماد ترتيب الكلمات المطلوب في أسماء العرض الجديدة.

### 3. دمج Trendline Touch 3 Breakout

- استبدال الخيارين المنفصلين بخيار واحد: `Trend Line Touch 3 Breakout`.
- حسب قاعدة الاتجاه العكسية التي حددها الطلب:
  - `BUY` يعرض `Trend Line Touch 3 Sell Breakout`.
  - `SELL` يعرض `Trend Line Touch 3 Buy Breakout`.
- العنوان السياقي لنافذة الفريمات والعنصر المختار والصفقات المحفوظة تستخدم نفس قاعدة العرض.

### 4. التوافق ومنع التكرار

- أضيفت مفاتيح دلالية مستقلة للخيارات الموحدة الثلاثة: `directionalSfrRfs` و`directionalTrendlineTouch3` و`directionalTrendlineTouch3Breakout`.
- لا يتغير مخطط JSON أو نموذج `TradeEntrySetup`؛ يظل حقل السبب نصياً كما كان.
- مفاتيح السجلات القديمة لـ SFR/RFS وTrendline Buy/Sell وTrendline Breakout تبقى قابلة للقراءة، وتُطابق صف الاختيار الموحد عند تحريرها.
- تم تعديل فحص التكرار ليقارن المفتاح الدلالي الموحد بدلاً من النص الحرفي، لمنع تكرار السبب نفسه والفريم بعد الدمج.
- جميع مواضع العرض الحالية تستخدم `formatTradeEntryReasonLabel` المركزي، بما فيها نموذج الصفقة وشرائح الأسباب وبطاقات/تفاصيل الصفقات وملخص الأيام.
- لم تتغير بقية أسباب الدخول، أو الفريمات، أو الارتكاز، أو ظروف الدخول، أو تأكيد الدخول.

## الملفات المرتبطة بالتعديل

- `lib/domain/trade_entry_catalog.dart`
- `lib/screens/trade_form_screen.dart`
- `test/trade_entry_catalog_test.dart`
- `test/custom_confirmation_test.dart`
- `test/entry_conditions_test.dart`
- `test/trading_app_test.dart`
- سكربتات التحقق في `scripts/` لتتوافق مع الإصدار الجديد وتتحقق من خيارات الاتجاه الموحّدة.
- `pubspec.yaml` و`.github/workflows/android-build.yml` و`README.md` و`BUILD_INFO_AR.md` و`RELEASE_NOTES_AR.md`.

## نتائج التحقق التي نُفذت فعلياً

- فحوصات التحقق الساكنة: **305/305** ناجحة عبر 11 سكربتاً.
- تغطية عينات الخطوط العربية واللاتينية/الأرقام: نجحت العينتان.
- YAML: ملفا `pubspec.yaml` وGitHub Actions قُرئا بنجاح.
- Android XML: **8/8** ملفات سليمة.
- Python: `compileall` لسكربتات التحقق نجح.
- Bash: فحص الصياغة نجح لملفي shell و`android/gradlew`.
- تم فحص مصدر التغيير بمقارنته بأرشيف `1.7.84+140`؛ نطاق التغييرات مقتصر على الكتالوج ومنطق إدخال سبب الصفقة واختباراته وملفات الإصدار والفحوصات.

## اختبارات لم يمكن تشغيلها

حاولت تشغيل:
- `flutter analyze`
- `flutter test`
- `flutter build apk --release --target-platform android-arm64`

لكن Flutter وDart SDK غير مثبتين في بيئة التنفيذ (`flutter: command not found` و`dart: command not found`). لذلك لم تُشغّل اختبارات Flutter فعلياً ولم يُنتج APK. ملف التسليم هو المشروع المصدري الكامل، وليس APK.
