# تقرير التحديث والتحقق — TraderDesk 1.7.80+136

## المصدر وحدود التعديل

- المصدر المستخدم مباشرةً: `TraderDesk_Android_Project_v1.7.78+134_GPT_SOURCE.zip` المرفق في هذه المحادثة.
- لم تُستخدم ملفات أو تعديلات من النسخ التي أُنشئت بعد `1.7.78+134`.
- رقم الإصدار: `1.7.80`، رقم البناء: `136`. استُخدم هذا الرقم لتفادي إعادة استخدام `1.7.79+135` الذي سبق ظهوره في تسليم سابق مختلف، وليس دليلاً على استيراد أي محتوى منه.

## التعديلات المنفذة

### 1. تسميات ارتداد S/R

أصبح النص المعروض في مستطيل الاختيارات وفي تفاصيل الصفقة وفق اتجاه الصفقة كما يلي:

| الاتجاه | خيار اللمسة | النص المعروض |
|---|---|---|
| BUY | Touch 2 محدد | `ارتداد من Support Touch 15MIN` |
| BUY | دون Touch 2 | `ارتداد من Support 15MIN` |
| SELL | Touch 2 محدد | `ارتداد من Resistance Touch 15MIN` |
| SELL | دون Touch 2 | `ارتداد من Resistance 15MIN` |

- استُخدمت تهجئة `Resistance` الصحيحة بدلاً من `Resistan`.
- أزيلت الشرطة والفاصل غير المرغوبين، وأصبح ترتيب النص ثابتاً: نوع الارتداد، ثم `Touch` عند تفعيله، ثم الفريم.
- نافذة الاختيار نفسها ما زالت تعرض الاختيار باسم `2 Touch`؛ الاختصار إلى `Touch` يخص تسمية العنصر المختار فقط.
- بقيت آلية الاتجاه، والفريم، ومفتاح `bounceFromSrZone`، وقيمة `touch2` كما كانت. التغيير في التنسيق المرئي فقط.
- لأن التنسيق مشترك، ينعكس الاسم الجديد في نموذج الإضافة/التعديل وفي تفاصيل الصفقات المحفوظة، بما فيها الصفقات القديمة ذات مفتاح S/R نفسه.

### 2. اختصار تسميات سحب السيولة

| المفتاح الثابت | العربية الجديدة | الإنجليزية الجديدة |
|---|---|---|
| `internalLiquiditySweep` | `سحب سيولة داخلي` | `Internal liquidity sweep` |
| `majorStructureLiquiditySweep` | `سحب السيولة خارجي` | `External liquidity sweep` |

- حُدثت قائمة خيارات منطقة الارتداد والترجمات المركزية.
- لم تتغير مفاتيح الخيارين؛ لذلك تبقى الصفقات المحفوظة سابقاً قابلة للقراءة، وتظهر لها التسمية الجديدة عند العرض.

## الملفات التي عُدلت

- `lib/domain/trade_entry_catalog.dart`
- `lib/l10n/app_strings.dart`
- `test/trade_entry_catalog_test.dart`
- `test/entry_conditions_test.dart`
- `test/trade_detail_layout_test.dart`
- `scripts/verify_text_cleanup.py`
- `scripts/verify_bounce_direction_gate.py`
- `scripts/verify_base_anchor_update.py`
- `scripts/verify_precision_update.py`
- `scripts/verify_timeframe_header_update.py`
- إضافة `scripts/verify_sr_bounce_liquidity_label_update.py`
- `pubspec.yaml`
- `.github/workflows/android-build.yml`
- `README.md`
- `RELEASE_NOTES_AR.md`
- `BUILD_INFO_AR.md`

## التحقق الذي نُفذ فعلياً

- اجتازت سكربتات التحقق الثابتة الثمانية **235/235** تحققاً. كما نجح اختبارا تغطية عينات الخطوط العربية واللاتينية ضمن فحص الخطوط؛ ليكون إجمالي بنود التحقق الثابت وتغطية المحارف **237/237**.
- نجح `python3 -m compileall -q scripts`.
- نجح `bash -n` لملفات `android/gradlew` و`build_release_apk.sh` و`verify_arm64_apk.sh`.
- نجح تحليل YAML لكل من `pubspec.yaml` و`.github/workflows/android-build.yml`.
- نجح تحليل ملفات Android XML الثمانية.
- فُحصت جميع مواضع استدعاء formatter المشترك، وتأكد غياب الصياغات العربية القديمة المطلوبة من كود التطبيق النشط.

## ما لم يُنفذ

- لم تتوفر أوامر `flutter` أو `dart` في بيئة التنفيذ؛ لذلك لم يُشغّل `flutter analyze` أو `flutter test` ولم يُنفذ بناء APK.
- اختبارات Dart/Flutter المحدثة موجودة في المشروع لكنها لم تُشغّل فعلياً هنا.
- التسليم مشروع Flutter المصدري ZIP، وليس APK.
